#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-06-08
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################
# -------------------------------------------------------------------------------------------------------------------------------
usage()
{
	echo ""
	echo "Usage: $(basename $0) -n net -s sta -c str -f start -d days -o out_dir [ -w wlen ] [ -h step ] [ -g cfg_dir ]"
	echo " where:"
	echo "  -n net specifies the network"
	echo "  -s sta specifies the station"
	echo "  -c str specifies the stream"
	echo "  -f start specifies the start date"
	echo "  -d days specifies the number of days to be analyzed"
	echo "  -o specifies the output directory"
	echo "  -w wlen specifies duration of a single analysis time window (in seconds);"
	echo "  must be between ${MIN_RECLEN} and ${MAX_RECLEN}"
	echo "  -h step specifies step between two consecutive windows (in days);"
	echo "  must be between ${MIN_STEP} and ${MAX_STEP}"
	echo "  -g specifies the directory containing configuration files, if different from the default"
}
# -------------------------------------------------------------------------------------------------------------------------------
base_dir=$(dirname ${BASH_SOURCE}); cfg_dir=${base_dir}/conf; lib_dir=${base_dir}/tools
fwscm=${lib_dir}/ws_tools.sh; fgpcm=${lib_dir}/gp_tools.sh; fcomm=${lib_dir}/tools.sh
. ${fwscm} && . ${fgpcm} && . ${fcomm} || exit 1

# remote (1) or local (0) data
((blc=1))
# retry (1) or not (0)
((brt=0))

# dataless directory for local data
ddless=${base_dir}/dataless
# -------------------------------------------------------------------------------------------------------------------------------
while getopts n:s:c:f:d:w:h:g:o:r OPZ
do
	case $OPZ in
		n) net=${OPTARG} ;;
		s) sta=${OPTARG} ;;
		c) str=${OPTARG:0:2} ;;
		f) dto=${OPTARG} ;;
		d) dys=${OPTARG} ;;
		w) cmd_drt0=${OPTARG} ;;
		h) cmd_step=${OPTARG} ;;
		g) cfg_dir=${OPTARG} ;;
		o) out=${OPTARG} ;;
		r) ((brt=1)) ;;
		?) usage; exit 1 ;;
	esac
done
# -------------------------------------------------------------------------------------------------------------------------------
((err=0))
# check that the command line options are set
[ -z "${net}" ] && { echo -e "\nspecify network with -n"; ((err+=1)); }
[ -z "${sta}" ] && { echo -e "\nspecify station with -s"; ((err+=1)); }
[ -z "${str}" ] && { echo -e "\nspecify stream with -c"; ((err+=1)); }
[ -z "${dto}" ] && { echo -e "\nspecify start date with -f"; ((err+=1)); }
[ -z "${dys}" ] && { echo -e "\nspecify number of days to be analyzed with -d"; ((err+=1)); }
[ -z "${out}" ] && { echo -e "\nspecify output directory with -o"; ((err+=1)); }
[ ${err} -ne 0 ] && { usage; exit 1; }
# -------------------------------------------------------------------------------------------------------------------------------
# configuration file
fcfg0=${cfg_dir}/hv_noise.conf
# ws configuration file
fcfgw=${cfg_dir}/fdsn_ws.conf
# local data path file
fpth0=${cfg_dir}/datapath.conf
# comp changes file
fchng=${cfg_dir}/comp_changes.conf
# geopsy configuration file
fparm=${cfg_dir}/param_hv_noise.conf
# -------------------------------------------------------------------------------------------------------------------------------
# check various files
[ ! -f "${fcfg0}" -o ! -s "${fcfg0}" ] && { echo -e "\nconfiguration file \"${fcfg0}\" does not exist or is empty"; ((err+=1)); }
[ ! -f "${fcfgw}" -o ! -s "${fcfgw}" ] && { echo -e "\nconfiguration file \"${fcfgw}\" does not exist or is empty"; ((err+=1)); }
[ ! -f "${fpth0}" ] && { echo -e "\ndatapath file \"${fpth0}\" does not exist"; ((err+=1)); }
[ ! -d "${ddless}" ] && { echo -e "\ndataless directory \"${ddless}\" does not exist"; ((err+=1)); }
[ ! -f "${fparm}" ] && { echo -e "\ngeopsy configuration file \"${fparm}\" does not exist"; ((err+=1)); }

# checks net, sta, str
chk_net ${net}; ((err+=$?))
chk_sta ${sta}; ((err+=$?))
chk_str ${str}; ((err+=$?))
[ ${err} -ne 0 ] && exit 1
# -------------------------------------------------------------------------------------------------------------------------------
# verifies that the output directory does not exist
[ -d ${out} ] && { echo -e "\nthe specified output directory exists"; ((err+=1)); }

# check start date and number of days
dto=$(date -u +"${DFMT}" -d "${dto} utc") && hms=$(date -u +"${DFMH}" -d "${dto} utc") || ((err+=1))
dys=$(echo ${dys} | awk '{printf "%d", $1}'); x=$(echo ${dys} | awk '$1>=1')
[ -z "${x}" ] && { echo -e "\nthe number of days to be analyzed must be at least 1"; ((err+=1)); }

[ ${err} -ne 0 ] && exit 1

dt0=${dto}
# -------------------------------------------------------------------------------------------------------------------------------
# cfg
g_cfg=$(init_cfg_hvnoise) && g_cfg=$(parse_cfg_hvnoise ${fcfg0} "${g_cfg}"); ((err+=$?))
if [ ${err} -eq 0 ]; then
	[ ! -z "${cmd_drt0}" ] && g_cfg=$(set_par_tab "${g_cfg}" "g_cfg_drt0" ${cmd_drt0})
	[ ! -z "${cmd_step}" ] && g_cfg=$(set_par_tab "${g_cfg}" "g_cfg_step" ${cmd_step})
	[ ! -z "${cfg_perc}" ] && g_cfg=$(set_par_tab "${g_cfg}" "g_cfg_perc" ${cfg_perc})
	check_cfg_hvnoise "${g_cfg}"; ((err+=$?))
fi
[ ${err} -ne 0 ] && exit 1
# restyle cfg
cmd_drt0=$(get_par_tab "${g_cfg}" "g_cfg_drt0"); cmd_drt0=$(echo ${cmd_drt0} | awk '{printf "%d", $1}')
cmd_step=$(get_par_tab "${g_cfg}" "g_cfg_step"); cmd_step=$(echo ${cmd_step} | awk '{printf "%d", $1}')
cfg_perc=$(get_par_tab "${g_cfg}" "g_cfg_perc"); cfg_perc=$(echo ${cfg_perc} | awk '{printf "%d", $1}')
g_cfg=$(set_par_tab "${g_cfg}" "g_cfg_drt0" ${cmd_drt0})
g_cfg=$(set_par_tab "${g_cfg}" "g_cfg_step" ${cmd_step})
g_cfg=$(set_par_tab "${g_cfg}" "g_cfg_perc" ${cfg_perc})
# -------------------------------------------------------------------------------------------------------------------------------
# check datapath.conf
links=$(parse_datafile_paths ${fpth0}) && links=$(echo "${links}" | awk -vFS="${WS_SEQ}" -vn=${net} '$2 == n') || exit 1
# if net is not present in datapath file, data are remote
[ -z "${links}" ] && ((blc=1)) || ((blc=0))
# -------------------------------------------------------------------------------------------------------------------------------
# possible component changes
[ -f ${fchng} -a -s ${fchng} ] && chngs=$(awk -vFS="|" '!/^#/ && NF==5' ${fchng})
# -------------------------------------------------------------------------------------------------------------------------------
# checks param.conf
gp_check_param_noise_conf ${fparm} || ((err+=1))
# -------------------------------------------------------------------------------------------------------------------------------
[ ${err} -ne 0 ] && exit 1
# -------------------------------------------------------------------------------------------------------------------------------
# creates directories
dtmp=${out}/${g_dir_tmp}; dmsd=${out}/${g_dir_ms}; dfls=${out}/${g_dir_files}; dhv=${out}/${g_dir_hv}
mkdir -p ${dtmp} ${dmsd} ${dfls} ${dhv} || exit 1
# -------------------------------------------------------------------------------------------------------------------------------
echo -e -n "\nstart date ${dt0}, days to be analyzed ${dys}; "
[ ${blc} -eq 1 ] && echo "remote data" || echo "local data"; echo
# retrieves station info --------------------------------------------------------------------------------------------------------
if [ ${blc} -eq 1 ]; then
	wscfg=$(ws_load_cfg ${fcfgw} 1 0) && wscfg=$(ws_get_links "${wscfg}") && \
	links=$(echo "${wscfg}" | awk '/^'${CFG_WS_DATA}'/ {print $2}') && \
	linkz=$(echo "${wscfg}" | awk '/^'${CFG_WS_STAT}'/ {print $2}') && \
	sta_info=$(ws_get_station_info "${linkz}" ${net} ${sta} "${str}?"); ((err+=$?))
else
	fdless=${ddless}/${net}/${sta}.dless && sta_info=$(ws_parse_dless ${net} ${fdless}) && \
	sta_info=$(echo "${sta_info}" | awk -vFS="#" -vstr=${str} 'substr($4, 1, 2) == str'); ((err+=$?))
	[ ${err} -eq 0 -a -z "${sta_info}" ] && { echo -e "\nperhaps triple ${net}/${sta}/${str} does not exist"; ((err+=1)); }
fi
# -------------------------------------------------------------------------------------------------------------------------------

# restyles geopsy configuration file
[ ${err} -eq 0 ] && \
{ fpart=${dfls}/${g_file_parm_noise}; gp_restyle_param_noise_conf ${fparm} ${fpart}; ((err+=$?)); }

# write coordinates to file
if [ ${err} -eq 0 ]; then
	fcoord=${dfls}/${g_file_coord}
	xcrdz=$(ws_info_coords "${sta_info}" ${net} ${sta}) && echo "${xcrdz}" >${fcoord}; ((err+=$?))
fi

# minimum number of windows
[ ${err} -eq 0 ] && { nwins=$(gp_min_wins ${fpart} ${cmd_drt0} ${cfg_perc}); ((err+=$?)); }

# write the input arguments, nwins and blc to file
if [ ${err} -eq 0 ]; then
	fcall=${dfls}/${g_file_args}
	add_pars_file ${fcall} ${g_info_net} "${net}" ${g_info_sta} "${sta}" ${g_info_str} "${str}" \
	${g_info_dt1} "${dto}" ${g_info_hms} "${hms}" ${g_info_dys} "${dys}" ${g_info_stp} "${cmd_step}" \
	${g_info_drt} "${cmd_drt0}" ${g_info_prc} "${cfg_perc}" ${g_info_n0w} "${nwins}" ${g_info_src} "${blc}"
	((err+=$?))
	if [ ${err} -eq 0 ]; then
		[ ${blc} -eq 0 ] && dfrom="local archive" || dfrom=$(ws_get_data_from "${wscfg}")
		add_pars_file ${fcall} ${g_info_frm} "${dfrom}"; ((err+=$?))
	fi
fi

# writes cmdline to file
[ ${err} -eq 0 ] && { fcmdl=${dfls}/${g_file_cmd}; echo "$(basename $0) $*" >${fcmdl}; }

[ ${err} -ne 0 ] && { rm -r ${out}; exit 1; }
# -------------------------------------------------------------------------------------------------------------------------------
# loop on dates
for i in $(seq 1 ${dys})
do
	echo -e "\ndate ${dt0}"
	yj=$(date -u +"${DFMY}" -d "${dt0}"); dt1=$(date -u +"${DFMT}" -d "${dt0} utc +${cmd_drt0} sec")
	# link or data path
	[ ${blc} -eq 1 ] && linkx=${links} || \
	linkx=$(echo "${links}" | awk -vFS="${WS_SEQ}" -vdt0=${dt0} '$4 <= dt0 && dt0 < $5 {print $1}' | head -n1)
	nslt=$(ws_info_nsls "${sta_info}" ${dt0})
	if [ -z "${linkx}" -o -z "${nslt}" ]; then
		echo -e "\npath or link not found for ${dt0}"
	else
		# loop on nslt
		for nslx in ${nslt}
		do
			# error on current nslx
			((errx=0)); unset tre
			loc=$(echo ${nslx} | awk -vFS=${WS_SEQ} '{print $3}'); nsls=${nslx//${WS_SEQ}/.}.${str}
			xinfo=$(ws_select_stainfo "${sta_info}" ${dt0} ${dt1} ${net} ${sta} "${loc}" ${str}) && \
			ws_check_station_info "${xinfo}" && chs=$(ws_info_chans "${xinfo}") && \
			xsens=$(ws_info_sens_m "${xinfo}"); ((errx=$?))
			if [ ${errx} -eq 0 ]; then
				chz=""
				for chn in ${chs}
				do
					chm=$(chngs_get_cha "${chngs}" ${net} ${sta} "${loc}" ${chn})
					chm=${chm:-${chn}}; chz=$(echo -e "${chz}\n${chm}")
				done
				chz=${chz:1}; ws_check_comps "${chz}"; ((errx=$?))
			fi
			if [ ${errx} -eq 0 ]; then
				# loop on channels
				for chn in ${chs}
				do
					nslc=${net}.${sta}.${loc}.${chn}; fseed=${dmsd}/${nslc}.D.${yj}
					# download or definition of files
					if [ ${blc} -eq 1 ]; then
						fseet=${dtmp}/${nslc}.D.${yj}
						strx="starttime=${dt0}&endtime=${dt1}&net=${net}&sta=${sta}&loc=${loc}&cha=${chn}"
						wget -nv -a /dev/stdout --show-progress -O ${fseet} ${linkx}${strx}; ((errx+=$?))
						[ ${errx} -eq 0 -a ! -s ${fseet} ] && { ((errx+=1)); echo -e "\ndata not found for ${nslc}"; }
					else
						pathd=${linkx}/${yj:0:4}/${net}/${sta}/${chn}.D; fseep=${pathd}/${nslc}.D.${yj}
						if [ ! -f ${fseep} -o ! -s ${fseep} ]; then
							echo -e "\nfile ${fseep} does not exist or is empty"; ((errx+=1))
						elif [ ${dt0:0:10} != ${dt1:0:10} ]; then
							# includes the next day
							yj1=$(date -u +"${DFMY}" -d "${dt1} utc"); pathd=${linkx}/${yj1:0:4}/${net}/${sta}/${chn}.D
							fseez=${pathd}/${nslc}.D.${yj1}; [ -f ${fseez} -a -s ${fseez} ] && fseep="${fseep} ${fseez}"
						fi
					fi
					# qmerge is needed for local data
					if [ ${errx} -eq 0 ]; then
						[ ${blc} -eq 1 ] && fseed=${fseet} || \
						{ qmerge -T -f ${dt0//T/.} -t ${dt1//T/.} -o ${fseed} ${fseep}; ((errx+=$?)); }
						[ ${errx} -eq 0 -a -s ${fseed} ] && tre="${tre} ${fseed}" || ((errx+=1))
					fi
					if [ ${errx} -eq 0 -a ! -z "${chngs}" ]; then
						chm=$(chngs_get_cha "${chngs}" ${net} ${sta} "${loc}" ${chn})
						if [ ! -z "${chm}" ]; then
							# changes the channel code and adjusts the sensitivity table
							ms_ch_cha ${fseed} ${chm} && xsens=$(xs_ch_cha "${xsens}" ${chn} ${chm}); ((errx=$?))
						fi
					fi
					[ ${errx} -ne 0 ] && break
				done
				# end loop on channels
			fi
			[ ${errx} -eq 0 ] && gp_ms_norm ${tre} "${xsens}" && \
			gp_hv_ms ${tre} ${fpart} ${dhv} ${nsls}.${yj}; ((errx=$?))
			if [ ${errx} -eq 139 -a ${brt} -eq 1 ]; then
				echo "retrying using sac files..."
				# retries using sac files
				((errx=0)); fxs=""
				for fms in ${tre}
				do
					if [ ${errx} -eq 0 ]; then
						gap=$(msi -G -tf 1 ${fms} | grep "_")
						[ -z "${gap}" ] && ms2sac ${fms} ${fms}.sac &>/dev/null && fxs="${fxs} "${fms}.sac || ((errx=$?))
					fi
				done
				[ ${errx} -eq 0 ] && fxs=${fxs:1} && gp_hv_sac ${fxs} ${fpart} ${dhv} ${nsls}.${yj}; ((errx=$?))
			fi
			# deletes downloaded files and temporary files
			[ ${blc} -eq 1 ] && dirx=${dtmp} || dirx=${dmsd}
			rm -f ${dirx}/${nsls}?.D.${yj} ${dirx}/${nsls}?.D.${yj}.sac
		done
		# end loop on nslt
	fi
	# ----------------------------------------------------------------------------------------------------------------------------
	dt0=$(date -u +"${DFMT}" -d "${dt0} utc +${cmd_step} days")
done
# end loop on dates
# -------------------------------------------------------------------------------------------------------------------------------
echo
# maybe the check is redundant
check_hvnoise_output ${out} 1 && hv_noise_all ${out} "${g_cfg}" && hv_noise_output ${out} "${g_cfg}"; ((err=$?))
rmdir --ignore-fail-on-non-empty ${dtmp} ${dmsd} ${dfls} ${dhv} ${out}
exit ${err}
