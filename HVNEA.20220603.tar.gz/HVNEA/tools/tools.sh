#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-06-03
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################
# --------------------------------------------------------------------------------------------------------------------------
# 0 or sac, 1 for gsac
SAC_PROG=0
SAC_UNDEF="-12345"
# --------------------------------------------------------------------------------------------------------------------------
g_dir_hv="HV-"
g_dir_ms="mseed"
g_dir_sac="sac"
g_dir_cut="cut"
g_dir_evts="evts"
g_dir_files="files"
g_dir_tmp="tmp_dir"
g_file_evts_list="evts_list.txt"
g_file_evts_resp="evts_resp.txt"
g_file_coord="coords.txt"
g_file_args="args.txt"
g_file_cmd="cmdline.txt"
g_file_parm_noise="param_hv_noise.conf"
g_file_parm_eqk="param_hv_eqk.conf"
g_file_params="params.txt"
# --------------------------------------------------------------------------------------------------------------------------
# eqk output file names
g_eqk_map_ps="map.0.ps"
g_eqk_mean="mean-hv-eqk.@nslc@.txt"
g_eqk_mean_smooth="mean-hv-eqk.@nslc@.txt.S"
g_eqk_img_mean="mean.@nslc@.@ityp@"
g_eqk_map0="map0.@nslc@.ps"
g_eqk_mapt="map1.@nslc@.pdf"
g_eqk_img_map="map.@nslc@.@ityp@"
g_eqk_frm="RM1.@nslc@.txt"
g_eqk_fxall="all.@nslc@.hv"
g_eqk_fxcln="all.@nslc@.clean"
g_eqk_fxtmp="all.@nslc@.tmp"
g_eqk_idtmp="idvs.@nslc@.txt"
g_eqk_info="eqk_info.@nslc@.txt"
g_eqk_ff0s="win-f0s.@nslc@.txt"
g_eqk_m1d="model_1D.txt"
g_eqk_rep="hv-eqk.@nslc@.pdf"
g_eqk_ok=".hv-eqk.ok"
# --------------------------------------------------------------------------------------------------------------------------
# noise output file names
g_noise_flist="@nslc@.list.txt"
g_noise_fxall="@nslc@.all.hv.txt"
g_noise_fxcln="@nslc@.all.hv.clean"
g_noise_fxtmp="@nslc@.all.hv.tmp"
g_noise_dstmp="@nslc@.dates.txt"
g_noise_ff0s="@nslc@.win-f0s.txt"
g_noise_mean="mean-hv-noise.@nslc@.txt"
g_noise_img_all="@nslc@.all.hv.@ityp@"
g_noise_img_mean="@nslc@.all.hv.bw.@ityp@"
g_noise_info="noise_info.@nslc@.txt"
g_noise_rep="hv-noise.@nslc@.pdf"
g_noise_ok=".hv-noise.ok"
# --------------------------------------------------------------------------------------------------------------------------
# field names in input and info
g_info_net="net_code"
g_info_sta="sta_code"
g_info_loc="loc_code"
g_info_str="stream"
g_info_nsl="nslc"
g_info_src="data_source"
g_info_frm="data_from"
g_info_frn="events_from"
g_info_dt1="start_date"
g_info_hms="begin_time"
g_info_dt2="end_date"
g_info_stp="step"
g_info_dys="days"
g_info_drt="record_length"
g_info_mrf="min_rel_frequency"
g_info_wns="num_windows"
g_info_n0w="min_windows"
g_info_prc="min_percentage"
g_info_mg1="min_mag"
g_info_mg2="max_mag"
g_info_sn1="min_snr"
g_info_sn2="max_snr"
g_info_ds1="min_dist"
g_info_ds2="max_dist"
g_info_bz1="min_baz"
g_info_bz2="max_baz"
g_info_dp1="min_dep"
g_info_dp2="max_dep"
g_info_am1="min_amp"
g_info_am2="max_amp"
g_info_tmi="time_ranges"
g_info_lst="evt_list"
g_info_nqk="n_eqk"
g_info_f0w="f0_wins"
g_info_f01="f1_avg"
g_info_a01="a1_avg"
# --------------------------------------------------------------------------------------------------------------------------
# some geopsy parameters
# window length
gp_window_length="gp_window_length"
# frequencies et al.
gp_freq_min="gp_freq_min"
gp_freq_max="gp_freq_max"
gp_freq_scale_type="gp_freq_scale_type"
gp_freq_step_type="gp_freq_step_type"
gp_freq_num_samples="gp_freq_num_samples"
# taper
gp_taper_type="gp_taper_win_type"
gp_taper_rev="gp_taper_win_rev"
gp_taper_width="gp_taper_win_width"
# smoothing
gp_sm_method="gp_sm_method"
gp_sm_width_type="gp_sm_width_type"
gp_sm_width="gp_sm_width"
gp_sm_scale_type="gp_sm_scale_type"
gp_sm_win_type="gp_sm_win_type"
# composition of the horizontal components
gp_horiz_comp="gp_horiz_comp"
# --------------------------------------------------------------------------------------------------------------------------
# some "useful" constants
((SECS_PER_HOUR=3600))
((SECS_PER_DAY=86400))

# some useful date formats;
# used in main scripts, parse_datafile_paths, check_dfile, hv_eqk_select
DFMT="%Y-%m-%dT%H:%M:%S"
# used in eqk main script and in check_ms
DFMN="%Y-%m-%dT%H:%M:%S.%N"
# used in plot noise
DFMP="%Y-%m-%d.%H:%M:%S"
# used in reports
DFMB="%Y-%m-%d %H:%M:%S"
# used in hv_noise_all, hv_noise_select, plot noise
DFMD="%Y-%m-%d"
# used in main scripts
DFMY="%Y.%j"
# used in noise main script
DFMH="%H:%M:%S"

# for f0 from average
MIN_PEAK_AMPL=2
# --------------------------------------------------------------------------------------------------------------------------
# in HV_Eqk.sh

# minimum and maximum duration that can be set for an event
((EQK_MIN_LENGTH=6)); ((EQK_MAX_LENGTH=100))
# pre-event noise length and extra length
((SECS_NOISE=20)); ((SECS_EXTRA=3))
# --------------------------------------------------------------------------------------------------------------------------
# in HV_Noise.sh
# minimum and maximum duration of a window (in seconds)
((MIN_RECLEN=${SECS_PER_HOUR})); ((MAX_RECLEN=${SECS_PER_DAY}))
# minimum and maximum step between two windows (in days)
((MIN_STEP=1)); ((MAX_STEP=30))
# --------------------------------------------------------------------------------------------------------------------------
# for 1d models
Z_LIM=60; Z_MIN=0; Z_MAX=100
# --------------------------------------------------------------------------------------------------------------------------
# noise list format
FMT_LIST_NOISE="%s %5.2f %5d %5.2f %5.2f"
# --------------------------------------------------------------------------------------------------------------------------
# some font settings used in plots

# aspect ratio
aspect_ratio=1.3; map_ratio=${aspect_ratio}

# plot file types
IMG_TYPE_PDF="pdf"; IMG_TYPE_PNG="png"

IMG_SETTINGS="
${IMG_TYPE_PDF}/terminal/pdfcairo enhanced size 7.8, 6
${IMG_TYPE_PDF}/fontterm/Helvetica, 14
${IMG_TYPE_PDF}/fontlabel/Helvetica, 22
${IMG_TYPE_PDF}/fontclabel/Helvetica, 22
${IMG_TYPE_PDF}/fonttitle/Helvetica, 22
${IMG_TYPE_PDF}/fontxtics/Helvetica, 14
${IMG_TYPE_PNG}/terminal/pngcairo enhanced size 832, 640
${IMG_TYPE_PNG}/fontterm/Helvetica, 12
${IMG_TYPE_PNG}/fontlabel/Helvetica, 18
${IMG_TYPE_PNG}/fontclabel/Helvetica, 18
${IMG_TYPE_PNG}/fonttitle/Helvetica, 18
${IMG_TYPE_PNG}/fontxtics/Helvetica, 12"

# some settings for plot noise ---------------------------------------------------------------------------------------------
NOISE_MIN_FREQ=0.1; NOISE_MIN_FREK=0.2; NOISE_MAX_FREQ=15
N_FTICS_LOG=".1, .2, .5, 1, 2, 5, 10, 15"
N_FTICS_LIN=".1, 2, 4, 6, 8, 10, 12, 14, 15"
N_YSCALE_LOG=1; N_CBSCALE_LOG=1; N_XSCALE_LOG=1; N_FSCALE_LOG=1
N_MIN_AMPL_LOG=0.1; N_MAX_AMPL_LOG=30
N_YTICS_LOG=".5, 1, 2, 3, 4, 5, 10, 15, 30"
N_MIN_AMPL_LIN=0; N_MAX_AMPL_LIN=30
N_YTICS_LIN=$(seq -s, 0 2 30)
# some settings for plot eqk -----------------------------------------------------------------------------------------------
EQK_MIN_FREQ=0.5; EQK_MAX_FREQ=15
EQK_FTICS=".5, .6, .7, .8, 1, 2, 3, 4, 5, 10, 15"
EQK_SN_MIN=0; EQK_SN_MAX=30
E_YSCALE_LOG=1
E_MIN_AMPL_LOG=0.1; E_MAX_AMPL_LOG=30
E_YTICS_LOG=".5, 1, 2, 3, 4, 5, 10, 15, 30"
E_MIN_AMPL_LIN=0; E_MAX_AMPL_LIN=30
E_YTICS_LIN=$(seq -s, 0 2 30)
# colormap for SNR
SNR_CMAP="(0 'dark-gray', 1 'dark-green', 2 'green', 3 'orange', 4 'yellow')"
# Matlab colormap, shamelessly copied from http://www.gnuplotting.org/code/default_color_map3.gnu
MATLAB_CMAP="(0 '#000090',1 '#000fff',2 '#0090ff',3 '#0fffee',4 '#90ff70',5 '#ffee00',6 '#ff7000',7 '#ee0000',8 '#7f0000')"
# for gnuplot
export LANG='en_US.UTF-8'
# -------------------------------------------------------------------------------------------------------------------------------
# some description of geopsy parameters
DESC_HOR_COMPS=$(echo -e "${DESC_HOR_COMPS}\nSquared Vectorial sum")
DESC_HOR_COMPS=$(echo -e "${DESC_HOR_COMPS}\nEnergy Total horizontal energy")
DESC_HOR_COMPS=$(echo -e "${DESC_HOR_COMPS}\nAzimuth Directional energy")
DESC_HOR_COMPS=$(echo -e "${DESC_HOR_COMPS}\nGeometric Geometric mean of horizontal components")
DESC_HOR_COMPS=${DESC_HOR_COMPS:1}
# -------------------------------------------------------------------------------------------------------------------------------
chk_imgtype()
{
	local lstr=$1 ltmp
	ltmp=$(echo "${IMG_SETTINGS}" | awk -vFS="/" -vt=${lstr} '$1==t')
	[ -z "${ltmp}" ] && { echo "img type \"${lstr}\" is not valid"; return 1; }
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
get_setting()
{
	local lterm=$1 lparx=$2
	echo "${IMG_SETTINGS}" | awk -vFS="/" -vt=${lterm} -vs=${lparx} '$1==t && $2==s {print $3}' | xargs
}
# -------------------------------------------------------------------------------------------------------------------------------
parse_datafile_paths()
{
	local lfpth=$1
	[ -z "${lfpth}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -s ${lfpth} ] || { echo "${FUNCNAME}: file ${lfpth} does not exist or is empty" >/dev/stderr; return 1; }
	
	local lerr lerz lerx

	local lspth lnts
	local lnet lt1 lt2 ld1 ld2 ldx ld0
	local lidx ltmp ltmq ltmr lrowz lrows

	((lerr=0))
	
	lspth=$(awk '!/^#/ && !/^$/' ${lfpth}); ltmp=$(echo "${lspth}" | awk 'NF != 4')
	[ ! -z "${ltmp}" ] && { echo -e "\n${lfpth}: the number of fields must be 4" >/dev/stderr; return 1; }
	
	lnts=$(echo "${lspth}" | awk '{print $1}' | sort -u)
	for lnet in ${lnts}
	do
		((lerz=0)); unset lrowz
		ltmp=$(echo "${lspth}" | awk -vn=${lnet} '$1 == n' | sort -u); ltmq=$(echo -n "${ltmp}" | awk 'END {print NR}')
		for lidx in $(seq 1 ${ltmq})
		do
			((lerx=0))
			ltmr=$(echo "${ltmp}" | awk -vj=${lidx} 'NR==j')
			lt1=$(echo "${ltmr}"|awk '{print $2}'); lt2=$(echo "${ltmr}"|awk '{print $3}')
			ldx=$(echo "${ltmr}"|awk '{print $4}')
			ld1=$(date -u +"${DFMT}" -d "${lt1} utc" 2>/dev/null) || \
			{ echo -e "\n${lfpth}: date \"${lt1}\" is not valid" >/dev/stderr; ((lerx+=1)); }
			ld2=$(date -u +"${DFMT}" -d "${lt2} utc" 2>/dev/null) || \
			{ echo -e "\n${lfpth}: date \"${lt2}\" is not valid" >/dev/stderr; ((lerx+=1)); }
			if [ ${lerx} -eq 0 ]; then
				[[ "${ld1}" < "${ld2}" ]] || \
				{ echo -e "\n${lfpth} - ${lnet}: error, ${ld1} >= ${ld2}" >/dev/stderr; ((lerz+=1)); }
			fi
			[ ! -d ${ldx} ] && { echo -e "\n${lfpth}: directory ${ldx} does not exist" >/dev/stderr; ((lerz+=1)); }
			chk_net ${lnet} || ((lerz+=1))

			((lerz+=${lerx}))
			[ ${lerz} -eq 0 ] && lrowz=$(echo -e "${lrowz}\n${lnet} ${ld1} ${ld2} ${ldx}")
		done
		# eventually go to the next net; TO VERIFY
		((lerr+=${lerz})); [ ${lerz} -ne 0 ] && continue
		# rearranges by date
		lrowz=${lrowz:1}; lrowz=$(echo "${lrowz}" | sort)
		# check for overlaps
		for lidx in $(seq 1 ${ltmq})
		do
			ltmr=$(echo "${lrowz}" | awk -vj=${lidx} 'NR==j')
			ld1=$(echo "${ltmr}"|awk '{print $2}'); ld2=$(echo "${ltmr}"|awk '{print $3}')
			if [ ${lidx} -gt 1 ]; then
				[[ "${ld1}" < "${ld0}" ]] && \
				{ echo -e "\n${lfpth}: overlap error, ${ld1} < ${ld0}" >/dev/stderr; ((lerz+=1)); }
			fi
			ld0=${ld2}
		done
		[ ${lerz} -eq 0 ] && lrows=$(echo -e "${lrows}\n${lrowz}") || ((lerr+=${lerz}))
	done

	# station is not needed for now, we insert it (empty) for possible future developments
	if [ ${lerr} -eq 0 -a ! -z "${lrows}" ]; then
		lrows=${lrows:1}; lrows=$(echo "${lrows}" | awk -vOFS="#" '{print $4, $1, "", $2, $3}'); echo "${lrows}"
	fi

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# check that the miniseed file is not empty, that it has no gaps, that it covers the time interval specified
check_ms()
{
	local lfseed ldt01 ldt02 lerr
	lfseed=$1; ldt01=$2; ldt02=$3; ((lerr=0))
	[ -z "${ldt02}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -s ${lfseed} ] || { echo "${FUNCNAME}: ${lfseed} does not exist or is empty" >/dev/stderr; return 1; }
	local ldtx0 ldtx1 ldtx2 lstmp lstmq
	ldt01=$(date -u +"${DFMN}" -d "${ldt01} utc") || return 1; ldt01=${ldt01:0:26}
	ldt02=$(date -u +"${DFMN}" -d "${ldt02} utc") || return 1; ldt02=${ldt02:0:26}

	lstmp=$(msi -T -tf 1 ${lfseed}) || { echo "${FUNCNAME}: file ${lfseed} is not valid" >/dev/stderr; return 1; }
	lstmq=$(msi -G ${lfseed} | awk '/_/ {print}')
	[ ! -z "${lstmq}" ] && { echo -e "file ${lfseed} contains gaps"; return 1; }
	ldtx0=$(echo "${lstmp}" | awk '/_/')
	ldtx1=$(echo ${ldtx0} | awk '{print $2}'); ldtx2=$(echo ${ldtx0} | awk '{print $3}')
	lstmp=$(echo ${ldtx1} ${ldt01} ${ldt02} ${ldtx2} | awk '$1 <= $2 && $3 <= $4')
	[ -z "${lstmp}" ] && { echo -e "file ${lfseed} is incomplete" >/dev/stderr; ((lerr=1)); }

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# cake wrapper
cake_w()
{
	local lphase=$1 ldept=$2 ldist=$3 lmodel=$4
	[ -z "${lmodel}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ ! -s "${lmodel}" ] && { echo "${FUNCNAME}: file ${lmodel} does not exist or is empty" >/dev/stderr; return 1; }
	local ltime lstmp lerr
	((lerr=0))
	[ "${lphase}" != "1" ] && lstmp="S,s" || lstmp="P,p"
	ltime=$(cake arrivals --phases=${lstmp} --sdepth=${ldept} --distances=${ldist} --model=${lmodel} 2>/dev/null | \
	awk '$1-0 == $1 {print $3}' | sort -gk1 | head -n1); ((lerr=$?))
	[ -z "${ltime}" ] && ((lerr+=1))
	[ ${lerr} -ne 0 ] && echo -e "\nerror while calculating travel time" >/dev/stderr || echo ${ltime}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
set_t1()
{
	local lval lfiles lstmp lerr
	[ -z "$2" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	lval=$1; shift; lfiles=($@)
	((lerr=0))
	if [ ${SAC_PROG} -eq 0 ]; then
		echo "rh ${lfiles[@]}; ch iztype io; wh; quit" | sac >/dev/null
		echo "rh ${lfiles[@]}; ch T1 ${lval}; wh; quit" | sac >/dev/null
	else
		echo -e "rh ${lfiles[@]}\nch iztype io\nwh\nquit" | gsac >/dev/null
		echo -e "rh ${lfiles[@]}\nch T1 ${lval}\nwh\nquit" | gsac >/dev/null
	fi
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
sync_sacs()
{
	local ldatev lfiles lerr
	local ldatex lxdiff lstrx ldatej ljday lmsec
	[ -z "$2" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	ldatev=$1; shift; lfiles=($@)
	((lerr=0))
	# synchronizes files
	if [ ${SAC_PROG} -eq 0 ]; then
		echo "r ${lfiles[@]}; synch b off; w over; quit" | sac >/dev/null
	else
		echo -e "r ${lfiles[@]}\nsync\nw ${lfiles[@]}\nquit" | gsac >/dev/null
	fi
	# retrieves the date
	if [ ${SAC_PROG} -eq 0 ]; then
		ldatex=$(saclst kzdate f ${lfiles[0]} | awk '{gsub(/\//, "-"); print $2}')
		ldatex=${ldatex}"T"$(saclst kztime f ${lfiles[0]} | awk '{print $2}')
	else
		ldatex=$(saclhdr -NZYEAR -NZMON -NZDAY -NZHOUR -NZMIN -NZSEC -NZMSEC -NL ${lfiles[0]} | \
		awk '{print $1"-"$2"-"$3"T"$4":"$5":"$6"."$7}')
	fi
	lxdiff=$(d_diff ${ldatex} ${ldatev}); ((lerr=$?))
	# sets origin time
	if [ ${lerr} -eq 0 ]; then
		if [ ${SAC_PROG} -eq 0 ]; then
			echo "rh ${lfiles[@]}; ch allt -${lxdiff}; wh; quit" | sac >/dev/null
			echo "rh ${lfiles[@]}; ch o 0; wh; quit" | sac >/dev/null
		else
			ldatej=$(date +"%Y %j %H %M %S %N" -d"${ldatev}"); ((lerr=$?))
			if [ ${lerr} -eq 0 ]; then
				lstrx=$(echo ${ldatej} | awk '{print "nzhour", $3, "nzmin", $4, "nzsec", $5, "nzmsec", substr($6, 1, 3)}')
				lstrx=$(echo ${ldatej} | awk '{print "nzyear", $1, "nzjday", $2}')" ${lstrx}"
				echo -e "rh ${lfiles[@]}\nch ${lstrx}\nwh\nquit" | gsac >/dev/null
				echo -e "r ${lfiles[@]}\nshift fixed -${lxdiff}\nw\nquit" | gsac >/dev/null
				echo -e "rh ${lfiles[@]}\nch o 0\nwh\nquit" | gsac >/dev/null
			fi
		fi
	fi
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# sac fill wrapper; applies taper before padding
sac_fill_w()
{
	local lflx=$1 ldrt=$2
	local lsset lstap lsfil lprog lerr
	[ -z "${ldrt}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lflx} ] || { echo "${FUNCNAME}: file ${lflx} does not exist" >/dev/stderr; return 1; }
	# clear begin time, taper, possible fill
	lsset="NZYEAR 1970 nzjday 1 nzhour 0 nzmin 0 nzsec 0 nzmsec 0 B 0 T1 ${SAC_UNDEF} O ${SAC_UNDEF}"
	lsset=$(echo -e "rh ${lflx}\nch ${lsset}\nwh\nquit")
	lsfil=$(echo -e "cuterr fill\ncut 0 ${ldrt}\nr ${lflx}\nw ${lflx}\ncut of\nquit")
	[ ${SAC_PROG} -eq 0 ] && \
	{ lstap=$(echo -e "r ${lflx}\nrmean\nrtr\ntaper type hanning w 0.05\nrmean\nw ${lflx}\nquit"); lprog="sac"; } || \
	{ lstap=$(echo -e "r ${lflx}\nrmean\nrtr\ntaper hanning w 0.05\nrmean\nw ${lflx}\nquit"); lprog="gsac"; }
	echo "${lsset}" | ${lprog} >/dev/null && echo "${lstap}" | ${lprog} >/dev/null && echo "${lsfil}" | ${lprog} >/dev/null
	# echo "lsset ${lsset}" && echo "lstap ${lstap}" && echo "lsfil ${lsfil}"
	((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chngs_get_cha()
{
	local lcgs=$1 lnet=$2 lsta=$3 lloc=$4 lcha=$5
	[ -z "${lcha}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	echo "${lcgs}" | awk -vFS="|" -vn=${lnet} -vs=${lsta} -vl=${lloc} -vc=${lcha} \
	'$1==n && $2==s && $3==l && $4==c {print $5}' | awk 'END {print}'
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
ms_ch_cha()
{
	local lfile=$1 lcha=$2
	local lerr lrecs
	((lerr=0))
	[ -z "${lcha}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfile} ] || { echo "${FUNCNAME}: file ${lfile} does not exist" >/dev/stderr; return 1; }
	lrecs=$(echo -e "disp str\nquit" | qedit ${lfile} | awk '/^num_blocks/ {print $NF}')
	[ -z "${lrecs}" ] && return 1
	echo -e "from 1 thru ${lrecs} set chan ${lcha}\nwrite\nquit" | qedit ${lfile} ${lfile} >/dev/null; ((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
xs_ch_cha()
{
	local lxsens=$1 lchn=$2 lcha=$3
	local lerr
	((lerr=0))
	[ -z "${lcha}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	echo "${lxsens}" | awk -vc=${lchn} -vd=${lcha} '{if ($1==c) {$1 = d}; print}'
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
sac_ch_cha()
{
	local lfile=$1 lcha=$2
	local lerr lprog
	((lerr=0))
	[ -z "${lcha}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfile} ] || { echo "${FUNCNAME}: file ${lfile} does not exist" >/dev/stderr; return 1; }
	[ ${SAC_PROG} -eq 0 ] && lprog="sac" || lprog="gsac"
	echo -e "rh ${lfile}\nch kcmpnm ${lcha}\nwh\nquit" | ${lprog} >/dev/null; ((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
d_diff()
{
	local ld1=$1; ld2=$2
	[ -z "${ld2}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local ld01 ld02 ldx lerr
	((lerr=0))
	ld01=$(echo ${ld1} | awk -vFS=. '{print $1}') && \
	ld01=$(date -u +"%s" -d "${ld01} utc") && \
	ld01=${ld01}.$(echo ${ld1} | awk -vFS=. '{print $2}') && \
	ld02=$(echo ${ld2} | awk -vFS=. '{print $1}') && \
	ld02=$(date -u +"%s" -d "${ld02} utc") && \
	ld02=${ld02}.$(echo ${ld2} | awk -vFS=. '{print $2}') && \
	ldx=$(echo ${ld01} ${ld02} | awk '{printf "%f", $2 - $1}'); ((lerr=$?))
	[ ${lerr} -eq 0 ] && echo ${ldx}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
d_diffd()
{
	local ld1=$1; ld2=$2
	[ -z "${ld2}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local ld01 ld02 ldx lerr
	((lerr=0))
	ldx=$(d_diff ${ld1} ${ld2}) && \
	ldx=$(echo ${ldx} | awk -vs=${SECS_PER_DAY} '{if ($1<0) {$1 = -1*$1}; printf "%d", $1/s}')
	((lerr=$?))
	[ ${lerr} -eq 0 ] && echo ${ldx}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves the 1d model
model1d()
{
	local lfrm lfcsv lfiasp ldtmp lfmodel lerr
	lfrm=$1; lfcsv=$2; lfiasp=$3; ldtmp=$4; lfmodel=$5; ((lerr=0))

	local llims llatm llatM llonm llonM lnmt0
	local lfvp lfvs lzs lz lvsm lvpm lfvel

	lfvp=${ldtmp}/vp.txt; lfvs=${ldtmp}/vs.txt; lfvel=${ldtmp}/vels.txt; lfmodel0=${lfmodel}.tmp

	llims=$(gmt info -C ${lfrm})
	llonm=$(echo ${llims} | awk '{print $1}'); llonM=$(echo ${llims} | awk '{print $2}')
	llatm=$(echo ${llims} | awk '{print $3}'); llatM=$(echo ${llims} | awk '{print $4}')

	echo -e "\ncomputation of 1D model..."
	# select the model velocities vp and vs for the area under consideration
	awk -vla1=${llatm} -vla2=${llatM} -vlo1=${llonm} -vlo2=${llonM} -vFS="|" \
	'NR>1 && $2>=la1 && $2<=la2 && $1>=lo1 && $1<=lo2 && $4=="vp" {print $1, $2, $3, $4, $5, $6}' ${lfcsv} >${lfvp}
	awk -vla1=${llatm} -vla2=${llatM} -vlo1=${llonm} -vlo2=${llonM} -vFS="|" \
	'NR>1 && $2>=la1 && $2<=la2 && $1>=lo1 && $1<=lo2 && $4=="vs" {print $1, $2, $3, $4, $5, $6}' ${lfcsv} >${lfvs}

	if [ -s ${lfvp} -a -s ${lfvs} ]; then
		# calculates average vp and vs for each depth and writes them to file
		>${lfvel}; lzs=$(awk '{print $3}' ${lfvs} | sort -gk1 | uniq)
		for lz in ${lzs}
		do
			lvsm=$(awk -vz=${lz} '$3==z {print $5}' ${lfvs} | gmt math STDIN -T -S MEAN =)
			lvpm=$(awk -vz=${lz} '$3==z {print $5}' ${lfvp} | gmt math STDIN -T -S MEAN =)
			echo ${lz} ${lvpm} ${lvsm} >>${lfvel}
		done

		# resamples the 1D model in intervals of 5 km in depth, adds the IASP model for depths greater than 60 km
		gmt sample1d ${lfvel} -T0 -I5 -Fa | \
		awk -vz=${Z_LIM} '$1<=z {printf " %6.2f %.2f %.2f %.2f\n", $1, $2, $3, 2.54}' >${lfmodel0} && \
		awk -vz=${Z_LIM} '$1>z {printf " %6.2f %.2f %.2f %.2f\n", $1, $3, $4, 2.54}' ${lfiasp} >>${lfmodel0} && \
		lnmt0=$(awk '$2>7.4 {print NR-1}' ${lfmodel0} | head -n 1) && \
		sed -e ''${lnmt0}'a\mantle' ${lfmodel0} >${lfmodel}; ((lerr=$?))
	else
		echo "cannot find rows with latitude in [${llatm} - ${llatM}] and longitude in [${llonm} - ${llonM}]"; ((lerr+=1))
	fi

	if [ ${lerr} -eq 0 ]; then
		if [ ! -f ${lfmodel} -o ! -s ${lfmodel} ]; then
			((lerr=1))
		else
			[ ! -z "$(grep 'nan' ${lfmodel})" ] && ((lerr=1))
		fi
		[ ${lerr} -gt 0 ] && echo -e "\nerror getting the 1D model\n"
	fi

	# deletes unnecessary files
	rm -rf ${lfvel} ${lfvp} ${lfvs} ${lfmodel0}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
sac_chk()
{
	local lfx=$1
	[ -z "${lfx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfx} ] || { echo "${FUNCNAME}: file ${lfx} does not exist" >/dev/stderr; return 1; }
	local lstmp lerr
	((lerr=0))
	if [ ${SAC_PROG} -eq 0 ]; then
		lstmp=$(saclst npts f ${lfx}); [ -z "${lstmp}" ] && ((lerr=1))
	else
		lstmp=$(saclhdr -NPTS ${lfx}); [ "${lstmp}" == "-1" ] && { echo "${lfx} seems to be not valid"; ((lerr=1)); }
	fi
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
sac_rms()
{
	local lfx=$1 lc1=$2 lc2=$3
	[ -z "${lc2}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfx} ] || { echo "${FUNCNAME}: file ${lfx} does not exist" >/dev/stderr; return 1; }
	local lfy ldx lerr
	((lerr=0))
	ldx=$(mktemp -dqp.) && lfy=${ldx}/fcut && sac_cut_w ${lfx} ${lfy} ${lc1} ${lc2} && \
	lrms=$(od -An -w4 -v -f -j632 ${lfy} | awk '{x+=$1^2} END {print sqrt(x/NR)}'); ((lerr=$?))
	[ ${lerr} -eq 0 ] && echo ${lrms}
	rm -r ${ldx}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
sac_div_w()
{
	local lfx=$1 lvx=$2
	[ -z "${lvx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfx} ] || { echo "${FUNCNAME}: file ${lfx} does not exist" >/dev/stderr; return 1; }
	local lprog lerr
	[ ${SAC_PROG} -eq 0 ] && lprog="sac" || lprog="gsac"
	echo -e "r ${fsac}\ndiv ${xsens}\nw ${fsac}\nquit" | ${lprog} >/dev/null; ((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
sac_cut_w()
{
	local lfx=$1 lfy=$2 lc1=$3 lc2=$4
	[ -z "${lc2}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfx} ] || { echo "${FUNCNAME}: file ${lfx} does not exist" >/dev/stderr; return 1; }
	local lbeg lend lstmp lstmq lerr
	((lerr=0))
	[ ${SAC_PROG} -eq 0 ] && \
	lstmp=$(saclst b e f ${lfx} | awk '{$1=""; print}' | xargs) || \
	lstmp=$(saclhdr -B -E -NL ${lfx})
	lbeg=$(echo ${lstmp} | awk '{print $1}'); lend=$(echo ${lstmp} | awk '{print $2}')
	# echo "${FUNCNAME}: lbeg = ${lbeg}, lend = ${lend}" >/dev/stderr
	lstmq=$(echo ${lc1} ${lc2} | xargs -n1 | awk -vb=${lbeg} -ve=${lend} '$1 > e || $1 < b')
	[ ! -z "${lstmq}" ] && { echo "${FUNCNAME}: cannot cut between ${lc1} and ${lc2}" >/dev/stderr; return 1; }
	if [ ${SAC_PROG} -eq 0 ]; then
		echo -e "cut ${lc1} ${lc2}\nr ${lfx}\nrmean\nw ${lfy}\ncut of\nquit" | sac >/dev/null; ((lerr=$?))
	else
		lc1=$(echo ${lc1} | awk -vb=${lbeg} '{print $1-b}'); lc2=$(echo ${lc2} | awk -vb=${lbeg} '{print $1-b}')
		echo -e "cut ${lc1} ${lc2}\nr ${lfx}\nrmean\nw ${lfy}\ncut of\nquit" | gsac >/dev/null; ((lerr=$?))
	fi
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
sac_max_amp()
{
	local lfx=$1
	[ -z "${lfx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfx} ] || { echo "${FUNCNAME}: file ${lfx} does not exist" >/dev/stderr; return 1; }
	local lamin lamax lerr
	((lerr=0))
	if [ ${SAC_PROG} -eq 0 ]; then
		lamin=$(saclst DEPMIN f ${lfx} | awk '{print $2}') && lamax=$(saclst DEPMAX f ${lfx} | awk '{print $2}')
		((lerr=$?))
	else
		lamin=$(saclhdr -DEPMIN -DEPMAX -NL ${lfx}) && \
		lamax=$(echo ${lamin} | awk '{print $2}') && \
		lamin=$(echo ${lamin} | awk '{print $1}'); ((lerr=$?))
	fi
	lamax=$(echo ${lamin} ${lamax} | awk '{a = $1^2; b = $2^2; print (a<b) ? sqrt(b) : sqrt(a)}')
	[ ${lerr} -eq 0 ] && echo ${lamax}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_lat()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0 && $0 >= -90 && $0 <= 90')
	[ -z "${ltmp}" ] && { echo -e "\nlatitude ${lval} is not valid (must be between -90 and 90)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_lon()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0 && $0 >= -180 && $0 <= 180')
	[ -z "${ltmp}" ] && { echo -e "\nlongitude ${lval} is not valid (must be between -180 and 180)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_mag()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0 && $0 > 0 && $0 <= 10')
	[ -z "${ltmp}" ] && { echo -e "\nmagnitude ${lval} is not valid (must be between 0 and 10)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_dep()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0')
	[ -z "${ltmp}" ] && { echo -e "\ndepth ${lval} is not valid (must be numeric)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_dst()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0 && $0 >= 1')
	[ -z "${ltmp}" ] && { echo -e "\ndistance ${lval} is not valid (must be al least 1)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_baz()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0 && $0 >= 0 && $0 <= 360')
	[ -z "${ltmp}" ] && { echo -e "\nback-azimuth ${lval} is not valid (must be between 0 and 360)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_snr()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0 && $0 >= 0')
	[ -z "${ltmp}" ] && { echo -e "\nsnr ${lval} is not valid (must be numeric and at least 0)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_amp()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0 && $0 >= 0')
	[ -z "${ltmp}" ] && { echo -e "\namplitude ${lval} is not valid (must be numeric and at least 0)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_fre()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0 == $0 && $0 >= 0')
	[ -z "${ltmp}" ] && { echo -e "\nfrequency ${lval} is not valid (must be numeric and at least 0)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_drt()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk -vm=${MIN_RECLEN} -vM=${MAX_RECLEN} '$0-0==$0 && $0>=m && $0<=M')
	[ -z "${ltmp}" ] && \
	{ echo -e "\nrecord length ${lval} is not valid (must be between ${MIN_RECLEN} and ${MAX_RECLEN})"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_stp()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk -vm=${MIN_STEP} -vM=${MAX_STEP} '$0-0==$0 && $0>=m && $0<=M')
	[ -z "${ltmp}" ] && \
	{ echo -e "\ntime interval ${lval} is not valid (must be between ${MIN_STEP} and ${MAX_STEP})"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_prc()
{
	local lval ltmp lerr
	lval=$@; ((lerr=0))
	ltmp=$(echo ${lval} | awk '$0-0==$0 && $0>=0 && $0<=100')
	[ -z "${ltmp}" ] && { echo -e "\npercentage ${lval} is not valid (must be between 0 and 100)"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_due()
{
	local lval1 lval2 lstr ltmp lerr
	lval1=$1; lval2=$2; lstr=$3; ((lerr=0))
	lstr=${lstr:-"value"}
	ltmp=$(echo ${lval1} ${lval2} | awk '$1 <= $2')
	[ -z "${ltmp}" ] && { echo -e "\nminimum ${lstr} ${lval1} exceeds maximum ${lstr} ${lval2}"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_net()
{
	local lval lerr
	lval=$1; ((lerr=0))
	[[ ${lval} =~ ^[[:alnum:]][[:alnum:]]$ ]] || { echo -e "\nnetwork ${lval} is not valid"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_sta()
{
	local lval lerr
	lval=$1; ((lerr=0))
	[[ ${lval} =~ ^[A-Z][[:alnum:]]{2,4}$ ]] || { echo -e "\nstation ${lval} is not valid"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_loc()
{
	local lval lerr
	lval=$1; ((lerr=0))
	[ -z "${lval}" ] || [[ ${lval} =~ ^[0-9A-Z][0-9A-Z]$ ]] || { echo -e "\nlocation ${lval} is not valid"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_cha()
{
	local lval lerr
	lval=$1; ((lerr=0))
	[[ ${lval} =~ ^[A-Z][A-Z][0-9A-Z]$ ]] || { echo -e "\nchannel ${lval} is not valid"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_stz()
{
	local lval lerr
	lval=$1; ((lerr=0))
	[[ ${lval} =~ ^[A-Z]$ ]] || { echo -e "\nsensor type ${lval} is not valid"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
chk_str()
{
	local lval lerr
	lval=$1; ((lerr=0))
	[[ ${lval} =~ ^[A-Z][A-Z]$ ]] || { echo -e "\nstream ${lval} is not valid"; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
mean_hv()
{
	local lfilex lfiley lerr
	lfilex=$1; lfiley=$2
	((lerr=0))

	[ -z "${lfiley}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfilex} -a -s ${lfilex} ] || { echo "${FUNCNAME}: file ${lfilex} missing or empty" >/dev/stderr; return 1; }

	awk '
	BEGIN {i = -1; n = 0}
	NF >= 2 && !/^#/ {
		# sets i
		if ($1 != f[0] || f[0] == "") {i += 1} else {i = 0}
		# sets f; it is only needed on the first round, but it is not worth checking (I think)
		f[i] = $1
		# possibly increases the total of events
		if ($1 == f[0]) {n += 1}
		# updates s and sq
		x = log($2); s[i] += x; sq[i] += x^2
	}
	END {
		delete f[-1]
		if (n > 0) {
			for (i = 0; i < length(f); i += 1)
			{
				m[i] = s[i]/n; if (n > 1) {st[i] = sqrt((sq[i] - n * m[i]^2)/(n - 1))} else {st[i] = 0};
				print f[i], exp(m[i]), exp(m[i] - st[i]), exp(m[i] + st[i]);
			}
		}
	}' ${lfilex} >${lfiley}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
mean_hp()
{
	local lfilex lfiley lerr
	lfilex=$1; lfiley=$2
	((lerr=0))

	[ -z "${lfiley}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfilex} -a -s ${lfilex} ] || { echo "${FUNCNAME}: file ${lfilex} missing or empty" >/dev/stderr; return 1; }

	awk '
	BEGIN {i = -1; n = 0}
	NF >= 4 && !/^#/ {
		if ($1 != f[0] || f[0] == "") {i += 1} else {i = 0}
		f[i] = $1; k = $4
		if ($1 == f[0]) {n += k}
		x = k * log($2); d = log($3); s[i] += x; sq[i] += (k-1) * d^2
	}
	END {
		delete f[-1]
		if (n > 0) {
			for (i = 0; i < length(f); i += 1)
			{
				m[i] = s[i]/n; if (n > 1) {st[i] = sqrt(sq[i]/(n - 1))} else {st[i] = 0};
				print f[i], exp(m[i]), exp(m[i] - st[i]), exp(m[i] + st[i]);
			}
		}
	}' ${lfilex} >${lfiley}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
f0_from_windows()
{
	local lfilex lerr lstrx
	lfilex=$1
	((lerr=0))
	[ -z "${lfilex}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfilex} -a -s ${lfilex} ] || { echo "${FUNCNAME}: file ${lfilex} missing or empty" >/dev/stderr; return 1; }

	strx=$(awk '
	BEGIN {n = 0; s = 0; sq = 0}
	NF >= 1 && !/^#/ && $1-0==$1 {n += 1; x = log($1); s += x; sq += x^2}
	END {
		if (n > 0) {
			m = s/n; if (n > 1) {st = sqrt((sq - n * m^2)/(n - 1))} else {st = 0};
			printf "%.2f %.2f %.2f", exp(m), exp(m - st), exp(m + st)
		}
	}' ${lfilex})
	[ ! -z "${strx}" ] && echo "${strx}"
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
f0s_from_average()
{
	local lfile lfreq
	lfile=$1; lfreq=$2
	local strx
	local lerr; ((lerr=0))

	[ -z "${lfile}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfile} ] || { echo "${FUNCNAME}: file ${lfile} does not exist" >/dev/stderr; return 1; }
	lfreq=${lfreq:-0}; lfreq=$(echo ${lfreq} | awk '{printf "%.2f", $1}')

	strx=$(awk -vv0=${MIN_PEAK_AMPL} -vf0=${lfreq} '
	BEGIN {b = 0; ds = 0; flag = 1}
	!/^$/ && $1-0==$1 && $1 >= f0 {
	if (b == 1) {ds = $2 - v}
	if (ds >= 0) {if (b == 1) {flag = 0}}
	else if (flag == 0 && v >= v0) {printf "%.2f %.2f\n", f, v; flag = 1}
	f = $1; v = $2; b = 1
	}' ${lfile})
	[ ! -z "${strx}" ] && echo "${strx}"

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_eqk_report()
{
	local lfnf lfmap lfmean lfout lgcfg
	lfnf=$1; lfmap=$2; lfmean=$3; lfout=$4; lgcfg=$5

	local lstr lstx lval ltmp
	local lnsl lfmapx lfmeanx
	local ldout ldtmp lftmpl lftx lfpx lerr

	((lerr=0))

	[ -z "${lgcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }

	lftype=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype")
	lftmpl=$(get_par_tab "${lgcfg}" "g_cfg_eqk_rept")

	# get information
	lstr=$(cat ${lfnf})

	ldout=$(dirname ${lfnf}); ldtmp=$(mktemp -dqp${ldout} "tex.XXXXXX") || return 1
	# --------------------------------------------------------------------------------------------------------------------------
	# suitable names for pdflatex
	lfmapx=${ldtmp}/map.${lftype}; lfmeanx=${ldtmp}/hv-mean.${lftype}
	cp ${lfmap} ${lfmapx} && cp ${lfmean} ${lfmeanx} || return 1
	# --------------------------------------------------------------------------------------------------------------------------
	ltmp=$(cat ${lftmpl})
	for lstx in "g_info_nsl" "g_info_nqk" "g_info_sn1" "g_info_dt1" "g_info_dt2" "g_info_mg1" "g_info_mg2" "g_info_ds1" \
	"g_info_ds2" "g_info_mrf" "g_info_f0w" "g_info_f01" "g_info_a01" "gp_sm_win_type" "gp_sm_width" "gp_horiz_comp"
	do
		lval=$(get_par_tab "${lstr}" ${!lstx}) && ltmp="${ltmp//@@${lstx}@@/${lval}}"; ((lerr+=$?))
	done
	if [ ${lerr} -eq 0 ]; then
		lval=$(date -u +"${DFMB}") && ltmp="${ltmp//@@cdate@@/${lval}}" && \
		lval=$(get_par_tab "${lstr}" ${g_info_frm}) && ltmp="${ltmp//@@dfrom@@/${lval}}" && \
		lval=$(get_par_tab "${lstr}" ${g_info_frn}) && ltmp="${ltmp//@@efrom@@/${lval}}" && \
		# just to be safe
		ltmp="${ltmp//_/underscore}" && \
		ltmp="${ltmp//@@fig-map@@/${lfmapx}}" && ltmp="${ltmp//@@fig-mean@@/${lfmeanx}}"; ((lerr=$?))
	fi
	lnsl=$(get_par_tab "${lstr}" ${g_info_nsl}); lnsl=${lnsl:-tecs}; lftx=${ldtmp}/${lnsl}.tex; lfpx=${ldtmp}/${lnsl}.pdf
	# --------------------------------------------------------------------------------------------------------------------------
	if [ ${lerr} -eq 0 ]; then
		echo "${ltmp}" >${lftx} && \
		pdflatex -output-directory=${ldtmp} -interaction=batchmode ${lftx} &>/dev/null && \
		mv ${lfpx} ${lfout} && rm -r ${ldtmp}; ((lerr=$?))
	fi
	[ ${lerr} -ne 0 ] && echo "${FUNCNAME}: error while creating report" >/dev/stderr

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_noise_report()
{
	local lfnf lfigc lfigb lfout lgcfg
	lfnf=$1; lfigc=$2; lfigb=$3; lfout=$4; lgcfg=$5

	local lstr lstx lval ltmp
	local lnsl lfigcx lfigbx
	local ldout ldtmp lftmpl lftx lfpx lerr

	((lerr=0))

	[ -z "${lgcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }

	lftype=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype")
	lftmpl=$(get_par_tab "${lgcfg}" "g_cfg_noise_rept")

	# get information
	lstr=$(cat ${lfnf})

	ldout=$(dirname ${lfnf}); ldtmp=$(mktemp -dqp${ldout} "tex.XXXXXX") || return 1
	# --------------------------------------------------------------------------------------------------------------------------
	# suitable names for pdflatex
	lfigcx=${ldtmp}/hv-all.${lftype}; lfigbx=${ldtmp}/hv-mean.${lftype}
	cp ${lfigc} ${lfigcx} && cp ${lfigb} ${lfigbx} || return 1
	# --------------------------------------------------------------------------------------------------------------------------
	ltmp=$(cat ${lftmpl})
	for lstx in "g_info_nsl" "g_info_dt1" "g_info_hms" "g_info_dys" "g_info_drt" "g_info_mrf" "g_info_wns" "g_info_f01" \
	"g_info_a01" "gp_window_length" "gp_taper_type" "gp_taper_width" "gp_sm_win_type" "gp_sm_width" "gp_horiz_comp"
	do
		lval=$(get_par_tab "${lstr}" ${!lstx}) && ltmp="${ltmp//@@${lstx}@@/${lval}}"; ((lerr+=$?))
	done
	if [ ${lerr} -eq 0 ]; then
		lval=$(date -u +"${DFMB}") && ltmp="${ltmp//@@cdate@@/${lval}}" && \
		lval=$(get_par_tab "${lstr}" ${g_info_frm}) && ltmp="${ltmp//@@dfrom@@/${lval}}" && \
		# just to be safe
		ltmp="${ltmp//_/underscore}" && \
		ltmp="${ltmp//@@fig-contour@@/${lfigcx}}" && ltmp="${ltmp//@@fig-mean@@/${lfigbx}}"; ((lerr=$?))
	fi
	lnsl=$(get_par_tab "${lstr}" ${g_info_nsl}); lnsl=${lnsl:-tecs}; lftx=${ldtmp}/${lnsl}.tex; lfpx=${ldtmp}/${lnsl}.pdf
	# --------------------------------------------------------------------------------------------------------------------------
	if [ ${lerr} -eq 0 ]; then
		echo "${ltmp}" >${lftx} && \
		pdflatex -output-directory=${ldtmp} -interaction=batchmode ${lftx} &>/dev/null && \
		mv ${lfpx} ${lfout} && rm -r ${ldtmp}; ((lerr=$?))
	fi
	[ ${lerr} -ne 0 ] && echo "${FUNCNAME}: error while creating report" >/dev/stderr

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_eqk_info()
{
	local lftxt lnsl lfevts
	lftxt=$1; lnsl=$2; lfevts=$3
	local lerr ltevts ltmpx lneqk lt1 lt2
	((lerr=0))
	[ -z "${lfevts}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${levts} -a -s ${levts} ] || { echo -e "\n${levts} does not exist or is empty"; return 1; }

	# perhaps the filter on $NF is not needed
	ltevts=$(awk -vn=${lnsl} '!/^#/ && $2 == n && $NF == 0 {print}' ${lfevts})
	lneqk=$(echo -n "${ltevts}" | awk 'END {print NR}')
	add_pars_file ${lftxt} ${g_info_nqk} "${lneqk}" || return 1
	if [ ${lneqk} -gt 0 ]; then
		ltmpx=$(echo "${ltevts}" | awk '{print substr($3, 1, 19)}' | tr "T" " " | sort -u)
		lt1=$(echo "${ltmpx}" | awk 'NR == 1'); lt2=$(echo "${ltmpx}" | awk 'END {print}')
		add_pars_file ${lftxt} ${g_info_dt1} "${lt1}" ${g_info_dt2} "${lt2}"
		ltmpx=$(echo "${ltevts}" | awk '{print $7}' | sort -n)
		lt1=$(echo "${ltmpx}" | awk 'NR == 1'); lt2=$(echo "${ltmpx}" | awk 'END {print}')
		add_pars_file ${lftxt} ${g_info_mg1} "${lt1}" ${g_info_mg2} "${lt2}"
		ltmpx=$(echo "${ltevts}" | awk '{print $9}' | sort -n)
		lt1=$(echo "${ltmpx}" | awk 'NR == 1'); lt2=$(echo "${ltmpx}" | awk 'END {print}')
		add_pars_file ${lftxt} ${g_info_ds1} "${lt1}" ${g_info_ds2} "${lt2}"
	fi
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_eqk_header()
{
	local lfnf lfhv
	lfnf=$1; lfhv=$2
	local lerr lstr ltmp ltmq lstx
	((lerr=0))

	[ -z "${lfhv}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfhv} ] || { echo -e "\n${lfhv} does not exist"; return 1; }

	lstx=$(cat ${lfnf})
	ltmp=$(get_par_tab "${lstx}" ${g_info_nqk}); lstr=$(echo -e "# Number of earthquakes used: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_sn1}); lstr=$(echo -e "${lstr}\n# Minimum SNR: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_dt1}); lstr=$(echo -e "${lstr}\n# Start date: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_dt2}); lstr=$(echo -e "${lstr}\n# End date: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_mg1}); ltmq=$(get_par_tab "${lstx}" ${g_info_mg2})
	lstr=$(echo -e "${lstr}\n# Magnitude range: ${ltmp} - ${ltmq}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_ds1}); ltmq=$(get_par_tab "${lstx}" ${g_info_ds2})
	lstr=$(echo -e "${lstr}\n# Range of distances from station: ${ltmp} - ${ltmq}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_f01}); lstr=$(echo -e "${lstr}\n# f0 from average: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_a01}); lstr=$(echo -e "${lstr}\n# A0 from average: ${ltmp}")

	echo -e "${lstr}\n$(cat ${lfhv})" >${lfhv}; ((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_noise_header()
{
	local lfnf lfhv
	lfnf=$1; lfhv=$2
	local lerr lstr lstx ltmp
	((lerr=0))
	[ -z "${lfhv}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfhv} ] || { echo -e "\n${lfhv} does not exist"; return 1; }
	
	lstx=$(cat ${lfnf})
	ltmp=$(get_par_tab "${lstx}" ${g_info_dt1}); lstr=$(echo -e "# Start date: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_dys}); lstr=$(echo -e "${lstr}\n# Number of days used: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_drt}); lstr=$(echo -e "${lstr}\n# Daily recording duration: ${ltmp} sec")
	ltmp=$(get_par_tab "${lstx}" ${gp_window_length}); lstr=$(echo -e "${lstr}\n# Window length: ${ltmp} sec")
	ltmp=$(get_par_tab "${lstx}" ${g_info_wns}); lstr=$(echo -e "${lstr}\n# Total number of windows: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_f01}); lstr=$(echo -e "${lstr}\n# f0 from average: ${ltmp}")
	ltmp=$(get_par_tab "${lstx}" ${g_info_a01}); lstr=$(echo -e "${lstr}\n# A0 from average: ${ltmp}")
	
	echo -e "${lstr}\n$(cat ${lfhv})" >${lfhv}; ((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_smooth()
{
	local lfile lfout
	lfile=$1 lfout=$2

	local lplot ldirt lftmp
	local ln1 ln2 ln3
	local lerr; ((lerr=0))

	[ -z "${lfout}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfile} ] || { echo "${FUNCNAME}: file ${lfile} does not exist" >/dev/stderr; return 1; }

	ldirx=$(dirname ${lfile}); ldirt=$(mktemp -dqp ${ldirx}) || return 1
	lftmp=${ldirt}/t0
	awk '!/^#/ && $1-0==$1 {print $1, $2, $3, $4}' ${lfile} >${lftmp}
	
	lplot=${ldirt}/plotm.txt; >${lplot}
	echo "set table '${ldirt}/t1'" >>${lplot}; echo "plot '${lftmp}' u 1:2:(10) smooth acsplines" >>${lplot}
	echo "set table '${ldirt}/t2'" >>${lplot}; echo "plot '${lftmp}' u 1:3:(10) smooth acsplines" >>${lplot}
	echo "set table '${ldirt}/t3'" >>${lplot}; echo "plot '${lftmp}' u 1:4:(10) smooth acsplines" >>${lplot}
	echo "unset table; quit" >>${lplot}
	gnuplot ${lplot}; ((lerr=$?))
	if [ ${lerr} -eq 0 ]; then
		awk '$1-0==$1 {print $1, $2}' ${ldirt}/t1 >${ldirt}/t1.c; ln1=$(awk 'END {print NR}' ${ldirt}/t1.c)
		awk '$1-0==$1 {print $1, $2}' ${ldirt}/t2 >${ldirt}/t2.c; ln2=$(awk 'END {print NR}' ${ldirt}/t2.c)
		awk '$1-0==$1 {print $1, $2}' ${ldirt}/t3 >${ldirt}/t3.c; ln3=$(awk 'END {print NR}' ${ldirt}/t3.c)
		if [ ${ln1} -eq ${ln2} -a ${ln2} -eq ${ln3} ]; then
			paste ${ldirt}/t1.c ${ldirt}/t2.c ${ldirt}/t3.c | awk '{print $1, $2, $4, $6}' >${lfout}
		else
			echo "${FUNCNAME}: cannot paste files" >/dev/stderr; ((lerr=1))
		fi
	fi
	[ ${lerr} -eq 0 ] && rm -rf ${ldirt}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
fevts_hdr()
{
	local lfile=$1
	[ -z "${lfile}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	echo "#id nsls dat lat lon dep mag baz dst f0w min max snr res" >${lfile}; return $?
}
# -------------------------------------------------------------------------------------------------------------------------------
# not used for now
fevts_add()
{
	local lfile=$1 lstrx=$2
	[ -z "${lstrx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lidv lnsl ldat llat llon ldep lmag lbaz ldst lf0w lam1 lam2 lsnr lres
	lidv=$(echo ${lstrx} | awk -vFS="#" '{print $1}')
	lnsl=$(echo ${lstrx} | awk -vFS="#" '{print $2}')
	ldat=$(echo ${lstrx} | awk -vFS="#" '{print $3}')
	llat=$(echo ${lstrx} | awk -vFS="#" '{print $4}')
	llon=$(echo ${lstrx} | awk -vFS="#" '{print $5}')
	ldep=$(echo ${lstrx} | awk -vFS="#" '{print $6}')
	lmag=$(echo ${lstrx} | awk -vFS="#" '{print $7}')
	lbaz=$(echo ${lstrx} | awk -vFS="#" '{print $8}')
	ldst=$(echo ${lstrx} | awk -vFS="#" '{print $9}')
	lf0w=$(echo ${lstrx} | awk -vFS="#" '{print $10}')
	lam1=$(echo ${lstrx} | awk -vFS="#" '{print $11}')
	lam2=$(echo ${lstrx} | awk -vFS="#" '{print $12}')
	lsnr=$(echo ${lstrx} | awk -vFS="#" '{print $13}')
	lres=$(echo ${lstrx} | awk -vFS="#" '{print $14}')
	echo ${lstrx}
	echo "${lidv}" "${lnsl}" "${ldat}" "${llat}" "${llon}" "${ldep}" "${lmag}" "${lbaz}" "${ldst}" \
	"${lf0w}" "${lam1}" "${lam2}" "${lsnr}" "${lres}" | awk '
	{
		idv = $1; nsl = sprintf("%-14s", $2); dat = $3; lat = sprintf("%8.5f", $4); lon = sprintf("%9.5f", $5)
		dep = sprintf("%6.1f", $6); mag = sprintf("%3.1f", $7); baz = sprintf("%3d", $8); dst = sprintf("%6.1f", $9)
		if ($10) {f0w = sprintf("%5.2f", $10)} else {f0w = "-"}
		if ($11) {am1 = sprintf("%5.2f", $11)} else {am1 = "-"}
		if ($12) {am2 = sprintf("%5.2f", $12)} else {am2 = "-"}
		if ($13) {snr = sprintf("%4.1f", $13)} else {snr = "-"}
		res = sprintf("%d", $14)
		print idv, nsl, dat, lat, lon, dep, mag, baz, dst, f0w, am1, am2, snr, res
	}
	' >>${lfile}
	return $?
}
# -------------------------------------------------------------------------------------------------------------------------------
flist_hdr()
{
	local lfile=$1
	[ -z "${lfile}" ] && return 1
	echo "#date f0_wins num_wins amin amax" >${lfile}; return $?
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_eqk_output()
{
	local ldirx lgcfg lpars lflag
	ldirx=$1; lgcfg=$2; lpars=$3

	local lfcoor lfparm lfcall lfevtz lfevt0
	local lnet lsta lloc lstr lsrc lfrm lfrn lsn1 lsn2 lscall
	local lnsls lnslx lfxall lrep

	local lfilerm lhmap lhmap0 lxcrds llatSx llonSx
	local lfmean lfmeax lfinfo lhmean lneqk ltmpt
	local lf0wins lf0s lf0savg lf0avg la0avg

	local lftype lfgrid

	local lerr lerx
	((lerr=0))

	[ -z "${lgcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }

	lfevtz=${ldirx}/${g_file_evts_resp}; lfcoor=${ldirx}/${g_dir_files}/${g_file_coord}
	lfparm=${ldirx}/${g_dir_files}/${g_file_parm_eqk}; lfcall=${ldirx}/${g_dir_files}/${g_file_args}

	# -----------------------------------------------------------------------------------------------------------------------
	lftype=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype")
	lfgrid=$(get_par_tab "${lgcfg}" "g_cfg_fgrid")

	lscall=$(cat ${lfcall})
	lnet=$(get_par_tab "${lscall}" ${g_info_net})
	lsta=$(get_par_tab "${lscall}" ${g_info_sta})
	lstr=$(get_par_tab "${lscall}" ${g_info_str})
	lsrc=$(get_par_tab "${lscall}" ${g_info_src})
	lfrm=$(get_par_tab "${lscall}" ${g_info_frm})
	lfrn=$(get_par_tab "${lscall}" ${g_info_frn})
	lsn1=$(get_par_tab "${lpars}" ${g_info_sn1}); lsn1=$(echo ${lsn1} | awk '{printf "%.1f", $1}')
	# lsn2=$(get_par_tab "${lpars}" ${g_info_sn2})

	# -----------------------------------------------------------------------------------------------------------------------
	ldout=$(mkdir_hveqk ${ldirx} ${lsn1}) || return 1
	echo -e "\noutput will be created in ${ldout}\n"

	lnsls=$(awk -vFS="#" -vOFS=. -vs=${lstr} '{print $1, $2, $3, s}' ${lfcoor} | sort -u)
	lfevt0=${ldout}/${g_file_evts_resp}
	# -----------------------------------------------------------------------------------------------------------------------
	if [ ! -z "${lpars}" ]; then
		echo "selecting events..."
		hv_eqk_select ${ldirx} ${ldout} "${lpars}"; ((lerr=$?))
	else
		echo "copying..."
		# maybe this copy is better in hv_eqk_select
		fevts_hdr ${lfevt0}; awk '$NF == 0' ${lfevtz} >>${lfevt0}
		# for lnslx in ${lnsls}
		# do
		# 	lfxall=${ldirx}/${g_eqk_fxall//@nslc@/${lnslx}}; cp ${lfxall} ${ldout}; ((lerr+=$?))
		# done
		for lnslx in ${lnsls}
		do
			lfxall=${ldirx}/${g_eqk_fxall//@nslc@/${lnslx}}; [ -f ${lfxall} ] && { cp ${lfxall} ${ldout}; ((lerr+=$?)); }
		done
	fi
	# -----------------------------------------------------------------------------------------------------------------------
	[ ${lerr} -eq 0 ] && >${ldout}/${g_eqk_ok}
	# directory files; we insert in g_file_args only the fields of interest
	if [ ${lerr} -eq 0 ]; then
		mkdir ${ldout}/${g_dir_files} && cp ${lfcoor} ${lfparm} ${ldout}/${g_dir_files} && \
		mkargs_hveqk ${lfcall} ${ldout}/${g_dir_files}/${g_file_args}; ((lerr=$?))
	fi

	[ ${lerr} -eq 0 ] && { gpparms=$(get_gp_params ${lfparm}); ((lerr=$?)); }

	if [ ${lerr} -eq 0 ]; then

		# averages and reports
		for lnslx in ${lnsls}
		do
			# error on lnslx
			((lerx=0))
			echo -e "\nprocessing ${lnslx}"

			lloc=$(echo ${lnslx} | cut -d. -f3); lfilerm=${ldout}/${g_eqk_frm//@nslc@/${lnslx}}
			lfxall=${ldout}/${g_eqk_fxall//@nslc@/${lnslx}}; lfxtmp=${ldout}/${g_eqk_fxcln//@nslc@/${lnslx}}
			lhmap0=${ldout}/${g_eqk_map0//@nslc@/${lnslx}}; lhmapt=${ldout}/${g_eqk_mapt//@nslc@/${lnslx}}
			lf0s=${ldout}/${g_eqk_ff0s//@nslc@/${lnslx}}
			lfmean=${ldout}/${g_eqk_mean//@nslc@/${lnslx}}; lfmeax=${ldout}/${g_eqk_mean_smooth//@nslc@/${lnslx}}
			lfinfo=${ldout}/${g_eqk_info//@nslc@/${lnslx}}; lrep=${ldout}/${g_eqk_rep//@nslc@/${lnslx}}
			lhmean=${ldout}/${g_eqk_img_mean//@nslc@/${lnslx}}; lhmean=${lhmean//@ityp@/${lftype}}
			lhmap=${ldout}/${g_eqk_img_map//@nslc@/${lnslx}}; lhmap=${lhmap//@ityp@/${lftype}}

			# retrieve number of events
			lneqk=$(awk -vn=${lnslx} '!/^#/ && $2==n' ${lfevt0} | awk 'END {print NR}')
			echo "${lneqk} events to be used"
			if [ ${lneqk} -ge 1 -a -s ${lfxall} ]; then

				# map ----------------------------------------------------------------------------------------------------------
				echo "map..."
				awk -vn=${lnslx} '!/^#/ && $2==n {print $4, $5, $6, $7}' ${lfevt0} | sort -u >${lfilerm}
				lxcrds=$(awk -vFS="#" -vl=${lloc} '$3==l {print $4, $5, $6}' ${lfcoor})
				llatSx=$(echo ${lxcrds} | awk '{print $1}'); llonSx=$(echo ${lxcrds} | awk '{print $2}')
				maps -s${lnslx} -L${llatSx} -l${llonSx} -o${lhmap0} -e${lfilerm} -g${lfgrid}; ((lerx=$?))
				if [ ${lerx} -eq 0 ]; then
					if [ ${lftype} == "${IMG_TYPE_PNG}" ]; then
						convert -density 300 -trim ${lhmap0} ${lhmap}
					else
						ps2pdf ${lhmap0} ${lhmapt} && pdfcrop ${lhmapt} ${lhmap} 1>/dev/null
					fi
					((lerx=$?))
					rm -f ${lhmapt} ${lhmap0}
				fi

				# average ------------------------------------------------------------------------------------------------------
				awk '/^$/ {print $0} !/^$/ {print $2, $3, $4}' ${lfxall} >${lfxtmp}
				if [ -s ${lfxtmp} ]; then
					echo "average..."
					mean_hv ${lfxtmp} ${lfmean} && gp_smooth ${lfmean} ${lfmeax} && \
					lf0savg=$(f0s_from_average ${lfmeax} ${EQK_MIN_FREQ}) && \
					lf0avg=$(echo ${lf0savg} | awk 'NR==1 {print $1}') && \
					la0avg=$(echo ${lf0savg} | awk 'NR==1 {print $2}'); ((lerx+=$?))
				else
					echo -e "\nno data found in ${lfxall}"; ((lerx+=1))
				fi

				# f0 from windows ----------------------------------------------------------------------------------------------
				awk -vn=${lnslx} '!/^#/ && $2==n {print $10}' ${lfevt0} >${lf0s}
				[ -s ${lf0s} ] && { lf0wins=$(f0_from_windows ${lf0s}); ((lerx+=$?)); }

				# infos --------------------------------------------------------------------------------------------------------
				echo "collecting info..."
				echo "# general information" >${lfinfo}
				add_pars_file ${lfinfo} ${g_info_net} "${lnet}" ${g_info_sta} "${lsta}" ${g_info_loc} "${lloc}"
				add_pars_file ${lfinfo} ${g_info_str} "${lstr}" ${g_info_nsl} "${lnslx}" ${g_info_mrf} "${EQK_MIN_FREQ}"
				add_pars_file ${lfinfo} ${g_info_src} "${lsrc}" ${g_info_frm} "${lfrm}" ${g_info_frn} "${lfrn}"
				hv_eqk_info ${lfinfo} ${lnslx} ${lfevt0}; ((lerx+=$?))
				add_pars_file ${lfinfo} ${g_info_sn1} "${lsn1}"
				# add_pars_file ${lfinfo} ${g_info_sn2} "${lsn2}"
				add_pars_file ${lfinfo} ${g_info_f0w} "${lf0wins}"
				add_pars_file ${lfinfo} ${g_info_f01} "${lf0avg}" ${g_info_a01} "${la0avg}"
				echo "${gpparms}" >>${lfinfo}

				# header hv ----------------------------------------------------------------------------------------------------
				[ ${lerx} -eq 0 ] && { hv_eqk_header ${lfinfo} ${lfmean}; ((lerx+=$?)); }

				# plot ---------------------------------------------------------------------------------------------------------
				if [ ${lerx} -eq 0 ]; then
					echo "plot..."
					ltmpt="HVSR ${lnslx} on ${lneqk} earthquakes - minimum SNR ${lsn1}"
					plot_hveqk ${lfmean} ${lfmeax} ${lfxtmp} ${lhmean} "${ltmpt}" "H/V amplitude" "${lgcfg}"; ((lerx+=$?))
				fi

				# report -------------------------------------------------------------------------------------------------------
				if [ ${lerx} -eq 0 ]; then
					echo "report..."; hv_eqk_report ${lfinfo} ${lhmap} ${lhmean} ${lrep} "${lgcfg}"; ((lerx+=$?))
				fi
				
				# clean --------------------------------------------------------------------------------------------------------
				rm -f ${lfilerm} ${lf0s} ${lfxtmp}
				
			else
				echo -e "\nno data found in ${lfxall} and/or ${lfevt0}"
			fi
			((lerr+=${lerx}))
		done
	fi
	# -----------------------------------------------------------------------------------------------------------------------

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_eqk_all()
{
	local ldirx=$1 lgcfg=$2

	local lfevtz lsevtz levtx ldevx ldevs lfilex lsnrx lnrows ljtmp
	local lnsls lnslx lfxall
	local lerr; ((lerr=0))

	[ -z "${ldirx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -d ${ldirx} ] || { echo "${FUNCNAME}: directory ${ldirx} does not exist" >/dev/stderr; return 1; }

	lfevtz=${ldirx}/${g_file_evts_resp}; ldevs=${ldirx}/${g_dir_evts}
	# this check is probably redundant
	[ ! -s ${lfevtz} -o ! -d ${ldevs} ] && { echo "${FUNCNAME}: directory ${ldirx} is not valid" >/dev/stderr; return 1; }
	# -----------------------------------------------------------------------------------------------------------------------
	lsevtz=$(awk '!/^#/ && $NF == 0' ${lfevtz})
	lnrows=$(echo -n "${lsevtz}" | awk 'END {print NR}')
	lnsls=$(echo "${lsevtz}" | awk '{print $2}' | sort -u)
	# creates overall files
	echo "creation of cumulative files..."
	for lnslx in ${lnsls}; do lfxall=${ldirx}/${g_eqk_fxall//@nslc@/${lnslx}}; >${lfxall}; done
	for ljtmp in $(seq 1 ${lnrows})
	do
		levtx=$(echo "${lsevtz}" | awk -vj=${ljtmp} 'NR==j')
		ldevx=$(echo ${levtx} | awk '{print $1}'); lnslx=$(echo ${levtx} | awk '{print $2}')
		lfxall=${ldirx}/${g_eqk_fxall//@nslc@/${lnslx}}; lfilex=${ldevs}/${ldevx}/${g_dir_hv}/${lnslx}.hv
		if [ -s ${lfilex} ]; then
			lsnrx=$(echo ${levtx} | awk '{print $(NF-1)}')
			awk -vs="${lsnrx}" -vi="${ldevx}" '!/^#/ && !/^$/ {print i, $1, $2, s} END {print ""}' ${lfilex} >>${lfxall}
			echo -ne "\r\e[Kadded event ${ldevx} (${lnslx})"
		else
			echo -e "\n${FUNCNAME}: file ${lfilex} does not exist or is empty" >/dev/stderr
		fi
	done
	echo
	# -----------------------------------------------------------------------------------------------------------------------
	[ ${lerr} -eq 0 ] && >${ldirx}/${g_eqk_ok}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_eqk_select()
{
	local ldirx ldout lpars
	ldirx=$1; ldout=$2; lpars=$3

	local lnsls lnslx lfidvs lfall0 lfallq lfevtz lfevt0
	local ls1 ls2 lm1 lm2 lp1 lp2 ld1 ld2 lb1 lb2 la1 la2 lts lstry lstrz
	local ljtmp lntmp ltmp1 ltmp2 lrow

	local lerr; ((lerr=0))

	[ -z "${ldout}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -d ${ldirx} ] || { echo "${FUNCNAME}: directory ${ldirx} does not exist" >/dev/stderr; return 1; }
	mkdir -p ${ldout} || return 1
	[ ${ldout} -ef ${ldirx} ] && { echo "${FUNCNAME}: input and output directory are the same"; return 1; }

	lfevtz=${ldirx}/${g_file_evts_resp}
	# maybe this check is redundant
	[ ! -s ${lfevtz} ] && { echo "${FUNCNAME}: directory ${ldirx} is not valid" >/dev/stderr; return 1; }

	# composes the string for selection -------------------------------------------------------------------------------------
	if [ ! -z "${lpars}" ]; then
		ls1=$(get_par_tab "${lpars}" ${g_info_sn1}); ls2=$(get_par_tab "${lpars}" ${g_info_sn2})
		lm1=$(get_par_tab "${lpars}" ${g_info_mg1}); lm2=$(get_par_tab "${lpars}" ${g_info_mg2})
		lp1=$(get_par_tab "${lpars}" ${g_info_dp1}); lp2=$(get_par_tab "${lpars}" ${g_info_dp2})
		ld1=$(get_par_tab "${lpars}" ${g_info_ds1}); ld2=$(get_par_tab "${lpars}" ${g_info_ds2})
		lb1=$(get_par_tab "${lpars}" ${g_info_bz1}); lb2=$(get_par_tab "${lpars}" ${g_info_bz2})
		la1=$(get_par_tab "${lpars}" ${g_info_am1}); la2=$(get_par_tab "${lpars}" ${g_info_am2})
		lts=$(get_par_tab "${lpars}" ${g_info_tmi} | xargs -n2)
	fi

	lstry='!/^#/'
	# this should be in an appropriate function
	[ ! -z "${ls1}" ] && { chk_snr ${ls1} && lstry="${lstry} && \$(NF-1)>=${ls1}" || ((lerr+=1)); }
	[ ! -z "${ls2}" ] && { chk_snr ${ls2} && lstry="${lstry} && \$(NF-1)<=${ls2}" || ((lerr+=1)); }
	[ ! -z "${lp1}" ] && { chk_dep ${lp1} && lstry="${lstry} && \$6>=${lp1}" || ((lerr+=1)); }
	[ ! -z "${lp2}" ] && { chk_dep ${lp2} && lstry="${lstry} && \$6<=${lp2}" || ((lerr+=1)); }
	[ ! -z "${lm1}" ] && { chk_mag ${lm1} && lstry="${lstry} && \$7>=${lm1}" || ((lerr+=1)); }
	[ ! -z "${lm2}" ] && { chk_mag ${lm2} && lstry="${lstry} && \$7<=${lm2}" || ((lerr+=1)); }
	[ ! -z "${lb1}" ] && { chk_baz ${lb1} && lstry="${lstry} && \$8>=${lb1}" || ((lerr+=1)); }
	[ ! -z "${lb2}" ] && { chk_baz ${lb2} && lstry="${lstry} && \$8<=${lb2}" || ((lerr+=1)); }
	[ ! -z "${ld1}" ] && { chk_dst ${ld1} && lstry="${lstry} && \$9>=${ld1}" || ((lerr+=1)); }
	[ ! -z "${ld2}" ] && { chk_dst ${ld2} && lstry="${lstry} && \$9<=${ld2}" || ((lerr+=1)); }
	[ ! -z "${la1}" ] && { chk_amp ${la1} && lstry="${lstry} && \$11>=${la1}" || ((lerr+=1)); }
	[ ! -z "${la2}" ] && { chk_amp ${la2} && lstry="${lstry} && \$12<=${la2}" || ((lerr+=1)); }
	[ ! -z "${lp1}" -a ! -z "${lp2}" -a ${lerr} -eq 0 ] && { chk_due ${lp1} ${lp2} "depth"; ((lerr+=$?)); }
	[ ! -z "${lm1}" -a ! -z "${lm2}" -a ${lerr} -eq 0 ] && { chk_due ${lm1} ${lm2} "magnitude"; ((lerr+=$?)); }
	[ ! -z "${lb1}" -a ! -z "${lb2}" -a ${lerr} -eq 0 ] && { chk_due ${lb1} ${lb2} "back-azimuth"; ((lerr+=$?)); }
	[ ! -z "${ld1}" -a ! -z "${ld2}" -a ${lerr} -eq 0 ] && { chk_due ${ld1} ${ld2} "distance"; ((lerr+=$?)); }
	[ ! -z "${la1}" -a ! -z "${la2}" -a ${lerr} -eq 0 ] && { chk_due ${la1} ${la2} "amplitude"; ((lerr+=$?)); }

	lntmp=$(echo -n "${lts}" | awk 'END {print NR}')
	for ljtmp in $(seq 1 ${lntmp})
	do
		lrow=$(echo "${lts}" | awk -vj=${ljtmp} 'NR==j')
		ltmp1=$(echo ${lrow} | awk '{print $1}'); ltmp1=$(date +"${DFMT}" -d${ltmp1}).000000
		ltmp2=$(echo ${lrow} | awk '{print $2}'); ltmp2=$(date +"${DFMT}" -d${ltmp2}).000000
		[ ! -z "${lstrz}" ] && lstrz="${lstrz} || "
		lstrz="${lstrz}\"${ltmp1}\"<=\$3 && \$3<=\"${ltmp2}\""
	done
	[ ! -z "${lstrz}" ] && lstry="${lstry} && (${lstrz})"
	echo "${lpars}" >${ldout}/${g_file_params}
	lstry="${lstry} && \$NF==0"
	# selection of events and overall files ---------------------------------------------------------------------------------
	lfevt0=${ldout}/${g_file_evts_resp}; fevts_hdr ${lfevt0}
	# events to be included
	awk ''"${lstry}"'' ${lfevtz} >>${lfevt0}
	lnsls=$(awk '!/^#/ {print $2}' ${lfevt0} | sort -u)
	for lnslx in ${lnsls}
	do
		lfall0=${ldirx}/${g_eqk_fxall//@nslc@/${lnslx}}; lfallq=${ldout}/${g_eqk_fxall//@nslc@/${lnslx}}
		lfidvs=${ldout}/${g_eqk_idtmp//@nslc@/${lnslx}}; lfallt=${ldout}/${g_eqk_fxtmp//@nslc@/${lnslx}}
		awk -vs=${lnslx} '$2==s {print "^"$1" "}' ${lfevt0} >${lfidvs}; echo "^$" >>${lfidvs}
		grep -f ${lfidvs} ${lfall0} >${lfallt}
		awk 'BEGIN {f=0} {if ($0=="") {f+=1} else {f=0}; if (f<=1) {print}}' ${lfallt} >${lfallq}
		rm -f ${lfidvs} ${lfallt}
	done
	# -----------------------------------------------------------------------------------------------------------------------

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_noise_output()
{
	local ldirx lgcfg lpars
	ldirx=$1; lgcfg=$2; lpars=$3
	[ -z "${lgcfg}" ] && { echo "${FUNCNAME}: missing arguments" >/dev/stderr; return 1; }

	local lnsls lnslx
	local ldfls lfcall lscall lfcoor lfparm ldhv
	local lamp1 lamp2
	local lnet lsta lloc lstr ldrq lhms ldtq lsrc lfrm
	local lfxall lflist lfxtmp lfmean lffigc lffigb lrep
	local lf0wins lf0savg lfinfo lf0avg la0avg lmrelf
	local lqta ltot
	local lftype
	local lerr lerx
	((lerr=0))

	lftype=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype")

	ldfls=${ldirx}/${g_dir_files}; lfcoor=${ldfls}/${g_file_coord}
	lfcall=${ldfls}/${g_file_args}; lfparm=${ldfls}/${g_file_parm_noise}

	lscall=$(cat ${lfcall})
	lnet=$(get_par_tab "${lscall}" ${g_info_net})
	lsta=$(get_par_tab "${lscall}" ${g_info_sta})
	lstr=$(get_par_tab "${lscall}" ${g_info_str})
	ldrq=$(get_par_tab "${lscall}" ${g_info_drt})
	lhms=$(get_par_tab "${lscall}" ${g_info_hms})
	lsrc=$(get_par_tab "${lscall}" ${g_info_src})
	lfrm=$(get_par_tab "${lscall}" ${g_info_frm})

	lamp1=$(get_par_tab "${lpars}" ${g_info_am1}); lamp2=$(get_par_tab "${lpars}" ${g_info_am2})
	[ -z "${lpars}" ] && ldout=${ldirx} || { ldout=$(mkdir_hvnoise ${ldirx} ${lamp1} ${lamp2}) || return 1; }
	echo "output will be created in ${ldout}"

	lnsls=$(awk -vFS="#" -vOFS=. -vs=${lstr} '{print $1, $2, $3, s}' ${lfcoor} | sort -u)

	# maybe this check is better in hv_noise_select -------------------------------------------------------------------------
	if [ ! -z "${lpars}" ]; then
		# ldirx and ldout are not the same, by setting
		hv_noise_select ${ldirx} ${ldout} "${lpars}"; ((lerr=$?))
	fi
	[ ${lerr} -eq 0 ] && >${ldout}/${g_noise_ok}
	# directory files; we insert in g_file_args only the fields of interest
	if [ ${lerr} -eq 0 -a ! -z "${lpars}" ]; then
		mkdir ${ldout}/${g_dir_files} && cp ${lfcoor} ${lfparm} ${ldout}/${g_dir_files} && \
		mkargs_hvnoise ${lfcall} ${ldout}/${g_dir_files}/${g_file_args}; ((lerr=$?))
	fi

	[ ${lerr} -eq 0 ] && { gpparms=$(get_gp_params ${lfparm}); ((lerr=$?)); }
	
	# -----------------------------------------------------------------------------------------------------------------------
	if [ ${lerr} -eq 0 ]; then
		for lnslx in ${lnsls}
		do
			# -----------------------------------------------------------------------------------------------------------------
			((lerx=0))
			echo -e "\nprocessing ${lnslx}"
			lloc=$(echo ${lnslx} | awk -vFS="." '{print $3}')
			lfxall=${ldout}/${g_noise_fxall//@nslc@/${lnslx}}; lflist=${ldout}/${g_noise_flist//@nslc@/${lnslx}}
			lfxtmp=${ldout}/${g_noise_fxcln//@nslc@/${lnslx}}; lfinfo=${ldout}/${g_noise_info//@nslc@/${lnslx}}
			lfmean=${ldout}/${g_noise_mean//@nslc@/${lnslx}}; lf0s=${ldout}/${g_noise_ff0s//@nslc@/${lnslx}}
			lrep=${ldout}/${g_noise_rep//@nslc@/${lnslx}}
			lffigc=${ldout}/${g_noise_img_all//@nslc@/${lnslx}}; lffigc=${lffigc//@ityp@/${lftype}}
			lffigb=${ldout}/${g_noise_img_mean//@nslc@/${lnslx}}; lffigb=${lffigb//@ityp@/${lftype}}

			if [ ! -s ${lflist} ]; then
				((lqta=0))
			else
				lqta=$(awk '!/^#/' ${lflist} | awk 'END {print NR}')
				ldtq=$(awk '!/^#/ {print $1}' ${lflist} | sort -u | head -n1)
			fi

			if [ ${lqta} -ge 1 -a -s ${lfxall} ]; then

				echo -e "${lqta} days to be used"

				# average ------------------------------------------------------------------------------------------------------
				awk '/^$/ {print $0} !/^$/ {print $2, $3, $4, $5}' ${lfxall} >${lfxtmp}
				if [ -s ${lfxtmp} ]; then
					echo "average..."
					mean_hp ${lfxtmp} ${lfmean} && \
					lmrelf=$(min_reliable_freq_noise ${lstr}) && \
					lf0savg=$(f0s_from_average ${lfmean} ${lfrelf}) && \
					lf0avg=$(echo ${lf0savg} | awk 'NR==1 {print $1}') && \
					la0avg=$(echo ${lf0savg} | awk 'NR==1 {print $2}'); ((lerx+=$?))
				else
					echo "no data found in ${lfxall}"; ((lerx+=1))
				fi

				# f0 from windows ----------------------------------------------------------------------------------------------
				awk '!/^#/ {print $2}' ${lflist} >${lf0s}
				[ -s ${lf0s} ] && { lf0wins=$(f0_from_windows ${lf0s}); ((lerx+=$?)); }

				# total number of windows --------------------------------------------------------------------------------------
				ltot=$(awk 'BEGIN {s = 0} !/^#/ {s += $3} END {print s}' ${lflist})

				# infos --------------------------------------------------------------------------------------------------------
				echo "collecting info..."
				echo "# general information" >${lfinfo}
				add_pars_file ${lfinfo} ${g_info_net} "${lnet}" ${g_info_sta} "${lsta}" ${g_info_loc} "${lloc}"
				add_pars_file ${lfinfo} ${g_info_mrf} "${lmrelf}" ${g_info_str} "${lstr}" ${g_info_nsl} "${lnslx}"
				add_pars_file ${lfinfo} ${g_info_dt1} "${ldtq}" ${g_info_hms} "${lhms}"
				add_pars_file ${lfinfo} ${g_info_dys} "${lqta}" ${g_info_wns} "${ltot}"
				add_pars_file ${lfinfo} ${g_info_drt} "${ldrq}" ${g_info_f0w} "${lf0wins}" ${g_info_f01} "${lf0avg}"
				add_pars_file ${lfinfo} ${g_info_a01} "${la0avg}" ${g_info_src} "${lsrc}" ${g_info_frm} "${lfrm}"
				echo "${gpparms}" >>${lfinfo}

				# header hv ----------------------------------------------------------------------------------------------------
				[ ${lerx} -eq 0 ] && { hv_noise_header ${lfinfo} ${lfmean}; ((lerx+=$?)); }

				# plot ---------------------------------------------------------------------------------------------------------
				if [ ${lerx} -eq 0 ]; then
					echo "plot..."
					plot_hvnoisec ${lfxall} ${lfmean} ${lnslx} ${lffigc} ${lmrelf} "${lgcfg}" && \
					plot_hvnoiseb ${lfxtmp} ${lfmean} ${lnslx} ${lffigb} ${lmrelf} "${lgcfg}"
					((lerx+=$?))
				fi

				# report -------------------------------------------------------------------------------------------------------
				if [ ${lerx} -eq 0 -a ${lqta} -gt 1 ]; then
					echo "report..."
					hv_noise_report ${lfinfo} ${lffigc} ${lffigb} ${lrep} "${lgcfg}"
					((lerx+=$?))
				fi				

				# clean --------------------------------------------------------------------------------------------------------
				rm -f ${lf0s} ${lfxtmp}

			else
				# echo "no data found in ${lfxall} and/or ${lflist}"
				echo "no data found"
			fi

			((lerr+=${lerx}))
			# ----------------------------------------------------------------------------------------------------------------------
		done
	fi

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_noise_all()
{
	local ldirx=$1 lgcfg=$2
	[ -z "${ldirx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -d ${ldirx} ] || { echo "${FUNCNAME}: directory ${ldirx} does not exist" >/dev/stderr; return 1; }

	local lnsls lnslx lstr ln0w lstp
	local ldfls lfcall lfcoor ldhv
	local lscall
	local lfall0 lflist
	local lfilez lfilex lfile0 lf0win lnwins lyear ljday ldtk ldtj llims
	
	local lerr
	((lerr=0))

	ldfls=${ldirx}/${g_dir_files}; lfcoor=${ldfls}/${g_file_coord}; lfcall=${ldfls}/${g_file_args}; ldhv=${ldirx}/${g_dir_hv}
	# this check is probably redundant
	[ -d ${ldfls} -a -s ${lfcoor} -a -s ${lfcall} -a -d ${ldhv} ] || \
	{ echo "${FUNCNAME}: directory ${ldirx} is not valid" >/dev/stderr; return 1; }

	lscall=$(cat ${lfcall})
	lstr=$(get_par_tab "${lscall}" ${g_info_str}) && ln0w=$(get_par_tab "${lscall}" ${g_info_n0w}) && \
	lstp=$(get_par_tab "${lscall}" ${g_info_stp}); ((lerr=$?))

	if [ ${lerr} -eq 0 ]; then
		lnsls=$(awk -vFS="#" -vOFS=. -vs=${lstr} '{print $1, $2, $3, s}' ${lfcoor} | sort -u)
		echo "creation of cumulative files"
		for lnslx in ${lnsls}
		do
			# -----------------------------------------------------------------------------------------------------------------
			lfall0=${ldirx}/${g_noise_fxall//@nslc@/${lnslx}}; lflist=${ldirx}/${g_noise_flist//@nslc@/${lnslx}}
			unset ldtk; >${lfall0}; flist_hdr ${lflist}
			# creates overall hv file and list file
			# sorts files by date
			lfilez=$(find ${ldhv} -name "${lnslx}.????.???.hv" | sort)
			for lfilex in ${lfilez}
			do
				if [ -f ${lfilex} -a -s ${lfilex} ]; then
					lfile0=$(basename ${lfilex}); echo -ne "\r\e[Kprocessing ${lfile0}"
					lf0win=$(awk '/f0 from windows/ {print $(NF-2)}' ${lfilex} | tail -n1); lf0win=${lf0win:-"-"}
					lnwins=$(awk 'BEGIN {IGNORECASE = 1} /Number of windows =/ {printf "%d", $NF}' ${lfilex} | tail -n1)
					lyear=$(echo ${lfile0} | awk -vFS="." '{print $5}'); ljday=$(echo ${lfile0} | awk -vFS="." '{printf "%d", $6}')
					llims=$(hv_min_max ${lfilex}); ldtj=$(date -u +"${DFMD}" -d "${lyear}-01-01 utc +$((ljday-1))days")
					if [ ${lnwins} -ge ${ln0w} -a ${lnwins} -ge 1 ]; then
						# --------------------------------------------------------------------------------------------------------
						[ ! -z "${ldtk}" ] && { ldtt=$(d_diffd ${ldtj} ${ldtk}); [ ${ldtt} -gt ${lstp} ] && echo >>${lfall0}; }
						ldtk=${ldtj}
						# --------------------------------------------------------------------------------------------------------
						awk -vd=${ldtj} -vn=${lnwins} '!/^#/ {print d, $1, $2, sqrt($4/$3), n}' ${lfilex} >>${lfall0}
						echo >>${lfall0}
						# --------------------------------------------------------------------------------------------------------
						echo ${ldtj} ${lf0win} ${lnwins} ${llims} | \
						awk -vf="${FMT_LIST_NOISE}\n" '{printf f, $1, $2, $3, $4, $5}' >>${lflist}
					fi
				fi
			done
			# -----------------------------------------------------------------------------------------------------------------
			echo
		done
	fi
	[ ${lerr} -eq 0 ] && >${ldirx}/${g_noise_ok}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_noise_select()
{
	local ldirx ldout lpars
	ldirx=$1; ldout=$2; lpars=$3
	[ -z "${ldout}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -d ${ldirx} ] || { echo "${FUNCNAME}: directory ${ldirx} does not exist" >/dev/stderr; return 1; }
	[ -d ${ldout} ] || { echo "${FUNCNAME}: directory ${ldirx} does not exist" >/dev/stderr; return 1; }

	local lstry lstrz
	local lnsls lnslx lstr
	local ldfls lfcoor lfcall lscall
	local la1 la2 lts llims ltmp lntmp ljtmp
	local lfall0 lflist lfallq lflisq lfdates lfallt

	local lerr
	((lerr=0))

	ldfls=${ldirx}/${g_dir_files}; lfcoor=${ldfls}/${g_file_coord}; lfcall=${ldfls}/${g_file_args}
	# maybe this check is redundant
	[ -d ${ldfls} -a -s ${lfcoor} -a -s ${lfcall} ] || \
	{ echo "${FUNCNAME}: directory ${ldirx} is not valid" >/dev/stderr; return 1; }

	echo "selecting days..."
	lscall=$(cat ${lfcall}); lstr=$(get_par_tab "${lscall}" ${g_info_str})

	# composes the string for selection -------------------------------------------------------------------------------------
	lstry="!/^$/ && !/^#/"
	if [ ! -z "${lpars}" ]; then
		la1=$(get_par_tab "${lpars}" ${g_info_am1}); la2=$(get_par_tab "${lpars}" ${g_info_am2})
		lts=$(get_par_tab "${lpars}" ${g_info_tmi} | xargs -n2)
	fi
	[ ! -z "${la1}" ] && { chk_amp ${la1} && lstry="${lstry} && \$(NF-1)>=${la1}" || ((lerr+=1)); }
	[ ! -z "${la2}" ] && { chk_snr ${la2} && lstry="${lstry} && \$NF<=${la2}" || ((lerr+=1)); }
	[ ! -z "${la1}" -a ! -z "${la2}" -a ${lerr} -eq 0 ] && { chk_due ${la1} ${la2} "amplitude"; ((lerr+=$?)); }
	lntmp=$(echo -n "${lts}" | awk 'END {print NR}')
	for ljtmp in $(seq 1 ${lntmp})
	do
		lrow=$(echo "${lts}" | awk -vj=${ljtmp} 'NR==j')
		ltmp1=$(echo ${lrow} | awk '{print $1}'); ltmp1=$(date +"${DFMD}" -d${ltmp1})
		ltmp2=$(echo ${lrow} | awk '{print $2}'); ltmp2=$(date +"${DFMD}" -d${ltmp2})
		[ ! -z "${lstrz}" ] && lstrz="${lstrz} || "
		lstrz="${lstrz}\"${ltmp1}\"<=\$1 && \$1<=\"${ltmp2}\""
	done
	[ ! -z "${lstrz}" ] && lstry="${lstry} && (${lstrz})"
	# -----------------------------------------------------------------------------------------------------------------------
	echo "${lpars}" >${ldout}/${g_file_params}
	lnsls=$(awk -vFS="#" -vOFS=. -vs=${lstr} '{print $1, $2, $3, s}' ${lfcoor} | sort -u)
	for lnslx in ${lnsls}
	do
		lfall0=${ldirx}/${g_noise_fxall//@nslc@/${lnslx}}; lflist=${ldirx}/${g_noise_flist//@nslc@/${lnslx}}
		lfallq=${ldout}/${g_noise_fxall//@nslc@/${lnslx}}; lflisq=${ldout}/${g_noise_flist//@nslc@/${lnslx}}
		flist_hdr ${lflisq} && awk ''"${lstry}"'' ${lflist} >>${lflisq}
		lfdates=${ldout}/${g_noise_dstmp//@nslc@/${lnslx}}; lfallt=${ldout}/${g_noise_fxtmp//@nslc@/${lnslx}}
		awk '!/^#/ {print "^"$1" "}' ${lflisq} >${lfdates}; echo "^$" >>${lfdates}
		grep -f ${lfdates} ${lfall0} >${lfallt}
		awk 'BEGIN {f=0} {if ($0=="") {f+=1} else {f=0}; if (f<=2) {print}}' ${lfallt} >${lfallq}
		rm -f ${lfdates} ${lfallt}
	done
	# -----------------------------------------------------------------------------------------------------------------------
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
plot_hveqk()
{

	local lftxt0 lfmean lfahv0 lftxt lfahv lfout ltitl lylbl lgcfg
	lftxt0=$1; lfmean=$2; lfahv0=$3; lfout=$4; ltitl=$5; lylbl=$6; lgcfg=$7

	local ldtmp lfplot lterm lfont lfmean lfminp lfminm
	local l_A1 l_A2 l_A12 lyscale lymin lymax ly0min ly0max lftype

	local lerr lstrx
	((lerr=0))

	[ -z "${lylbl}" ] && { echo -e "${FUNCNAME}: wrong number of arguments"; return 1; }
	ldtmp=$(mktemp -dp$(dirname ${lfout}) ${FUNCNAME}.XXXXXX) || return 1

	lyscale=$(get_par_tab "${lgcfg}" "g_cfg_plot_yscale")
	lftype=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype")
	lymin=$(get_par_tab "${lgcfg}" "g_cfg_plot_ymin")
	lymax=$(get_par_tab "${lgcfg}" "g_cfg_plot_ymax")

	lftxt=${ldtmp}/mean_hv.txt; lfahv=${ldtmp}/all_hv.txt
	awk 'BEGIN {IGNORECASE = 1} !/nan/ && !/^#/ {print}' ${lftxt0} >${lftxt}
	awk 'BEGIN {IGNORECASE = 1} !/nan/ && !/^#/ {print}' ${lfahv0} >${lfahv}

	# minimum and maximum amplitude
	l_A12=$(hv_min_max_round ${lfmean})
	l_A1=$(echo ${l_A12} | awk '{print $1}'); l_A2=$(echo ${l_A12} | awk '{print $2}')

	lterm=$(get_setting ${lftype} "terminal"); lfont=$(get_setting ${lftype} "fontterm")

	lfplot=${ldtmp}/plot.txt

	echo "set term "${lterm}" font '"${lfont}"'" >${lfplot}
	echo "set lmargin at screen 0.12; set rmargin at screen 0.85; set bmargin at screen 0.15; set tmargin at screen 0.9" \
	>>${lfplot}
	echo "set palette defined ${SNR_CMAP}" >>${lfplot}
	# x ------------------------------------------------------------------------------------------------------
	echo "set logscale x" >>${lfplot}
	echo "unset xtics" >>${lfplot}
	echo "set xtics out" >>${lfplot}
	echo "set xtics add (${EQK_FTICS})" >>${lfplot}
	echo "set mxtics 10" >>${lfplot}
	echo "set xrange [ ${EQK_MIN_FREQ} : ${EQK_MAX_FREQ} ]" >>${lfplot}
	# y ------------------------------------------------------------------------------------------------------
	echo "unset ytics" >>${lfplot}
	echo "set ytics out" >>${lfplot}
	[ ${lyscale} == "${E_YSCALE_LOG}" ] && \
	{ ly0min=${E_MIN_AMPL_LOG}; ly0max=${E_MAX_AMPL_LOG}; } || \
	{ ly0min=${E_MIN_AMPL_LIN}; ly0max=${E_MAX_AMPL_LIN}; }
	[ -z "${lymin}" ] && lymin=${l_A1}; lymin=$(echo ${lymin} ${ly0min} | awk '{print ($1<$2) ? $2 : $1}')
	[ -z "${lymax}" ] && lymax=${l_A2}; lymax=$(echo ${lymax} ${ly0max} | awk '{print ($1<$2) ? $1 : $2}')
	[ $(echo ${lymin} ${lymax} | awk '{print $1<$2}') -eq 0 ] && lymax=$(echo ${lymin} | awk '{print $1+1}')
	echo "set yrange [ ${lymin} : ${lymax} ]" >>${lfplot}
	[ ${lyscale} == "${E_YSCALE_LOG}" ] && \
	echo "set logscale y; set ytics add (${E_YTICS_LOG}, ${l_A2}); set mytics 10" >>${lfplot} || \
	echo "unset logscale y; set ytics add (${E_YTICS_LIN}, ${l_A2}); set mytics 2" >>${lfplot}
	# --------------------------------------------------------------------------------------------------------
	echo "unset logscale cb; set cbrange [ ${EQK_SN_MIN} : ${EQK_SN_MAX} ]" >>${lfplot}
	echo "set xlabel 'Frequency (Hz)' font '"$(get_setting ${lftype} "fontlabel")"'" >>${lfplot}
	echo "set cblabel 'SNR' font '"$(get_setting ${lftype} "fontclabel")"'" >>${lfplot}
	echo "set ylabel '${lylbl}' font '"$(get_setting ${lftype} "fontlabel")"'" >>${lfplot}
	echo "set grid behind ls 1 lw 0.5 lc 'black'" >>${lfplot}
	echo "set grid mxtics; set grid mytics" >>${lfplot}
	echo "set title '${ltitl}' font '"$(get_setting ${lftype} "fonttitle")"'" >>${lfplot}
	echo "set output '${lfout}'" >>${lfplot}
	lstrx="'${lfahv}' u 1:2:3 w l lw 0.3 palette t 'All'"
	lstrx=${lstrx}", '${lfmean}' u 1:4 w l lc 'blue' lw 2 t 'mean smooth+std'"
	lstrx=${lstrx}", '${lfmean}' u 1:3 w l lc 'blue' lw 2 t 'mean smooth-std'"
	lstrx=${lstrx}", '${lfmean}' u 1:2 w l lc 'blue' lw 5 t 'mean smooth'"
	echo "plot ${lstrx}" >>${lfplot}; echo "quit" >>${lfplot}

	gnuplot ${lfplot}; ((lerr=$?))

	rm -rf ${ldtmp}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
min_reliable_freq_noise()
{
	local lstr=$1
	[ -z "${lstr}" ] && { echo -e "${FUNCNAME}: wrong number of arguments"; return 1; }
	local lx=${lstr:0:1}; lstr=${lstr:-F}
	[ ! -z "$(echo FCHB | grep ${lx})" ] && echo ${NOISE_MIN_FREQ} || echo ${NOISE_MIN_FREK}
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
plot_hvnoiseb()
{
	local lfhv lfmean lnsl lfigb lnminf lgcfg
	lfhv=$1; lfmean=$2; lnsl=$3; lfigb=$4; lnminf=$5; lgcfg=$6

	local lerr
	((lerr=0))

	local lyscale lyrange lxscale lfscale lftype
	local lymin lymax ly0min ly0max
	local ldtmp l_A1 l_A2 l_A12
	local lplotb lstrx lterm lfont

	[ -z "${lnminf}" ] && { echo -e "${FUNCNAME}: wrong number of arguments"; return 1; }
	ldtmp=$(mktemp -dqp$(dirname ${lfigb}) ${FUNCNAME}.XXXXXX) || return 1

	lyscale=$(get_par_tab "${lgcfg}" "g_cfg_plot_yscale")
	lymin=$(get_par_tab "${lgcfg}" "g_cfg_plot_ymin")
	lymax=$(get_par_tab "${lgcfg}" "g_cfg_plot_ymax")
	lxscale=$(get_par_tab "${lgcfg}" "g_cfg_plot_xscale")
	lfscale=$(get_par_tab "${lgcfg}" "g_cfg_plot_fscale")
	lftype=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype")

	lplotb=${ldtmp}/plotb
	
	# minimum and maximum amplitude
	l_A12=$(hv_min_max_round ${lfmean} ${lnminf})
	l_A1=$(echo ${l_A12} | awk '{print $1}'); l_A2=$(echo ${l_A12} | awk '{print $2}')

	# term
	lterm=$(get_setting ${lftype} "terminal"); lfont=$(get_setting ${lftype} "fontterm")

	echo "set term "${lterm}" font '"${lfont}"'" >${lplotb}
	echo "set output '${lfigb}'" >>${lplotb}
	echo "set lmargin at screen 0.12; set rmargin at screen 0.9; set bmargin at screen 0.15; set tmargin at screen 0.9" \
	>>${lplotb}
	# x ---------------------------------------------------------------------------------------------------------------------
	echo "set xrange [ ${lnminf} : ${NOISE_MAX_FREQ} ]" >>${lplotb}
	echo "unset xtics; set xtics out" >>${lplotb}
	[ ${lxscale} == "${N_XSCALE_LOG}" ] && \
	echo "set logscale x; set xtics add (${N_FTICS_LOG}); set mxtics 10" >>${lplotb} || \
	echo "unset logscale x; set xtics add (${N_FTICS_LIN}); set mxtics 2" >>${lplotb}
	# y ---------------------------------------------------------------------------------------------------------------------
	echo "unset ytics; set ytics out" >>${lplotb}
	[ ${lyscale} == "${N_YSCALE_LOG}" ] && \
	{ ly0min=${N_MIN_AMPL_LOG}; ly0max=${N_MAX_AMPL_LOG}; } || \
	{ ly0min=${N_MIN_AMPL_LIN}; ly0max=${N_MAX_AMPL_LIN}; }
	[ -z "${lymin}" ] && lymin=${l_A1}; lymin=$(echo ${lymin} ${ly0min} | awk '{print ($1<$2) ? $2 : $1}')
	[ -z "${lymax}" ] && lymax=${l_A2}; lymax=$(echo ${lymax} ${ly0max} | awk '{print ($1<$2) ? $1 : $2}')
	[ $(echo ${lymin} ${lymax} | awk '{print $1<$2}') -eq 0 ] && lymax=$(echo ${lymin} | awk '{print $1+1}')
	echo "set yrange [ ${lymin} : ${lymax} ]" >>${lplotb}
	[ ${lyscale} == "${N_YSCALE_LOG}" ] && \
	echo "set logscale y; set ytics add (${N_YTICS_LOG}, ${l_A2}); set mytics 10" >>${lplotb} || \
	echo "unset logscale y; set ytics add (${N_YTICS_LIN}, ${l_A2}); set mytics 2" >>${lplotb}
	# -----------------------------------------------------------------------------------------------------------------------
	echo "set xlabel 'Frequency (Hz)' font '"$(get_setting ${lftype} "fontlabel")"'" >>${lplotb}
	echo "set ylabel 'Amplitude' font '"$(get_setting ${lftype} "fontlabel")"'" >>${lplotb}
	echo "set title 'H/V Noise ${lnsl}' font '"$(get_setting ${lftype} "fonttitle")"'" >>${lplotb}
	echo "set grid behind ls 1 lw 0.5 lc 'black'" >>${lplotb}
	echo "set grid mxtics; set grid mytics" >>${lplotb}
	lstrx="plot '${lfhv}' using 1:2 with lines lc 'black' lw 1 t 'all'"
	if [ -s ${lfmean} ]; then
		lstrx=${lstrx}", '${lfmean}' using 1:2 with lines lc 'red' lw 2 t 'mean'"
		lstrx=${lstrx}", '${lfmean}' using 1:3 with lines lc 'red' lw 1 t 'mean-std'"
		lstrx=${lstrx}", '${lfmean}' using 1:4 with lines lc 'red' lw 1 t 'mean+std'"
	fi
	echo "${lstrx}" >>${lplotb}
	echo "quit" >>${lplotb}

	gnuplot ${lplotb}; ((lerr+=$?))
	# -----------------------------------------------------------------------------------------------------------------------
	rm -rf ${ldtmp}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
plot_hvnoisec()
{
	local lfdhv lfmean lnsl lfigc lnminf lgcfg
	lfdhv=$1; lfmean=$2; lnsl=$3; lfigc=$4; lnminf=$5; lgcfg=$6

	local lerr
	((lerr=0))

	local lcscale lcrange lfscale lftype
	local lcbmin lcbmax lcb0min lcb0max
	local ldtmp llims l_d l_D l_A1 l_A2 l_A12
	local lplotc lstrx lterm lfont

	[ -z "${lnminf}" ] && { echo -e "${FUNCNAME}: wrong number of arguments"; return 1; }
	ldtmp=$(mktemp -dqp$(dirname ${lfigc}) ${FUNCNAME}.XXXXXX) || return 1

	lcscale=$(get_par_tab "${lgcfg}" "g_cfg_plot_cbscale")
	lcbmin=$(get_par_tab "${lgcfg}" "g_cfg_plot_cbmin")
	lcbmax=$(get_par_tab "${lgcfg}" "g_cfg_plot_cbmax")
	lfscale=$(get_par_tab "${lgcfg}" "g_cfg_plot_fscale")
	lftype=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype")

	lplotc=${ldtmp}/plotc

	# minimum and maximum amplitude
	l_A12=$(hv_min_max_round ${lfmean} ${lnminf})
	l_A1=$(echo ${l_A12} | awk '{print $1}'); l_A2=$(echo ${l_A12} | awk '{print $2}')

	# term
	lterm=$(get_setting ${lftype} "terminal"); lfont=$(get_setting ${lftype} "fontterm")

	# time range
	llims=$(awk '!/nan/ && !/^#/ && !/^$/' ${lfdhv} | \
	awk 'NR==1 {d=$1; D=$1} {if ($1<d) {d=$1} else if ($1>D) {D=$1}} END {print d, D}')
	l_d=$(echo ${llims}|awk '{print $1}'); l_D=$(echo ${llims}|awk '{print $2}')
	[ "${l_d}" = "${l_D}" ] && ((lerr=1))

	# -------------------------------------------------------------------------------------------------------------------------
	if [ ${lerr} -eq 0 ]; then

		echo "set term "${lterm}" font '"${lfont}"'" >${lplotc}
		echo "set output '${lfigc}'" >>${lplotc}
		echo "set lmargin at screen 0.1; set rmargin at screen 0.85; set bmargin at screen 0.15; set tmargin at screen 0.9" \
		>>${lplotc}
		echo "set pm3d map" >>${lplotc}
		echo "unset key" >>${lplotc}
		echo "set multiplot" >>${lplotc}
		echo "set palette defined ${MATLAB_CMAP}" >>${lplotc}
		echo "set grid front ls 1 lw 0.5 lc 'black'" >>${lplotc}
		echo "set grid mxtics; set grid mytics" >>${lplotc}
		echo "set tics in" >>${lplotc}

		# x ------------------------------------------------------------------------------------------------------------------
		echo "unset logscale x" >>${lplotc}
		echo "set xdata time; set timefmt \"${DFMP}\"; set format x \"${DFMD}\"" >>${lplotc}
		echo "set xrange [ \"${l_d}\" : \"${l_D}\" ]" >>${lplotc}
		echo "set xtics font '"$(get_setting ${lftype} "fontxtics")"' rotate by 30; set mxtics" >>${lplotc}
		# y ------------------------------------------------------------------------------------------------------------------
		echo "unset mytics" >>${lplotc}
		echo "set yrange [ ${lnminf} : ${NOISE_MAX_FREQ} ]" >>${lplotc}
		[ ${lfscale} == "${N_FSCALE_LOG}" ] && \
		echo "set logscale y; set ytics add (${N_FTICS_LOG}); set mytics 10" >>${lplotc} || \
		echo "unset logscale y; set ytics add (${N_FTICS_LIN}); set mytics 2" >>${lplotc}
		# c ------------------------------------------------------------------------------------------------------------------
		echo "unset cbtics" >>${lplotc}
		echo "set cbtics nomirror" >>${lplotc}
		[ ${lcscale} == "${N_CBSCALE_LOG}" ] && \
		{ lcb0min=${N_MIN_AMPL_LOG}; lcb0max=${N_MAX_AMPL_LOG}; } || \
		{ lcb0min=${N_MIN_AMPL_LIN}; lcb0max=${N_MAX_AMPL_LIN}; }
		[ -z "${lcbmin}" ] && lcbmin=${l_A1}; lcbmin=$(echo ${lcbmin} ${lcb0min} | awk '{print ($1<$2) ? $2 : $1}')
		[ -z "${lcbmax}" ] && lcbmax=${l_A2}; lcbmax=$(echo ${lcbmax} ${lcb0max} | awk '{print ($1<$2) ? $1 : $2}')
		[ $(echo ${lcbmin} ${lcbmax} | awk '{print $1<$2}') -eq 0 ] && lcbmax=$(echo ${lcbmin} | awk '{print $1+1}')
		echo "set cbrange [ ${lcbmin} : ${lcbmax} ]" >>${lplotc}
		[ ${lcscale} == "${N_CBSCALE_LOG}" ] && \
		echo "set logscale cb; set cbtics add (${N_YTICS_LOG}, ${l_A2}); set mcbtics 10" >>${lplotc} || \
		echo "unset logscale cb; set cbtics add (${N_YTICS_LIN}, ${l_A2}); set mcbtics 2" >>${lplotc}
		# --------------------------------------------------------------------------------------------------------------------

		echo "set xlabel 'Time' font '"$(get_setting ${lftype} "fontlabel")"'" >>${lplotc}
		echo "set ylabel 'Frequency (Hz)' font '"$(get_setting ${lftype} "fontlabel")"'" >>${lplotc}
		echo "set cblabel 'H/V amplitude' font '"$(get_setting ${lftype} "fontclabel")"'" >>${lplotc}
		echo "set title 'H/V Noise ${lnsl} from ${l_d} to ${l_D}' font '"$(get_setting ${lftype} "fonttitle")"'" >>${lplotc}
		echo "splot '${lfdhv}' using 1:2:3" >>${lplotc}
		echo "unset multiplot" >>${lplotc}
		echo "quit" >>${lplotc}

		gnuplot ${lplotc}; ((lerr+=$?))
	fi
	# -------------------------------------------------------------------------------------------------------------------------
	rm -rf ${ldtmp}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
maps()
{
	# llist columns are: lat, lon, dep, mag
	local lstaz lstla lstlo lfout llist lfgrd llisq
	local OPTIND OPTARG
	while getopts :s:L:l:o:e:f:g: OPZ
	do
		case $OPZ in
			s) lstaz=${OPTARG} ;;
			L) lstla=${OPTARG} ;;
			l) lstlo=${OPTARG} ;;
			o) lfout=${OPTARG} ;;
			e) llist=${OPTARG} ;;
			f) llisq=${OPTARG} ;;
			g) lfgrd=${OPTARG} ;;
			?) echo -e "${FUNCNAME}: invalid option -${OPTARG}"; return 1 ;;
		esac
	done

	local ldtmp lfmap lcpt
	local lmargin lticks ltickz lwidth lwidtk
	local lstax

	# additional space at the edges of the map with respect to the limits determined by station and events
	lmargin=0.2
	# number of intervals in the colormap, number of sub-intervals in one interval in the colormap
	lticks=5; ltickz=5
	# number of intervals in coordinate ticks
	ltickw=5
	# map width(s)
	lwidth=12c; lwidtk=3c

	local lrange lrance lx llims llim1 llim2 lRMAP lRMAQ lRMAZ ltick ltich ltikk lPAL lneqk lmrng lmag0
	local lstrx

	local lerr
	((lerr=0))

	[ -z "${llist}" -o -z "${lstaz}" -o -z "${lstla}" -o -z "${lstlo}" -o -z "${lfout}" ] && \
	{ echo -e "${FUNCNAME}: missing arguments"; return 1; }

	[ -f ${llist} -a -s ${llist} ] && [ -z "$(awk 'NF != 4' ${llist})" ] || \
	{ echo -e "${FUNCNAME}: file ${llist} does not exist or is empty"; return 1; }

	ldtmp=$(mktemp -dqp$(dirname ${lfout}) ${FUNCNAME}.XXXXXX) || return 1

	lfmap=${ldtmp}/rmap.txt; lcpt=${ldtmp}/cpt.cpt

	gmt set MAP_TITLE_OFFSET=0c
	gmt set FONT_TITLE=14p,Helvetica,black
	gmt set FONT_ANNOT_PRIMARY=10p,Helvetica,black
	gmt set FONT_LABEL=10p,Helvetica,black
	gmt set MAP_FRAME_WIDTH=0.1c
	gmt set MAP_LABEL_OFFSET=0.1c
	gmt set FONT_LABEL=10p
	gmt set MAP_TICK_LENGTH=0.1c
	gmt set MAP_TICK_PEN=0.3p
	gmt set MAP_FRAME_TYPE=fancy
	gmt set PS_PAGE_ORIENTATION=Portrait

	[ ! -z "${llisq}" ] && [ -f ${llisq} -a -s ${llisq} ] || llisq=""

	echo ${lstlo} ${lstla} >${lfmap}; awk '!/^#/ {print $2, $1}' ${llist} >>${lfmap}
	[ ! -z "${llisq}" ] && awk '!/^#/ {print $2, $1}' ${llisq} >>${lfmap}
	
	lRMAQ=$(awk '{print $1, $2}' ${lfmap} | gmt info -C -I.1 | awk -vs=${lmargin} '{print $1-s, $2+s, $3-s, $4+s}')
	lRMAQ=$(adjust_rmap ${lRMAQ})

	# ----------------------------------------------------------------------------------------------------------------------------
	# station, if the input one is of type net.sta
	lstax=$(echo ${lstaz} | awk -vFS='.' '{print $2}'); lstax=${lstax:-${lstaz}}
	
	# ----------------------------------------------------------------------------------------------------------------------------
	# region to represent on the map
	lRMAP=$(echo ${lRMAQ} | tr " " "/")

	# ----------------------------------------------------------------------------------------------------------------------------
	# depths palette
	llims=$(awk '!/^#/ {print $3}' ${llist} | gmt info -C -I1)
	# max depth, min depth; if max depth is 0 it is set to 1 so that lrange is at least 1
	llim2=$(echo ${llims} | awk '{if ($2 == 0) $2 = 1; print $2}'); llim1=$(echo ${llims} | awk '{print $1}')
	# palette limits, appropriately rounded
	lrange=$(echo ${#llim2} | awk '{print 10^($1-1)}'); llims=$(echo -e "${llim1}\n${llim2}" | gmt info -C -I${lrange})
	# if llims has width 0 (almost impossible) the upper limit is increased to avoid gmt going out of the pitcher
	[ $(echo ${llims} | awk '{print $1 - $2}') = "0" ] && llims=$(echo "${llims}" | awk -vi=${lrange} '{print $1, $2 + i}')
	# width of the intervals in the palette
	ltick=$(echo "${llims}" | awk -vn=${lticks} '{print ($2-$1)/n}')
	# width of the sub-intervals in the palette
	ltich=$(echo ${ltick} | awk -vn=${ltickz} '{print $1/n}')
	# color ranges of the palette; using ltich makes them aligned to the sub-intervals
	lPAL=$(echo "${llims}" | awk -vOFS="/" -vt=${ltich} '{print $1, $2, t}')
	# palette file
	gmt makecpt -Cseis -T${lPAL} >${lcpt}

	# ----------------------------------------------------------------------------------------------------------------------------
	# maximum between lat and lon ranges
	lrance=$(echo ${lRMAQ} | awk '{a = $2 - $1; if ($4 - $3 > a) a = $4 - $3; print a}')
	# coordinates ticks width
	[ -z "$(echo ${lrance} | awk '$1<1')" ] && lx=0.5 || lx=0.1
	# coordinates ticks
	ltikk=$(echo ${lrance} ${ltickw} | awk '{print $1/$2}' | gmt info -C -I${lx} | awk '{print $2}')
	# ----------------------------------------------------------------------------------------------------------------------------

	# ----------------------------------------------------------------------------------------------------------------------------
	# number of events
	lneqk=$(awk '!/^#/' ${llist} | awk 'END {print NR}')
	
	# ----------------------------------------------------------------------------------------------------------------------------
	# magnitude range and minimum magnitude
	lstrx=$(awk '!/^#/ {print $4}' ${llist} | gmt info -C)
	lmrng=$(echo ${lstrx} | awk '{print $1"-"$2}')
	lmag0=$(echo ${lstrx} | awk '{print $1}')
	# ----------------------------------------------------------------------------------------------------------------------------

	lstrx="Station ${lstaz}, ${lneqk} eqk in Mag. range ${lmrng}"
	gmt psbasemap -JM${lwidth} -R${lRMAP} -Ba${ltikk}f${ltikk}:"Lat":/a${ltikk}f${ltikk}:"Lon"::."${lstrx}":/WeSn \
	-Glightgray -Vn -K >${lfout}; ((lerr=$?))

	[ ${lerr} -eq 0 -a ! -z "${lfgrd}" -a -s "${lfgrd}" ] && \
	{ gmt grdimage ${lfgrd} -J -R -Cdem2 -K -O >>${lfout}; ((lerr=$?)); }

	[ ${lerr} -eq 0 ] && \
	gmt pscoast -J -R -A2 -Df -I1/1p,blue -I2/0.25p,blue -N1/0.25p,- -S52/152/219 -W1,30 -W0.3 -K -O >>${lfout} && \
	gmt psscale -C${lcpt} -Ba${ltick}f${ltick}g${ltich}:'Eqk depth (Km)': -Dx2.5i/-0.4i/8.00/0.5h -K -O -P >>${lfout} && \
	awk -vm=${lmag0} '!/^#/ {print $2, $1, $3, ($4-m)/3 + 0.1}' ${llist} | \
	gmt psxy -R -J -O -Sc -W.2,0/0/0 -C${lcpt} -K >>${lfout}; ((lerr+=$?))

	if [ ${lerr} -eq 0 ]; then
		lstrx="-R -J -St.5 -G244/0/161 -W2,50/50/250 -O -N -K"
		echo ${lstlo} ${lstla} | gmt psxy ${lstrx} >>${lfout}; ((lerr+=$?))
	fi
	if [ ${lerr} -eq 0 -a ! -z "${llisq}" ]; then
		awk '!/^#/ {print $2, $1}' ${llisq} | gmt psxy -R -J -O -Sd0.3 -W1 -Ggreen >>${lfout}; ((lerr+=$?))
	fi

	[ ${lerr} -eq 0 ] && \
	{ echo ${lstlo} ${lstla} ${lstax} | gmt pstext -R -J -D.1/0 -N -O -F+f12,Helvetica-Bold+jLB -K >>${lfout}; ((lerr+=$?)); }

	if [ ${lerr} -eq 0 ]; then
		lRMAZ=$(echo "${lRMAQ}" | awk -vOFS="/" -vm=2 \
		'{x=.5*($1+$2); y=.5*($3+$4); dx=$2-$1; dy=$4-$3; print x-m*dx, x+m*dx, y-m*dy, y+m*dy}')
		gmt set MAP_FRAME_TYPE=PLAIN; gmt set MAP_FRAME_WIDTH=3000
		gmt pscoast -R${lRMAZ} -JM${lwidtk} -W0.1,30 -W0.1 -Df -N1/0.25p,- -S255/255/255 -G100/100/100 -A2 -O -K >>${lfout} && \
		gmt psbasemap -JM -R -B50 -X0.01 -Y0.01 -O -K >>${lfout} && \
		echo "${lRMAQ}" | awk '{printf "%s %s\n%s %s\n%s %s\n%s %s\n%s %s", $1, $3, $1, $4, $2, $4, $2, $3, $1, $3}' | \
		gmt psxy -R -JM -W0.9,250/30/30 -O -N >>${lfout}
	fi

	rm -rf ${ldtmp}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
adjust_rmap()
{
	local lrmaq=$@
	local llatc llat1 llat2 lvlat lvlon lvrap ldlonx ldlatx ldrap ldlon0 ldlat0
	local lstmp lerr
	((lerr=0))

	llatc=$(echo ${lrmaq} | awk '{print $3+0.5*($4-$3)}')
	# unitary lat value in latc, even if substantially independent from latc
	llat1=$(echo ${llatc} | awk '{print $1-.5}'); llat2=$(echo ${llatc} | awk '{print $1+.5}')
	lvlat=$(echo 0 ${llat2} | gmt mapproject -G0/${llat1}+uk | awk '{print $NF}')
	# unitary lon value in latc
	lvlon=$(echo -.5 ${llatc} | gmt mapproject -G.5/${llatc}+uk | awk '{print $NF}')
	# auxiliary aspect ratio
	lvrap=$(echo ${lvlon} ${lvlat} | awk '{print $1/$2}')

	# aspect ratio coords
	ldlonx=$(echo ${lrmaq} | awk '{print $2-$1}'); ldlatx=$(echo ${lrmaq} | awk '{print $4-$3}')
	ldrap=$(echo ${ldlonx} ${ldlatx} | awk '{print $1/$2}')

	lstmp=$(echo ${lvrap} ${ldrap} ${map_ratio} | awk '$1*$2<$3')
	if [ ! -z "${lstmp}" ]; then
		ldlon0=$(echo ${lvrap} ${ldlatx} ${map_ratio} | awk '{print $2*$3/$1}')
		lrmaq=$(echo ${lrmaq} | awk -vd0=${ldlon0} -vdx=${ldlonx} '{ds = .5 * (d0 - dx); $1-=ds; $2+=ds; print}')
	else
		ldlat0=$(echo ${lvrap} ${ldlonx} ${map_ratio} | awk '{print $2*$1/$3}')
		lrmaq=$(echo ${lrmaq} | awk -vd0=${ldlat0} -vdx=${ldlatx} '{ds = .5 * (d0 - dx); $3-=ds; $4+=ds; print}')
	fi
	echo ${lrmaq}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
set_par_tab()
{
	local ltab=$1 lpar=$2 lval=$3
	# brutal but robust
	[ $(echo ${lpar} | awk '{print NF}') -ne 1 ] && \
	{ echo "${FUNCNAME}: wrong argument ${lpar}" >/dev/stderr; echo "${ltab}"; return 1; }
	ltab=$(echo "${ltab}" | awk -vp=${lpar} '$1 != p')
	[ -z "${ltab}" ] && echo "${lpar} ${lval}" || echo -e "${ltab}\n${lpar} ${lval}"
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
add_pars_file()
{
	local lfile=$1; local lpar lval lstr
	shift
	while [ $1 ]
	do
		lpar=$1; lval=$2
		# brutal but robust
		[ $(echo ${lpar} | awk '{print NF}') -ne 1 ] && { echo "${FUNCNAME}: wrong argument ${lpar}" >/dev/stderr; return 1; }
		lstr=$(echo -e "${lstr}\n${lpar} ${lval}")
		shift; shift
	done
	echo "${lstr:1}" >>${lfile}
	return $?
}
# -------------------------------------------------------------------------------------------------------------------------------
get_par_tab()
{
	local ltab=$1 lpar=$2
	[ -z "${lpar}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	# brutal but robust
	[ $(echo ${lpar} | awk '{print NF}') -ne 1 ] && { echo "${FUNCNAME}: wrong argument \"${lpar}\"" >/dev/stderr; return 1; }
	echo "${ltab}" | awk -vp=${lpar} '$1 == p {$1 = ""; print}' | tail -n1 | xargs
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
get_par_file()
{
	local lfile=$1 lpar=$2
	local lstrx
	[ -z "${lpar}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ ! -f "${lfile}" ] && { echo "${FUNCNAME}: file ${lfile} does not exist" >/dev/stderr; return 1; }
	# brutal but robust
	[ $(echo ${lpar} | awk '{print NF}') -ne 1 ] && { echo "${FUNCNAME}: wrong argument \"${lpar}\"" >/dev/stderr; return 1; }
	lstrx=$(awk -vp=${lpar} '$1 == p {$1 = ""; print}' ${lfile} | tail -n1 | xargs)
	echo ${lstrx}
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves some parameters from geopsy param file
get_gp_params()
{
	local lfparm=$1
	[ -z "${lfparm}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ ! -f ${lfparm} -o ! -s ${lfparm} ] && { echo -e "\nfile ${lfparm} does not exist or is empty" >/dev/stderr; return 1; }
	local lrow1 lrow2 lstr0 lparms lparm lstmp lxtmp lerr
	((lerr=0))
	lrow1=$(awk '/^# BEGIN PARAMETERS$/ {print NR}' ${lfparm} | tail -n1)
	lrow2=$(awk '/^# END PARAMETERS$/ {print NR}' ${lfparm} | tail -n1)
	[ -z ${lrow1} -o -z ${lrow2} ] && \
	{ echo -e "\nfile ${lparm} is not valid (\"BEGIN PARAMETERS\" and/or \"END PARAMETERS\")" >/dev/stderr; return 1; }

	lstr0=$(awk -vn1=${lrow1} -vn2=${lrow2} 'NR>n1 && NR<n2' ${lfparm}) && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^WINDOW_MIN_LENGTH/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_window_length} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^MINIMUM_FREQUENCY/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_freq_min} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^MAXIMUM_FREQUENCY/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_freq_max} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^SCALE_TYPE_FREQUENCY/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_freq_scale_type} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^STEP_TYPE_FREQUENCY/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_freq_step_type} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^SAMPLES_NUMBER_FREQUENCY/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_freq_num_samples} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^WINDOW_TYPE/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_taper_type} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^WINDOW_REVERSED/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_taper_rev} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^WINDOW_ALPHA/ {print $NF}' | tail -n1) && \
	lstmp=$(echo ${lstmp} | awk '{print $1/2*100}') && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_taper_width} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^SMOOTHING_METHOD/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_sm_method} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^SMOOTHING_WIDTH_TYPE/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_sm_width_type} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^SMOOTHING_WIDTH/ {print $NF}' | tail -n1) && \
	lstmp=$(echo ${lstmp} | awk '{print $1*100}') && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_sm_width} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^SMOOTHING_SCALE_TYPE/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_sm_scale_type} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^SMOOTHING_WINDOW_TYPE/ {print $NF}' | tail -n1) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_sm_win_type} "${lstmp}") && \
	lstmp=$(echo "${lstr0}" | awk -vFS="=" '/^HORIZONTAL_COMPONENTS/ {print $NF}' | tail -n1) && \
	lstmp=$(get_par_tab "${DESC_HOR_COMPS}" ${lstmp}) && \
	lxtmp=$(set_par_tab "${lxtmp}" ${gp_horiz_comp} "${lstmp}")
	((lerr=$?))

	[ ${lerr} -eq 0 ] && echo -e "\n# geopsy parameters\n${lxtmp}"

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# verifies that a noise output directory is suitable for filtering or retrieval
check_hvnoise_output()
{
	local ldir0=$1 lflag=$2
	[ -z "${ldir0}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -d ${ldir0} ] || { echo "${FUNCNAME}: directory ${ldir0} does not exist" >/dev/stderr; return 1; }

	local ldfls lfcoor lfcall lfcmdl lfpart ldhv
	local lnet lsta lstr lstp lprc ln0w lsrc
	local lnsls lnslx lfxall lflist lntmp
	local ltmp
	local lerr; ((lerr=0))

	# 0 stands for output/filter/merge, 1 for recovery
	[ "${lflag}" != "1" ] && ((lflag=0))

	echo "checking directory ${ldir0} ..."
	ldfls=${ldir0}/${g_dir_files}; lfcoor=${ldfls}/${g_file_coord}; lfcall=${ldfls}/${g_file_args}
	lfcmdl=${ldfls}/${g_file_cmd}; lfpart=${ldfls}/${g_file_parm_noise}; ldhv=${ldir0}/${g_dir_hv}

	# check files existence
	[ ! -d ${ldfls} ] && { echo "directory ${ldfls} is missing"; ((lerr+=1)); }
	[ ! -s ${lfcoor} ] && { echo "file ${lfcoor} is missing or empty"; ((lerr+=1)); }
	[ ! -s ${lfcall} ] && { echo "file ${lfcall} is missing or empty"; ((lerr+=1)); }
	[ ! -s ${lfpart} ] && { echo "file ${lfpart} is missing or empty"; ((lerr+=1)); }
	[ ! -d ${ldhv} -a ${lflag} -eq 1 ] && { echo "directory ${ldhv} is missing"; ((lerr+=1)); }

	# check parameters in call.txt file; maybe a function that checks the call file would be better?
	if [ ${lerr} -eq 0 ]; then
		lnet=$(get_par_file ${lfcall} ${g_info_net})
		[ -z "${lnet}" ] && { echo "parameter ${g_info_net} missing in ${lfcall}"; ((lerr+=1)); }
		lsta=$(get_par_file ${lfcall} ${g_info_sta})
		[ -z "${lsta}" ] && { echo "parameter ${g_info_sta} missing in ${lfcall}"; ((lerr+=1)); }
		lstr=$(get_par_file ${lfcall} ${g_info_str})
		[ -z "${lstr}" ] && { echo "parameter ${g_info_str} missing in ${lfcall}"; ((lerr+=1)); }
		lstp=$(get_par_file ${lfcall} ${g_info_stp})
		[ -z "${lstp}" ] && { echo "parameter ${g_info_stp} missing in ${lfcall}"; ((lerr+=1)); }
		lprc=$(get_par_file ${lfcall} ${g_info_prc})
		[ -z "${lprc}" ] && { echo "parameter ${g_info_prc} missing in ${lfcall}"; ((lerr+=1)); }
		ln0w=$(get_par_file ${lfcall} ${g_info_n0w})
		[ -z "${ln0w}" ] && { echo "parameter ${g_info_n0w} missing in ${lfcall}"; ((lerr+=1)); }
		lsrc=$(get_par_file ${lfcall} ${g_info_src})
		[ -z "${lsrc}" ] && { echo "parameter ${g_info_src} missing in ${lfcall}"; ((lerr+=1)); }
	fi

	# check that net and sta are correct in coord.txt file
	if [ ${lerr} -eq 0 ]; then
		ltmp=$(awk -vFS="#" -vn=${lnet} -vs=${lsta} '$1 != n || $2 != s' ${lfcoor})
		[ -z "${ltmp}" ] || { echo -e "coordinate file ${lfcoor} is not valid (net and/or sta)"; ((lerr+=1)); }
	fi

	# check that directory is "complete"
	if [ ${lerr} -eq 0 -a ${lflag} -eq 0 ]; then
		[ -f ${ldir0}/${g_noise_ok} ] || { echo "directory ${ldir0} appears to be incomplete"; ((lerr+=1)); }
	fi

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# verifies that an eqk output directory is suitable for filtering or retrieval
check_hveqk_output()
{
	local ldir0=$1 lflag=$2
	[ -z "${ldir0}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -d ${ldir0} ] || { echo "${FUNCNAME}: directory ${ldir0} does not exist" >/dev/stderr; return 1; }

	local ldfls lfcoor lfcall lfcmdl lfpart ldevt
	local lfxall lfevtz
	local lnet lsta lstr lsrc lnsls lnslx
	local ltmp lntmp
	local lerr; ((lerr=0))
	
	# 0 stands for output/filter/merge, 1 for recovery
	[ "${lflag}" != "1" ] && ((lflag=0))

	echo "checking directory ${ldir0} ..."

	ldfls=${ldir0}/${g_dir_files}; lfcoor=${ldfls}/${g_file_coord}; lfcall=${ldfls}/${g_file_args}
	lfcmdl=${ldfls}/${g_file_cmd}; lfpart=${ldfls}/${g_file_parm_eqk}; ldevt=${ldir0}/${g_dir_evts}
	lfevtz=${ldir0}/${g_file_evts_resp}

	# check files existence
	[ ! -d ${ldfls} ] && { echo "directory ${ldfls} is missing"; ((lerr+=1)); }
	[ ! -s ${lfcoor} ] && { echo "file ${lfcoor} is missing or empty"; ((lerr+=1)); }
	[ ! -s ${lfcall} ] && { echo "file ${lfcall} is missing or empty"; ((lerr+=1)); }
	# [ ! -s ${lfcmdl} ] && { echo "file ${lfcmdl} is missing or empty"; ((lerr+=1)); }
	[ ! -s ${lfpart} ] && { echo "file ${lfpart} is missing or empty"; ((lerr+=1)); }
	[ ! -s ${lfevtz} ] && { echo "file ${lfevtz} is missing or empty"; ((lerr+=1)); }
	[ ! -d ${ldevt} -a ${lflag} -eq 1 ] && { echo "directory ${ldevt} is missing"; ((lerr+=1)); }

	# check parameters in call.txt file
	if [ ${lerr} -eq 0 ]; then
		lnet=$(get_par_file ${lfcall} ${g_info_net})
		[ -z "${lnet}" ] && { echo "parameter ${g_info_net} missing in ${lfcall}"; ((lerr+=1)); }
		lsta=$(get_par_file ${lfcall} ${g_info_sta})
		[ -z "${lsta}" ] && { echo "parameter ${g_info_sta} missing in ${lfcall}"; ((lerr+=1)); }
		lstr=$(get_par_file ${lfcall} ${g_info_str})
		[ -z "${lstr}" ] && { echo "parameter ${g_info_str} missing in ${lfcall}"; ((lerr+=1)); }
		lsrc=$(get_par_file ${lfcall} ${g_info_src})
		[ -z "${lsrc}" ] && { echo "parameter ${g_info_src} missing in ${lfcall}"; ((lerr+=1)); }
	fi

	# check that net and sta are correct in coord.txt file
	if [ ${lerr} -eq 0 ]; then
		ltmp=$(awk -vFS="#" -vn=${lnet} -vs=${lsta} '$1 != n || $2 != s' ${lfcoor})
		[ -z "${ltmp}" ] || { echo -e "coordinate file ${lfcoor} is not valid (net and/or sta)"; ((lerr+=1)); }
	fi

	# check that net and sta are correct in evts_resp.txt file
	if [ ${lerr} -eq 0 ]; then
		ltmp=$(awk '!/^#/ && !/^$/ {print $2}' ${lfevtz} | \
		awk -vFS="." -vn=${lnet} -vs=${lsta} -vt=${lstr} '$1!=n || $2!=s || $4!=t')
		[ ! -z "${ltmp}" ] && { echo "some rows in file ${lfevtz} are not valid (net, sta, str)"; ((err+=1)); }
	fi

	# check that directory is "complete"
	if [ ${lerr} -eq 0 -a ${lflag} -eq 0 ]; then
		[ -f ${ldir0}/${g_eqk_ok} ] || { echo "directory ${ldir0} appears to be incomplete"; ((lerr+=1)); }
	fi

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
check_dfile()
{
	local lfile=$1
	local lrow ltmp ltmp1 ltmp2 lstrx lerr lerx
	[ -f ${lfile} -a -s ${lfile} ] || { echo -e "\nfile ${lfile} does not exist or is empty" >/dev/stderr; return 1; }
	[ -z "$(awk 'NF != 2' ${lfile})" ] || { echo "file ${lfile} is not valid" >/dev/stderr; return 1; }
	((lerr=0)); ((lerx=0))
	while read lrow
	do
		((lerx=0))
		ltmp1=$(date +"${DFMT}" -d$(echo ${lrow} | awk '{print $1}')) || ((lerx+=1))
		ltmp2=$(date +"${DFMT}" -d$(echo ${lrow} | awk '{print $2}')) || ((lerx+=1))
		if [ ${lerx} -eq 0 ]; then
			ltmp=$(echo ${ltmp1} ${ltmp2} | awk '$1 <= $2')
			[ -z "${ltmp}" ] && { echo "row ${lrow} in file ${lfile} is not valid" >/dev/stderr; ((lerx+=1)); } || \
			lstrx=$(echo -e "${lstrx}\n${ltmp}")
		fi
		((lerr+=${lerx}))
	done <${lfile}
	[ ${lerr} -eq 0 ] && echo "${lstrx:1}"
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_min_max_round()
{
	local lfile=$1 lminf=$2
	[ -z "${lfile}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfile} -a -s ${lfile} ] || \
	{ echo "${FUNCNAME}: file ${lfile} does not exist or is empty" >/dev/stderr; return 1; }
	local l_a1 l_a2
	lminf=${lminf:-0}
	l_a1=$(awk '!/^#/' ${lfile} | awk -vf=${lminf} '$1>=f {print $3}' | sort -n | awk 'NR==1' | \
	gmt info -C -I.1 | awk '{print $1}')
	l_a2=$(awk '!/^#/' ${lfile} | awk -vf=${lminf} '$1>=f {print $4}' | sort -n | awk 'END {print}' | \
	gmt info -C -I1 | awk '{print $2}')
	echo ${l_a1} ${l_a2}
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
hv_min_max()
{
	local lfilex=$1
	[ -z "${lfilex}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfilex} -a -s ${lfilex} ] || \
	{ echo "${FUNCNAME}: file ${lfilex} does not exist or is empty" >/dev/stderr; return 1; }
	awk '!/^#/ {print $2}' ${lfilex} | sort -n | awk 'NR==1 {print} END {print}' | xargs
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
init_cfg_hveqk()
{
	local lstrx
	lstrx=$(set_par_tab "${lstrx}" g_cfg_sn0 0)
	lstrx=$(set_par_tab "${lstrx}" g_cfg_plot_yscale ${E_YSCALE_LOG})
	lstrx=$(set_par_tab "${lstrx}" g_cfg_plot_ftype ${IMG_TYPE_PNG})
	echo "${lstrx}"
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
init_cfg_hvnoise()
{
	local lstrx
	lstrx=$(set_par_tab "${lstrx}" g_cfg_drt0 ${MAX_RECLEN})
	lstrx=$(set_par_tab "${lstrx}" g_cfg_step ${MIN_STEP})
	lstrx=$(set_par_tab "${lstrx}" g_cfg_perc 0)
	lstrx=$(set_par_tab "${lstrx}" g_cfg_plot_yscale ${N_YSCALE_LOG})
	lstrx=$(set_par_tab "${lstrx}" g_cfg_plot_cbscale ${N_CBSCALE_LOG})
	lstrx=$(set_par_tab "${lstrx}" g_cfg_plot_xscale ${N_XSCALE_LOG})
	lstrx=$(set_par_tab "${lstrx}" g_cfg_plot_fscale ${N_FSCALE_LOG})
	lstrx=$(set_par_tab "${lstrx}" g_cfg_plot_ftype ${IMG_TYPE_PNG})
	echo "${lstrx}"
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
parse_cfg_hvnoise()
{
	local lfcfg lc0 lc1 lstr lstz lerr lgcfg lstrx
	lfcfg=$1; lgcfg=$2; ((lerr=0))
	[ -z "${lfcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfcfg} ] || { echo "${FUNCNAME}: file ${lfcfg} does not exist" >/dev/stderr; return 1; }

	lc0=$(awk -vFS='[[:blank:]]*=[[:blank:]]*' '!/^#/ {gsub(/["\047;\\\t<>$*\+: ]/, ""); print}' ${lfcfg})
	lc1=$(awk -vFS='[[:blank:]]*=[[:blank:]]*' '!/^#/ {gsub(/["\047;\\\t<>$* ]/, ""); print}' ${lfcfg})
	
	lstrx="${lgcfg}"

	lst0="drt0 step perc plot_yscale plot_cbscale plot_xscale plot_fscale plot_ymax plot_ymin plot_cbmax plot_cbmin plot_ftype"
	lst0=$(echo ${lst0} | xargs -n1 | awk '{print "g_cfg_"$1}')
	for lstz in ${lst0}
	do
		lstr=$(echo "${lc0}" | awk -vFS== '/^'${lstz}'=/ {print $2}' | tail -n1)
		[ ! -z "${lstr}" ] && lstrx=$(set_par_tab "${lstrx}" ${lstz} ${lstr})
	done

	lstx="g_cfg_noise_rept"
	lstr=$(echo "${lc1}" | awk '/^'${lstx}'=/' | awk -vFS== 'END {print $2}')
	lstrx=$(set_par_tab "${lstrx}" ${lstx} ${lstr})

	[ ${lerr} -eq 0 ] && echo "${lstrx}"

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
check_cfg_hvnoise()
{
	local lgcfg lstr lstz lerr lerx
	lgcfg=$1; ((lerr=0))
	[ -z "${lgcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }

	echo "checking configuration..."

	lstr=$(get_par_tab "${lgcfg}" "g_cfg_drt0"); chk_drt ${lstr}; ((lerr+=$?))
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_step"); chk_stp ${lstr}; ((lerr+=$?))
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_perc"); chk_prc ${lstr}; ((lerr+=$?))

	((lerx=0))
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_plot_ymin")
	[ ! -z "${lstr}" ] && { chk_amp ${lstr}; ((lerx+=$?)); }
	lstz=$(get_par_tab "${lgcfg}" "g_cfg_plot_ymax")
	[ ! -z "${lstz}" ] && { chk_amp ${lstz}; ((lerx+=$?)); }
	[ ! -z "${lstr}" -a ! -z "${lstz}" -a ${lerx} -eq 0 ] && { chk_due ${lstr} ${lstz}; ((lerx+=$?)); }
	((lerr+=${lerx}))

	((lerx=0))
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_plot_cbmin")
	[ ! -z "${lstr}" ] && { chk_amp ${lstr}; ((lerx+=$?)); }
	lstz=$(get_par_tab "${lgcfg}" "g_cfg_plot_cbmax")
	[ ! -z "${lstz}" ] && { chk_amp ${lstz}; ((lerx+=$?)); }
	[ ! -z "${lstr}" -a ! -z "${lstz}" -a ${lerx} -eq 0 ] && { chk_due ${lstr} ${lstz}; ((lerx+=$?)); }
	((lerr+=${lerx}))

	lstr=$(get_par_tab "${lgcfg}" "g_cfg_noise_rept")
	if [ -z "${lstr}" ]; then
		echo -e "\nparameter g_cfg_noise_rept missing"; ((lerr+=1))
	elif [ ! -f ${lstr} -o ! -s ${lstr} ]; then
		echo -e "\nfile \"${lstr}\" to generate summary report is missing or empty"; ((lerr+=1))
	fi

	# image file type
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype"); chk_imgtype ${lstr}; ((lerr+=$?))

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
parse_cfg_hveqk()
{
	local lfcfg lgcfg lc0 lc1 lc2 lstr lstrx lstx lerr
	lfcfg=$1; lgcfg=$2; ((lerr=0))

	[ -z "${lfcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfcfg} ] || { echo "${FUNCNAME}: file ${lfcfg} does not exist" >/dev/stderr; return 1; }

	lc0=$(awk -vFS='[[:blank:]]*=[[:blank:]]*' '!/^#/ {gsub(/["\047;\\\t<>$*\+\-: ]/, ""); print}' ${lfcfg})
	lc1=$(awk -vFS='[[:blank:]]*=[[:blank:]]*' '!/^#/ {gsub(/["\047;\\\t<>$* ]/, ""); print}' ${lfcfg})
	lc2=$(awk '!/^#/ {gsub(/["\047;\\\t<>$* ]/, ""); print}' ${lfcfg})

	lstrx="${lgcfg}"

	for lstx in "g_cfg_fmodl3d" "g_cfg_fiasp91" "g_cfg_fgrid" "g_cfg_eqk_rept"
	do
		lstr=$(echo "${lc1}" | awk '/^'${lstx}'=/' | awk -vFS== 'END {print $2}')
		lstrx=$(set_par_tab "${lstrx}" ${lstx} ${lstr})
	done

	for lstx in "g_cfg_sn0" "g_cfg_plot_yscale" "g_cfg_plot_ymax" "g_cfg_plot_ymin" "g_cfg_plot_ftype"
	do
		lstr=$(echo "${lc2}" | awk '/^'${lstx}'=/' | awk -vFS== 'END {print $2}')
		[ ! -z "${lstr}" ] && lstrx=$(set_par_tab "${lstrx}" ${lstx} ${lstr})
	done
	
	[ ${lerr} -eq 0 ] && echo "${lstrx}"

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
check_cfg_hveqk()
{
	local lgcfg lstr lstx lerr lerx
	lgcfg=$1; ((lerr=0))

	[ -z "${lgcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }

	echo "checking configuration..."

	# csv file for 1d model
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_fmodl3d")
	if [ -z "${lstr}" ]; then
		echo -e "\nparameter g_cfg_fmodl3d missing"; ((lerr+=1))
	elif [ ! -f ${lstr} -o ! -s ${lstr} ]; then
		echo -e "\nfile \"${lstr}\" to build 1d model is missing or empty"; ((lerr+=1))
	fi
	# iasp file for 1d model
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_fiasp91")
	if [ -z "${lstr}" ]; then
		echo -e "\nparameter g_cfg_fiasp91 missing"; ((lerr+=1))
	elif [ ! -f ${lstr} -o ! -s ${lstr} ]; then
		echo -e "\nfile \"${lstr}\" to build 1d model is missing or empty"; ((lerr+=1))
	fi
	# grd file
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_fgrid")
	if [ -z "${lstr}" ]; then
		echo -e "\nwarning: parameter g_cfg_fgrid missing"
	elif [ ! -f ${lstr} -o ! -s ${lstr} ]; then
		echo -e "\nwarning: file \"${lstr}\" is missing or empty"
	fi
	# template file for summary report
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_eqk_rept")
	if [ -z "${lstr}" ]; then
		echo -e "\nparameter g_cfg_eqk_rept missing"; ((lerr+=1))
	elif [ ! -f ${lstr} -o ! -s ${lstr} ]; then
		echo -e "\nfile \"${lstr}\" to generate summary report is missing or empty"; ((lerr+=1))
	fi

	# minimum default snr
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_sn0"); chk_snr ${lstr} || ((lerr+=1))

	# plot parameters
	((lerx=0))
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_plot_ymin")
	[ ! -z "${lstr}" ] && { chk_amp ${lstr}; ((lerx+=$?)); }
	lstz=$(get_par_tab "${lgcfg}" "g_cfg_plot_ymax")
	[ ! -z "${lstz}" ] && { chk_amp ${lstz}; ((lerx+=$?)); }
	[ ! -z "${lstr}" -a ! -z "${lstz}" -a ${lerx} -eq 0 ] && { chk_due ${lstr} ${lstz}; ((lerx+=$?)); }
	((lerr+=${lerx}))

	# image file type
	lstr=$(get_par_tab "${lgcfg}" "g_cfg_plot_ftype"); chk_imgtype ${lstr}; ((lerr+=$?))

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
mkdir_hveqk()
{
	local ldirx lsnr
	local ldout lj
	ldirx=$1; lsnr=$2
	[ -z "${ldirx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -d ${ldirx} ] || { echo "${FUNCNAME}: ${ldirx} does not exist" >/dev/stderr; return 1; }
	[ -z "${lsnr}" ] && lsnr="0.0"
	((lj=1))
	ldout=${ldirx}/SNR-${lsnr}-$(echo ${lj} | awk '{printf "%03d", $1}')
	while [ -d ${ldout} ]; do ((lj+=1)); ldout=${ldirx}/SNR-${lsnr}-$(echo ${lj} | awk '{printf "%03d", $1}'); done
	mkdir ${ldout} && echo ${ldout}
	return $?
}
# -------------------------------------------------------------------------------------------------------------------------------
mkdir_hvnoise()
{
	local ldirx la1 la2
	local ldout lj
	ldirx=$1; la1=$2; la2=$3
	[ -z "${ldirx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -d ${ldirx} ] || { echo "${FUNCNAME}: ${ldirx} does not exist" >/dev/stderr; return 1; }
	((lj=1))
	ldout=${ldirx}/AMP-${la1}-${la2}-$(echo ${lj} | awk '{printf "%03d", $1}')
	while [ -d ${ldout} ]; do ((lj+=1)); ldout=${ldirx}/AMP-${la1}-${la2}-$(echo ${lj} | awk '{printf "%03d", $1}'); done
	mkdir ${ldout} && echo ${ldout}
	return $?
}
# -------------------------------------------------------------------------------------------------------------------------------
mkargs_hveqk()
{
	local lfile1 lfile2 lxpar lxval lerr
	lfile1=$1; lfile2=$2
	[ -z "${lfile2}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfile1} ] || { echo "${FUNCNAME}: ${lfile1} does not exist" >/dev/stderr; return 1; }
	for lxpar in ${g_info_net} ${g_info_sta} ${g_info_str} ${g_info_src} ${g_info_frm} ${g_info_frn}
	do
		lxval=$(get_par_file ${lfile1} ${lxpar}) && add_pars_file ${lfile2} ${lxpar} "${lxval}"; ((lerr+=$?))
	done
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
mkargs_hvnoise()
{
	local lfile1 lfile2 lxpar lxval lerr
	lfile1=$1; lfile2=$2
	[ -z "${lfile2}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfile1} ] || { echo "${FUNCNAME}: ${lfile1} does not exist" >/dev/stderr; return 1; }
	((lerr=0))
	for lxpar in ${g_info_net} ${g_info_sta} ${g_info_str} ${g_info_stp} ${g_info_hms} \
	${g_info_prc} ${g_info_n0w} ${g_info_src} ${g_info_drt} ${g_info_frm}
	do
		lxval=$(get_par_file ${lfile1} ${lxpar}) && add_pars_file ${lfile2} ${lxpar} "${lxval}"; ((lerr+=$?))
	done
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
