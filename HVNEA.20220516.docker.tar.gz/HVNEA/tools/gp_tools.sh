#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-05-16
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################

# to overwrite some parameters in the param.conf; perhaps these should be put elsewhere
GP_NOISE_MIN_F=0.1; GP_NOISE_MAX_F=15; GP_EQK_MIN_F=0.5; GP_EQK_MAX_F=15

# minimum and maximum duration that can be set for the noise window in the param conf
GP_NOISE_MIN_L=10; GP_NOISE_MAX_L=300

# length after zero fill
GP_EQK_MIN_L=60

# -------------------------------------------------------------------------------------------------------------------------------
# checks only WINDOW_OVERLAP and WINDOW_MIN_LENGTH for now
gp_check_param_noise_conf()
{
	local lfparm lstmp lerr lerrx
	lfparm=$1; ((lerr=0))
	[ -z "${lfparm}" ] && { echo "${FUNCNAME}: wrong number of arguments"; return 1; }
	local lovrx lwmin

	lstmp=$(gp_get_params ${lfparm}) || return 1
	
	((lerrx=0))
	lovrx=$(awk -vFS="=" '/^WINDOW_OVERLAP/ {print $NF}' ${lfparm} | tail -n1 | tr -d " \t" | awk '$1-0==$1 && $1>=0 && $1<100')
	[ -z "${lovrx}" ] && { ((lerrx+=1)); echo -e "\n${FUNCNAME}: ${lfparm} is not valid (par. WINDOW_OVERLAP)" >/dev/stderr; }
	((lerr+=${lerrx}))
	
	((lerrx=0))
	lwmin=$(awk -vFS="=" '/^WINDOW_MIN_LENGTH/ {print $NF}' ${lfparm} | tail -n1 | tr -d " \t" | awk '$1-0==$1')
	lwmin=$(echo ${lwmin} | awk -vw1=${GP_NOISE_MIN_L} -vw2=${GP_NOISE_MAX_L} '$1>=w1 && $1<=w2')
	[ -z "${lwmin}" ] && ((lerrx+=1)) && \
	echo -e "\n${FUNCNAME}: WINDOW_MIN_LENGTH in ${lfparm} must be between ${GP_NOISE_MIN_L} and ${GP_NOISE_MAX_L}" >/dev/stderr
	((lerr+=${lerrx}))

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_restyle_param_conf()
{
	# ldrt in questo caso si usa, in attesa di -load-windows
	local lparm lpart lf1 lf2 ldrt lcmp
	lparm=$1; lpart=$2; lf1=$3; lf2=$4; ldrt=$5; lcmp=$6; ((lerr=0))
	[ -z "${lf2}" ] && { echo "${FUNCNAME}: wrong number of arguments"; return 1; }
	[ ! -f ${lparm} -o ! -s ${lparm} ] && \
	{ echo -e "\n${FUNCNAME}: file ${lfparm} does not exist or is empty" >/dev/stderr; return 1; }
	local lstr0

	lstr0=$(gp_get_params ${lparm}); ((lerr=$?))

	if [ ${lerr} -eq 0 ]; then
		# overwrite
		lstr0=$(echo -e "${lstr0}\nMINIMUM_FREQUENCY=${lf1}")
		lstr0=$(echo -e "${lstr0}\nMAXIMUM_FREQUENCY=${lf2}")
		lstr0=$(echo -e "${lstr0}\nWINDOW_LENGTH_TYPE=exactly")
		if [ ! -z "${ldrt}" ]; then
			lstr0=$(echo -e "${lstr0}\nWINDOW_MIN_LENGTH(s)=${ldrt}")
			lstr0=$(echo -e "${lstr0}\nWINDOW_MAX_LENGTH(s)=${ldrt}")
			lstr0=$(echo -e "${lstr0}\nANTI-TRIGGERING_ON_RAW_SIGNAL (y/n)=n")
			lstr0=$(echo -e "${lstr0}\nANTI-TRIGGERING_ON_FILTERED_SIGNAL (y/n)=n")
		fi
		[ "${lcmp}" == "1" ] && lstr0=$(echo -e "${lstr0}\nHORIZONTAL_COMPONENTS=Squared")

		lstr0=$(echo "${lstr0}" | awk '!/^#/ && $1' | \
		awk -vFS="=" 'BEGIN {n=0} {if (!v[$1]) { i[n++]=$1 } v[$1]=$2} END {for (j=0;j<n;j++) print i[j]"="v[i[j]]}')

		echo -e "# BEGIN PARAMETERS\n#" >${lpart}
		echo "${lstr0}" >>${lpart}
		echo -e "#\n# END PARAMETERS" >>${lpart}
	fi

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_restyle_param_noise_conf()
{
	local lparm lpart lerr
	lparm=$1; lpart=$2; ((lerr=0))
	[ -z "${lpart}" ] && { echo "${FUNCNAME}: wrong number of arguments"; return 1; }
	gp_restyle_param_conf ${lparm} ${lpart} ${GP_NOISE_MIN_F} ${GP_NOISE_MAX_F}; ((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_restyle_param_eqk_conf()
{
	local lparm lpart lerr
	lparm=$1; lpart=$2; ((lerr=0))
	[ -z "${lpart}" ] && { echo "${FUNCNAME}: wrong number of arguments"; return 1; }
	gp_restyle_param_conf ${lparm} ${lpart} ${GP_EQK_MIN_F} ${GP_EQK_MAX_F} ${GP_EQK_MIN_L}; ((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_min_wins()
{
	local lfpart=$1 ldrt=$2 lmnp=$3
	local lerr
	[ -z "${lmnp}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lwmin lovrx ln0t ln0w
	((lerr=0))
	lwmin=$(awk -vFS="=" '/^WINDOW_MIN_LENGTH/ {print $NF}' ${lfpart} | tail -n1) && \
	lovrx=$(awk -vFS="=" '/^WINDOW_OVERLAP/ {print $NF}' ${lfpart} | tail -n1) && \
	lovrx=$(echo ${lwmin} ${lovrx} | awk '{print $2 / 100 * $1}') && \
	ln0t=$(echo ${ldrt} ${lwmin} ${lovrx} | awk '{printf "%d", ($1 - $3) / ($2 - $3)}') && \
	ln0w=$(echo ${lmnp} ${ln0t} | awk '{print int(0.01*$1*$2)}') && echo ${ln0w};
	((lerr=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_hv_sac()
{
	# lf1, lf2, lf3 are supposed to be valid sac files with identical kstnm and delta fields
	local lf1=$1 lf2=$2 lf3=$3 lfparm=$4 ldout=$5 lpref=$6
	[ -z "${lpref}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ ! -f ${lf1} -o ! -f ${lf2} -o ! -f ${lf3} ] && \
	{ echo -e "\n${FUNCNAME}: one or more files do not exist" >/dev/stderr; return 1; }
	local lsta lsps
	local lfwins lfhv lfout lflog ltmp lerr
	((lerr=0))
	lsta=$(od -An -w8 -v -c -j440 -N8 ${lf1} | tr -d " ")
	lsps=$(od -An -w4 -v -f -N4 ${lf1} | xargs | awk '{print 1/$1}')
	# echo -e "\n${FUNCNAME}: lsta ${lsta}, lsps ${lsps}" >/dev/stderr
	lfhv=${ldout}/${lsta}.hv; lfout=${ldout}/${lpref}.hv; lflog=${ldout}/${lpref}.log
	geopsy-hv -param ${lfparm} -o ${ldout} -nobugreport ${lf1} ${lf2} ${lf3} &>/dev/null; ((lerr=$?))
	# geopsy-hv -param ${lfparm} -o ${ldout} ${lf1} ${lf2} ${lf3}; ((lerr=$?))
	if [ ${lerr} -eq 0 -a -f ${lfhv} -a -s ${lfhv} ]; then
		# discard the file if it contains at least one "nan", and just to be safe sets the error to 1
		ltmp=$(awk '!/^#/' ${lfhv} | awk -vs=${lsps} 'BEGIN {IGNORECASE = 1} /nan/ && $1 <= s/2 {print}')
		[ -z "${ltmp}" ] && { awk '/^#/ || !/nan/' ${lfhv} >${lfout}; rm -f ${lfhv}; } || \
		{ mv ${lfhv} ${lfout}.err; ((lerr=1)); }
	else
		((lerr=1))
	fi
	[ -f ${ldout}/${lsta}.log ] && mv ${ldout}/${lsta}.log ${lflog}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_hv_ms()
{
	local lf1=$1 lf2=$2 lf3=$3 lfparm=$4 ldout=$5 lpref=$6
	[ -z "${lpref}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lnet lsta lsps
	local lfhv lfout lflog lstr ltmp lerr
	((lerr=0))
	lstr=$(msi -T -tf 1 ${lf1} | grep _ | head -n1); ((lerr=$?))
	if [ ${lerr} -eq 0 ]; then
		lnet=$(echo ${lstr} | awk -vFS=_ '{print $1}')
		lsta=$(echo ${lstr} | awk -vFS=_ '{print $2}')
		lsps=$(echo ${lstr} | awk '{print $(NF-1)}')
		lfhv=${ldout}/${lnet}_${lsta}.hv; lfout=${ldout}/${lpref}.hv; lflog=${ldout}/${lpref}.log
		geopsy-hv -param ${lfparm} -o ${ldout} -nobugreport ${lf1} ${lf2} ${lf3} &>/dev/null; ((lerr=$?))
		# geopsy-hv -param ${lfparm} -o ${ldout} -nobugreport ${lf1} ${lf2} ${lf3}; ((lerr=$?))
		if [ ${lerr} -eq 0 ]; then
			if [ -f ${lfhv} -a -s ${lfhv} ]; then
				# discard the file if it contains at least one "nan", and sets the error to 1
				ltmp=$(awk '!/^#/' ${lfhv} | awk -vs=${lsps} 'BEGIN {IGNORECASE = 1} /nan/ && $1 <= s/2 {print}')
				[ -z "${ltmp}" ] && { awk '/^#/ || !/nan/' ${lfhv} >${lfout}; rm -f ${lfhv}; } || \
				{ echo "${FUNCNAME}: discarding ${lfhv}" >/dev/stderr; mv ${lfhv} ${lfout}.err; ((lerr=1)); }
			else
				# sets error to 1 because ${lfhv} is not present
				((lerr=1)); echo "${FUNCNAME}: error when calculating h/v" >/dev/stderr
			fi
		fi
		[ -f ${ldout}/${lnet}_${lsta}.log ] && mv ${ldout}/${lnet}_${lsta}.log ${lflog}
	fi
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_ms_norm()
{
	local lf1=$1 lf2=$2 lf3=$3 lxs=$4
	[ -z "${lxs}" ] && { echo "${FUNCNAME}: wrong number of arguments"; return 1; }
	local lerr lfile lfile0 lchn lsmax lschn lfilex lfilet ltmp
	((lerr=0))
	ltmp=$(echo "${lxs}" | awk 'NR==1 {s = $2} NR>1 {if ($2 != s) {print NR}}')
	if [ ! -z "${ltmp}" ]; then
		ldtmp=$(mktemp -dqp.) || return 1
		lsmax=$(echo "${lxs}" | awk '{print $2}' | sort -nr | awk 'NR==1')
		for lfile in ${lf1} ${lf2} ${lf3}
		do
			lchn=$(msi -T -tf 1 ${lfile} | awk '/_/ {print $1}' | awk -vFS="_" 'NR==1 {print $4}')
			lschn=$(echo "${lxs}" | awk -vchn=${lchn} '$1==chn {print $2}')
			if [ ! -z "$(echo ${lschn} ${lsmax} | awk '$1 != $2 {print}')" ]; then
				lfile0=$(basename ${lfile}); lfilex=${ldtmp}/${lfile0}.qs; lfilet=${ldtmp}/${lfile0}.ms
				echo -e "\n${FUNCNAME}: multiplying file ${lfile0} by ${lsmax}/${lschn}"
				echo "multiply(${lsmax}/${lschn});" >${lfilex}
				echo "exportFile(\"${lfilet}\", false, \"Miniseed\");" >>${lfilex}
				geopsy -waveform ${lfilex} ${lfile} &>/dev/null && qmerge -C ${lchn} -o ${lfile} ${lfilet} >/dev/null
				((lerr=$?))
			fi
		done
		rm -rf ${ldtmp}
	fi
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_get_params()
{
	local lfx lrow1 lrow2 lstrx
	lfx=$1
	[ -z "${lfx}" ] && { echo "${FUNCNAME}: wrong number of arguments"; return 1; }
	[ ! -f ${lfx} ] && { echo -e "\n${FUNCNAME}: file ${lfx} does not exist" >/dev/stderr; return 1; }
	lrow1=$(awk '/^# BEGIN PARAMETERS$/ {print NR}' ${lfx}); lrow2=$(awk '/^# END PARAMETERS$/ {print NR}' ${lfx})
	[ $(echo -n "${lrow1}" | awk 'END {print NR}') -ne 1 -o $(echo -n "${lrow2}" | awk 'END {print NR}') -ne 1 ] && \
	{ echo -e "\n${FUNCNAME}: ${lfx} is not valid (\"BEGIN PARAMETERS\" and/or \"END PARAMETERS\")" >/dev/stderr; return 1; }
	lstrx=$(awk -vn1=${lrow1} -vn2=${lrow2} '!/^#/ && $1 && NR>n1 && NR<n2' ${lfx} | sort) && echo "${lstrx}"
	return $?
}
# -------------------------------------------------------------------------------------------------------------------------------
gp_diff_param_files()
{
	local lf1 lf2 lstr1 lstr2 lerr
	lf1=$1; lf2=$2; ((lerr=0))
	[ -z "${lf2}" ] && { echo "${FUNCNAME}: wrong number of arguments"; return 1; }
	lstr1=$(gp_get_params ${lf1}) && lstr2=$(gp_get_params ${lf2}) && [ "${lstr1}" == "${lstr2}" ] || \
	{ echo "files ${lf1} and ${lf2} are not equal"; ((lerr=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
