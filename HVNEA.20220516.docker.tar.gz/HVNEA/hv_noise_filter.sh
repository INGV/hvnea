#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-05-16
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################
usage()
{
	echo ""
	echo "Usage: $(basename $0) -i input_dir [ -t ts_file ] [ -a min_amp ] [ -A max_amp ] [ -g cfg_dir ]"
	echo " where:"
	echo "  -i input_dir specifies a valid HV_Noise.sh output directory"
	echo "  -t ts_file specifies file containing time intervals to take into account"
	echo "  -a min_amp specifies minimum H/V amplitude"
	echo "  -A max_amp specifies maximum H/V amplitude"
	echo "  -g cfg_dir specifies the directory containing configuration files, if different from the default"
}
base_dir=$(dirname ${BASH_SOURCE}); cfg_dir=${base_dir}/conf; lib_dir=${base_dir}/tools
fcomm=${lib_dir}/tools.sh; . ${fcomm} || exit 1
while getopts a:A:t:i:g: OPZ
do
	case $OPZ in
		a) a1=${OPTARG} ;;
		A) a2=${OPTARG} ;;
		t) ftimes=${OPTARG} ;;
		i) dirx=${OPTARG} ;;
		g) cfg_dir=${OPTARG} ;;
		?) usage; exit 1 ;;
	esac
done
[ -z "${dirx}" ] && { usage; exit 0; }
# [ -z "${a1}" -a -z "${a2}" -a -z "${ftimes}" ] && \
# { echo -e "\nspecify at least one option between -a, -A, -t"; usage; exit 0; }
[ -d ${dirx} ] || { echo -e "\ndirectory ${dirx} does not exist"; exit 1; }
((err=0))

# check the time intervals file
[ ! -z "${ftimes}" ] && { stimes=$(check_dfile ${ftimes}); ((err+=$?)); }
[ ${err} -ne 0 ] && exit ${err}

# check dirx
check_hvnoise_output ${dirx} || exit 1

# load cfg
fcfg=${cfg_dir}/hv_noise.conf
g_cfg=$(init_cfg_hvnoise) && g_cfg=$(parse_cfg_hvnoise ${fcfg} "${g_cfg}") && check_cfg_hvnoise "${g_cfg}" || exit 1

# selection parameters
[ ! -z "${a1}" ] && strx=$(set_par_tab "${strx}" ${g_info_am1} ${a1})
[ ! -z "${a2}" ] && strx=$(set_par_tab "${strx}" ${g_info_am2} ${a2})
[ ! -z "${ftimes}" ] && { stmp=$(echo "${stimes}" | xargs); strx=$(set_par_tab "${strx}" ${g_info_tmi} "${stmp}"); }

# output
hv_noise_output ${dirx} "${g_cfg}" "${strx}"
