#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-05-27
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################
# -------------------------------------------------------------------------------------------------------------------------------
usage()
{
	echo ""
	echo "Usage: $(basename $0) -n net -s sta -c str -o out_dir [ -f start ] [ -t end ] [ -m min_mag ] [ -M max_mag ]"
	echo "       [ -R max_dist ] [ -l ev_list ] [ -N min_snr ] [ -g cfg_dir ] [ -y ] [ -d ]"
	echo " where:"
	echo "  -n net specifies the network"
	echo "  -s sta specifies the station"
	echo "  -c str specifies the stream"
	echo "  -o specifies the output directory"
	echo "  -f start specifies the start date"
	echo "  -t end specifies the end date"
	echo "  -m min_mag specifies minimum magnitude"
	echo "  -M max_mag specifies maximum magnitude"
	echo "  -R max_dis specifies maximum distance"
	echo "  -l ev_list specifies a file containing the list of events; excludes -f, -t, -m, -M, -R"
	echo "  -N specifies minimum signal to noise ratio"
	echo "  -g cfg_dir specifies the directory containing configuration files, if different from the default"
	echo "  -y specifies to perform the analysis without asking for confirmation"
	echo "  -d specifies to delete waveforms after analysis"
}
# -------------------------------------------------------------------------------------------------------------------------------
base_dir=$(dirname ${BASH_SOURCE}); cfg_dir=${base_dir}/conf; lib_dir=${base_dir}/tools
fwscm=${lib_dir}/ws_tools.sh; fgpcm=${lib_dir}/gp_tools.sh; fcomm=${lib_dir}/tools.sh
. ${fwscm} && . ${fgpcm} && . ${fcomm} || exit 1

# remote (1) or local (0) data
((blc=1))
# remote (1) or local (0) list of events
((blb=1))
# to let the user choose whether to run the analysis (0) or to just run it (1)
((blx=0))
# to delete (1) or not (0) sac files
((bld=0))

# dataless directory for local data
ddless=${base_dir}/dataless
# -------------------------------------------------------------------------------------------------------------------------------
while getopts n:s:c:f:t:m:M:R:l:N:o:g:yd OPZ
do
	case $OPZ in
		n) net=${OPTARG} ;;
		s) sta=${OPTARG} ;;
		c) str=${OPTARG} ;;
		f) dt0=${OPTARG} ;;
		t) dt1=${OPTARG} ;;
		m) mg0=${OPTARG} ;;
		M) mg1=${OPTARG} ;;
		R) dst=${OPTARG} ;;
		l) blt=${OPTARG}; ((blb=0)) ;;
		N) sn1=${OPTARG} ;;
		o) out=${OPTARG} ;;
		g) cfg_dir=${OPTARG} ;;
		y) ((blx=1)) ;;
		d) ((bld=1)) ;;
		?) usage; exit 1 ;;
	esac
done
# -------------------------------------------------------------------------------------------------------------------------------
((err=0))
# check that the command line options are set

# net, sta, stream
[ -z "${net}" ] && { echo -e "\nspecify network with -n"; ((err+=1)); }
[ -z "${sta}" ] && { echo -e "\nspecify station with -s"; ((err+=1)); }
[ -z "${str}" ] && { echo -e "\nspecify stream with -c"; ((err+=1)); }

# events list
if [ ${blb} -eq 1 ]; then
	[ -z "${dt0}" ] && { echo -e "\nspecify start date with -f"; ((err+=1)); }
	[ -z "${dt1}" ] && { echo -e "\nspecify end date with -t"; ((err+=1)); }
	[ -z "${mg0}" ] && { echo -e "\nspecify minimum magnitude with -m"; ((err+=1)); }
	[ -z "${mg1}" ] && { echo -e "\nspecify maximum magnitude with -M"; ((err+=1)); }
	[ -z "${dst}" ] && { echo -e "\nspecify maximum distance of the epicenters from station with -R"; ((err+=1)); }
else
	# this should never happen
	[ -z "${blt}" ] && { echo -e "\nspecify event list with -l"; ((err+=1)); }
fi

# output directory
[ -z "${out}" ] && { echo -e "\nspecify output directory with -o"; ((err+=1)); }

[ ${err} -ne 0 ] && { usage; exit 0; }
# -------------------------------------------------------------------------------------------------------------------------------
# configuration file
fcfg0=${cfg_dir}/hv_eqk.conf
# ws configuration file
fcfgw=${cfg_dir}/fdsn_ws.conf
# event list configuration file
fcfgl=${cfg_dir}/evt_list.conf
# local data path file
fpth0=${cfg_dir}/datapath.conf
# comp changes file
fchng=${cfg_dir}/comp_changes.conf
# geopsy configuration file
fparm=${cfg_dir}/param_hv_eqk.conf
# -------------------------------------------------------------------------------------------------------------------------------
# check various files
[ ! -f "${fcfg0}" -o ! -s "${fcfg0}" ] && { echo -e "\nconfiguration file \"${fcfg0}\" does not exist or is empty"; ((err+=1)); }
[ ! -f "${fcfgw}" -o ! -s "${fcfgw}" ] && { echo -e "\nconfiguration file \"${fcfgw}\" does not exist or is empty"; ((err+=1)); }
[ ! -f "${fcfgl}" -o ! -s "${fcfgl}" ] && { echo -e "\nconfiguration file \"${fcfgl}\" does not exist or is empty"; ((err+=1)); }
[ ! -f "${fparm}" ] && { echo -e "\ngeopsy configuration file \"${fparm}\" does not exist"; ((err+=1)); }
[ ! -f "${fpth0}" ] && { echo -e "\ndatapath file \"${fpth0}\" does not exist"; ((err+=1)); }
[ ! -d "${ddless}" ] && { echo -e "\ndataless directory \"${ddless}\" does not exist"; ((err+=1)); }

# checks net, sta, str
chk_net ${net}; ((err+=$?))
chk_sta ${sta}; ((err+=$?))
chk_str ${str}; ((err+=$?))
[ ${err} -ne 0 ] && exit 1

if [ ${blb} -eq 1 ]; then
	# check parameters for event list
	((erx=0))
	# check dates
	dt0=$(date -u "+${DFMT}" -d "${dt0} utc") && dt1=$(date -u "+${DFMT}" -d "${dt1} utc") && \
	chk_due ${dt0} ${dt1} "date"; ((erx+=$?))
	# check mags
	chk_mag ${mg0} && chk_mag ${mg1} && chk_due ${mg0} ${mg1} "magnitude"; ((erx+=$?))
	# check distance
	dst=$(echo "${dst}"|awk '{printf "%.1f", $1}'); chk_dst ${dst}; ((erx+=$?))
	((err+=${erx}))
else
	# check events list file
	[ ! -f "${blt}" -o ! -s "${blt}" ] && { echo -e "\nlist file \"${blt}\" does not exist or is empty"; ((err+=1)); }
fi

# -------------------------------------------------------------------------------------------------------------------------------
# verifies that the output directory does not exist
[ -d ${out} ] && { echo -e "\nthe specified output directory exists"; ((err+=1)); }

[ ${err} -ne 0 ] && exit 1

# -------------------------------------------------------------------------------------------------------------------------------
# cfg
g_cfg=$(init_cfg_hveqk) && g_cfg=$(parse_cfg_hveqk ${fcfg0} "${g_cfg}"); ((err+=$?))
if [ ${err} -eq 0 ]; then
	[ ! -z "${sn1}" ] && g_cfg=$(set_par_tab "${g_cfg}" "g_cfg_sn0" ${sn1})
	check_cfg_hveqk "${g_cfg}"; ((err+=$?))
fi
[ ${err} -ne 0 ] && exit 1
# restyle cfg
sn0=$(get_par_tab "${g_cfg}" "g_cfg_sn0"); sn0=$(echo ${sn0} | awk '{printf "%.1f", $1}')
g_cfg=$(set_par_tab "${g_cfg}" "g_cfg_sn0" ${sn0})
# -------------------------------------------------------------------------------------------------------------------------------
# for convenience
fmodl3d=$(get_par_tab "${g_cfg}" "g_cfg_fmodl3d")
fiasp91=$(get_par_tab "${g_cfg}" "g_cfg_fiasp91")
fgrid=$(get_par_tab "${g_cfg}" "g_cfg_fgrid")
# -------------------------------------------------------------------------------------------------------------------------------
# check datapath.conf
links=$(parse_datafile_paths ${fpth0}) && links=$(echo "${links}" | awk -vFS="#" -vn=${net} '$2 == n') || exit 1
# if net is not present in datapath file, data are remote
[ -z "${links}" ] && ((blc=1)) || ((blc=0))
# -------------------------------------------------------------------------------------------------------------------------------
# possible component changes
[ -f ${fchng} -a -s ${fchng} ] && chngs=$(awk -vFS="|" '!/^#/ && NF==5' ${fchng})
# -------------------------------------------------------------------------------------------------------------------------------
# loads ws configuration, if needed
wscfg=$(ws_load_cfg ${fcfgw} ${blc} ${blb}) && wscfg=$(ws_get_links "${wscfg}"); ((err+=$?))
if [ ${err} -eq 0 ]; then
	# retrieves event service, if needed
	[ ${blb} -eq 1 ] && linkv=$(ws_get_par "${wscfg}" ${CFG_WS_EVNT})
	if [ ${blc} -eq 1 ]; then
		# retrieves data service, station service, station info
		links=$(ws_get_par "${wscfg}" ${CFG_WS_DATA})
		linkz=$(ws_get_par "${wscfg}" ${CFG_WS_STAT})
		s_info=$(ws_get_station_info "${linkz}" ${net} ${sta} "${str}?"); ((err+=$?))
	else
		# parses dataless to obtain station info
		if [ -f ${ddless}/${net}/${sta}.dless -a -s ${ddless}/${net}/${sta}.dless ]; then
			s_info=$(ws_parse_dless ${net} ${ddless}/${net}/${sta}.dless) && \
			s_info=$(echo "${s_info}" | awk -vFS="#" -vstr=${str} 'substr($4, 1, 2)==str {print}'); ((err+=$?))
			[ ${err} -eq 0 -a -z "${s_info}" ] && \
			{ echo -e "\nperhaps triple ${net}/${sta}/${str} does not exist"; ((err+=1)); }
		else
			{ echo -e "\ndataless file ${ddless}/${net}/${sta}.dless is missing or empty"; ((err+=1)); }
		fi
	fi
fi
[ ${err} -ne 0 ] && exit ${err}

# retrieves event list structure ------------------------------------------------------------------------------------------------
evcfg=$(ws_load_evt_cfg ${fcfgl}) || exit 1
# -------------------------------------------------------------------------------------------------------------------------------
[ ${blb} -eq 0 ] && echo -e -n "\nevents from ${blt}; " || echo -e -n "\nstart date ${dt0}, end date ${dt1}; "
[ ${blc} -eq 1 ] && echo -e "remote data" || echo "local data"
# -------------------------------------------------------------------------------------------------------------------------------
# creates directories
dtmp=${out}/${g_dir_tmp}; dfls=${out}/${g_dir_files}; devs=${out}/${g_dir_evts}
mkdir -p ${dtmp} ${dfls} ${devs} || exit 1
# -------------------------------------------------------------------------------------------------------------------------------
# restyles geopsy configuration file
fpart=${dfls}/${g_file_parm_eqk}; gp_restyle_param_eqk_conf ${fparm} ${fpart}; ((err+=$?))

# maybe here it would be better not to delete the output directory in case of error
[ ${err} -ne 0 ] && { rm -rf ${out}; exit ${err}; }
# -------------------------------------------------------------------------------------------------------------------------------

# writes cmdline to file
fcmdl=${dfls}/${g_file_cmd}; echo "$(basename $0) $*" >${fcmdl}

# write the input arguments and blc to file
fcall=${dfls}/${g_file_args}
add_pars_file ${fcall} ${g_info_net} "${net}" ${g_info_sta} "${sta}" ${g_info_str} "${str}" \
${g_info_dt1} "${dt0}" ${g_info_dt2} "${dt1}" ${g_info_mg1} "${mg0}" ${g_info_mg2} "${mg1}" \
${g_info_ds2} "${dst}" ${g_info_sn1} "${sn0}" ${g_info_lst} "${blt}" ${g_info_src} "${blc}"
((err+=$?))
if [ ${err} -eq 0 ]; then
	[ ${blc} -eq 0 ] && dfrom="local archive" || dfrom=$(ws_get_data_from "${wscfg}")
	add_pars_file ${fcall} ${g_info_frm} "${dfrom}"; ((err+=$?))
	[ ${blb} -eq 0 ] && efrom="local list" || efrom=$(ws_get_evnt_from "${wscfg}")
	add_pars_file ${fcall} ${g_info_frn} "${efrom}"; ((err+=$?))
fi
[ ${err} -ne 0 ] && { rm -rf ${out}; exit ${err}; }
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves the coordinates of the various triples (and writes them to file),
# then it retrieves the coordinates of the empty location or alternatively any one
xcrdz=$(ws_info_coords "${s_info}" ${net} ${sta}); ((err+=$?))
if [ ${err} -eq 0 ]; then
	strx=$(echo "${xcrdz}" | awk -vFS="#" -vl="" '$3==l {print $4, $5, $6}')
	[ -z "${strx}" ] && strx=$(echo "${xcrdz}" | awk -vFS="#" 'NR==1 {print $4, $5, $6}')
	latS=$(echo ${strx} | awk '{print $1}'); lonS=$(echo ${strx} | awk '{print $2}')
	fcoord=${dfls}/${g_file_coord}; echo "${xcrdz}" >${fcoord}
fi
# -------------------------------------------------------------------------------------------------------------------------------
[ ${err} -ne 0 ] && { rm -rf ${out}; exit ${err}; }

# -------------------------------------------------------------------------------------------------------------------------------
# various lists
flist=${dfls}/${g_file_evts_list}; fbult=${flist}.0; fbuls=${flist}.1

# flag to perform the analysis (1) or not (0), number of events
((bly=1)); ((neqk=0))
[ ${blb} -eq 0 ] && fbult=${blt} || \
ws_get_evt_list -v${linkv} -f${dt0} -t${dt1} -m${mg0} -M${mg1} -L${latS} -l${lonS} -R${dst} -e${fbult}; ((err+=$?))
[ ${err} -eq 0 ] && \
ws_conv_evt_list ${fbult} ${fbuls} "${evcfg}" && \
ws_enhance_evt_list ${fbuls} ${lonS} ${latS} ${dtmp} ${flist} && \
neqk=$(ws_clean_evt_list ${flist}) && rm -f ${fbuls}; ((err+=$?))
[ ${err} -eq 0 -a ${blb} -eq 1 ] && rm -f ${fbult}
[ ${err} -ne 0 ] && exit ${err}

# here we decide whether to continue or not based on the distribution of events
if [ ${blx} -eq 0 ]; then
	fbulm=${dfls}/LIST.map.txt; fmap0=${out}/${g_eqk_map_ps}
	awk -vFS="${WS_EVT_LIST_SEP}" -vL=${ev_list_fields[lat]} -vl=${ev_list_fields[lon]} -vd=${ev_list_fields[dep]} \
	-vm=${ev_list_fields[mag]} '!/^#/ {print $L, $l, $d, $m}' ${flist} >${fbulm}
	# creates map; it makes no sense to distinguish the locations here
	maps -s${sta} -L${latS} -l${lonS} -o${fmap0} -e${fbulm} -g${fgrid}; ((err+=$?))
	if [ ${err} -eq 0 ]; then
		gv ${fmap0}
		echo
		while [ ${bly} -eq 1 ]
		do
			read -p "do you wish to [download and] analyze the ${neqk} events? " yn
			case ${yn} in
				[Yy]* ) break ;;
				[Nn]* ) ((bly=0)) ;;
				* ) echo -e "please answer yes or no.\n" ;;
			esac
		done
		[ ${bly} -eq 0 ] && ((err+=1))
	fi
	rm -f ${fbulm}
fi
# -------------------------------------------------------------------------------------------------------------------------------
# file to obtain the limits of the area to be analyzed; here it makes no sense to distinguish the locations
if [ ${err} -eq 0 ]; then
	frmtxt=${dfls}/analysis_area.tmp; fmodel=${dfls}/${g_eqk_m1d}
	echo ${lonS} ${latS} >${frmtxt}
	awk -vFS="${WS_EVT_LIST_SEP}" -vL=${ev_list_fields[lat]} -vl=${ev_list_fields[lon]} \
	'!/^#/ {print $l, $L}' ${flist} >>${frmtxt}
	# creates 1d model of the area to be analyzed
	model1d ${frmtxt} ${fmodl3d} ${fiasp91} ${dtmp} ${fmodel}; ((err+=$?))
	rm -f ${frmtxt}
fi
# -------------------------------------------------------------------------------------------------------------------------------
[ ${err} -ne 0 ] && { rm -rf ${out}; exit 1; }

# -------------------------------------------------------------------------------------------------------------------------------
evts=$(awk '!/^#/ {print}' ${flist})
# enhanced event list
fevtz=${out}/${g_file_evts_resp}; fevts_hdr ${fevtz}
# loop on events
for idx_evt in $(seq 1 ${neqk})
do
	# to read a row from the events list; we could use an associative array, but this way is more user-friendly;
	# unset is not necessary
	unset vcols_idv vcols_dat vcols_lat vcols_lon vcols_dep vcols_mag vcols_tmg vcols_baz vcols_dst
	# -------------------------------------------------------------------------------------------------------------
	evtx=$(echo "${evts}" | awk -vi=${idx_evt} 'NR==i {print}')
	# read parameters
	vcols_idv=$(ws_get_evtf "${evtx}" "idv"); vcols_dat=$(ws_get_evtf "${evtx}" "dat")
	vcols_lat=$(ws_get_evtf "${evtx}" "lat"); vcols_lon=$(ws_get_evtf "${evtx}" "lon")
	vcols_dep=$(ws_get_evtf "${evtx}" "dep"); vcols_mag=$(ws_get_evtf "${evtx}" "mag")
	vcols_tmg=$(ws_get_evtf "${evtx}" "tmg"); vcols_baz=$(ws_get_evtf "${evtx}" "baz")
	vcols_dst=$(ws_get_evtf "${evtx}" "dst"); echo -e "\nevent ${vcols_idv}"
	# check date
	vcols_dat=$(date -u +"${DFMN}" -d "${vcols_dat} utc") && vcols_dat=${vcols_dat:0:26} || continue
	# ------------------------------------------------------------------------------------------------------------------
	dtx=$(date -u +"${DFMN}" -d "${vcols_dat} utc -$((SECS_NOISE+SECS_EXTRA)) sec"); dtx=${dtx:0:26}
	dty=$(date -u +"${DFMN}" -d "${vcols_dat} utc +$((EQK_MAX_LENGTH+SECS_EXTRA)) sec"); dty=${dty:0:26}
	dts=${dtx:0:19}; dtz=${dty:0:19}
	dtS=$(echo ${dtx:0:19} | tr "[\-T:]" ".")
	yj=$(date -u +"${DFMY}" -d "${vcols_dat} utc -$((SECS_NOISE+SECS_EXTRA)) sec")

	# link or data path
	[ ${blc} -eq 1 ] && linkx=${links} || \
	linkx=$(echo "${links}" | awk -vFS="${WS_SEQ}" -vdt0=${dt0} '$4 <= dt0 && dt0 < $5 {print $1}' | head -n1)
	nsls=$(ws_info_nsls "${s_info}" ${dts})
	[ -z "${linkx}" -o -z "${nsls}" ] && { echo -e "\ndata not present for event ${vcols_idv}"; continue; }
	# ------------------------------------------------------------------------------------------------------------------
	devt=${devs}/${vcols_idv}; drhv=${devt}/${g_dir_hv}; dmsd=${devt}/${g_dir_ms}; dsac=${devt}/${g_dir_sac}
	mkdir -p ${drhv} ${dmsd} ${dsac} && \
	# loop on nslx
	for nslx in ${nsls}
	do
		# error on current nslx
		((errx=0)); unset xsnr xf0w cuts amps1 amps2
		loc=$(echo ${nslx} | awk -vFS=${WS_SEQ} '{print $3}'); nslt=${nslx//${WS_SEQ}/.}.${str}
		xcrds=$(echo "${xcrdz}" | awk -vFS="#" -vl=${loc} '$3==l {print $4, $5, $6}')
		latSx=$(echo ${xcrds} | awk '{print $1}'); lonSx=$(echo ${xcrds} | awk '{print $2}')
		eleSx=$(echo ${xcrds} | awk '{print $3}')
		x_info=$(ws_select_stainfo "${s_info}" ${dts} ${dtz} ${net} ${sta} "${loc}" ${str})
		ws_check_station_info "${x_info}" && chs=$(ws_info_chans "${x_info}"); ((errx+=$?))
		# chs=$(echo "${x_info}" | awk -vFS="#" '{print $4}' | sort -u)
		if [ ${errx} -eq 0 ]; then
			chz=""
			for chn in ${chs}
			do
				chm=$(chngs_get_cha "${chngs}" ${net} ${sta} "${loc}" ${chn})
				chm=${chm:-${chn}}; chz=$(echo -e "${chz}\n${chm}")
			done
			chz=${chz:1}
			ws_check_comps "${chz}"; ((errx=$?))
		fi
		if [ ${errx} -eq 0 ]; then
			# loop on channels
			for chn in ${chs}
			do
				if [ ${errx} -eq 0 ]; then
					nslc=${nslx//${WS_SEQ}/.}.${chn}; fseed=${dmsd}/${nslc}.${dtS}.mseed
					if [ ${blc} -eq 1 ]; then
						fseet=${fseed}.0; strx="starttime=${dtx}&endtime=${dty}&net=${net}&sta=${sta}&loc=${loc}&cha=${chn}"
						wget -nv -a /dev/stdout -O ${fseet} ${linkx}"${strx}"; ((errx+=$?))
						[ ${errx} -eq 0 -a ! -s ${fseet} ] && \
						{ ((errx+=1)); echo -e "\ndata not found for ${nslc}"; rm -f ${fseet}; }
					else
						pathd=${linkx}/${yj:0:4}/${net}/${sta}/${chn}.D; fseep=${pathd}/${nslc}.D.${yj}
						# perhaps this check is redundant
						if [ ! -f ${fseep} -o ! -s ${fseep} ]; then
							echo -e "\nfile ${fseep} is missing or empty"; ((errx+=1))
						elif [ ${dtx:0:10} != ${dty:0:10} ]; then
							# includes the next day
							yj1=$(date -u +"${DFMY}" -d "${dty} utc")
							linkx=$(echo "${links}" | awk -v FS='#' -v d0=${dtz} '$3 <= d0 && d0 < $4 {print $NF}')
							if [ ! -z "${linkx}" ]; then
								pathd=${linkx}/${yj1:0:4}/${net}/${sta}/${chn}.D; fseep="${fseep} ${pathd}/${nslc}.D.${yj1}"
							fi
						fi
					fi
				fi
				# qmerge is needed for local data, for remote data it simplifies check_ms
				if [ ${errx} -eq 0 ]; then
					# for double safety
					[ ${blc} -eq 1 ] && fseex=${fseet} || fseex=${fseep}
					dta=$(date -u +"${DFMN}" -d "${vcols_dat} utc -${SECS_NOISE} sec")
					dtb=$(date -u +"${DFMN}" -d "${vcols_dat} utc +${EQK_MAX_LENGTH} sec")
					qmerge -T -f ${dtx//[T-]/.} -t ${dty//[T-]/.} -o ${fseed} ${fseex} >/dev/null && \
					check_ms ${fseed} ${dta} ${dtb} && \
					fsac=${dsac}/${nslc}.${dtS}.SAC && \
					ms2sac -c ${latSx},${lonSx},${eleSx} -n seed ${fseed} ${fsac} && \
					xsens=$(ws_info_sens "${x_info}" ${net} ${sta} "${loc}" ${chn}) && \
					sac_div_w ${fsac} ${xsens}; ((errx+=$?))
					if [ ${errx} -eq 0 -a ! -z "${chngs}" ]; then
						chm=$(chngs_get_cha "${chngs}" ${net} ${sta} "${loc}" ${chn})
						[ ! -z "${chm}" ] && { sac_ch_cha ${fsac} ${chm}; ((errx=$?)); }
					fi						
					if [ ${errx} -eq 0 ]; then
						rm -f ${fseed}; [ ${blc} -eq 1 ] && rm -f ${fseet}
					fi
				fi
			done
			# end loop on channels
			sacs="${dsac}/${nslt}?.${dtS}.SAC"
		fi
		# ---------------------------------------------------------------------------------------------------------------
		# adjusts sac files and calculates the h/v
		if [ ${errx} -eq 0 ]; then
			# obtain a suitable tmg --------------------------------------------------------
			if [ ! -z "${vcols_tmg}" ]; then
				vcols_tmg=${vcols_tmg,,}; vcols_tmg=${vcols_tmg#m}
				vcols_tmg=$(echo "${vcols_tmg:0:1}" | grep ^[bslwdx])
			fi
			vcols_tmg="im"${vcols_tmg:-l}
			# ------------------------------------------------------------------------------
			if [ ${SAC_PROG} -eq 0 ]; then
				strx="rh ${sacs}; ch evla ${vcols_lat} evlo ${vcols_lon} evdp ${vcols_dep}"
				strx=${strx}" mag ${vcols_mag} imagtyp ${vcols_tmg}; wh; quit"
				echo "${strx}" | sac >/dev/null; ((errx=$?))
			else
				strx=$(echo -e "rh ${sacs}\nch evla ${vcols_lat} evlo ${vcols_lon}")
				strx=$(echo -e "${strx} evdp ${vcols_dep} mag ${vcols_mag}\nwh\nquit")
				echo "${strx}" | gsac >/dev/null; ((errx=$?))
			fi
			[ ${errx} -eq 0 ] && \
			cut1=$(cake_w 0 ${vcols_dep} ${vcols_dst} ${fmodel}) && \
			cut2=$(echo ${cut1} | awk -vd=${EQK_MIN_LENGTH} '{print $1+d}') && \
			sync_sacs ${vcols_dat} ${sacs} && \
			set_t1 ${cut1} ${sacs}; ((errx=$?))
			# -----------------------------------------------------------------------------------------
			for sacx in ${sacs}
			do
				if [ ${errx} -eq 0 ]; then
					cutx=${sacx}.cut && \
					sac_cut_w ${sacx} ${cutx} ${cut1} ${cut2} && \
					# retrieves max amplitude
					ampx=$(sac_max_amp ${cutx}) && \
					# rms on noise
					rmsx=$(sac_rms ${sacx} -${SECS_NOISE} 0) && \
					# evaluates single snr
					snrx=$(echo ${ampx} ${rmsx} | awk '{printf "%.1f", $1/$2}') && \
					# updates snr list
					xsnr=$(echo -e "${xsnr}\n"${snrx}) && \
					# taper, fill et al on file ${cutx}
					sac_fill_w ${cutx} ${GP_EQK_MIN_L} && \
					# updates cut file list
					cuts="${cuts} ${cutx}"; ((errx+=$?))
				fi
			done
			[ ${errx} -eq 0 ] && \
			xsnr=${xsnr:1} && xsnr=$(echo "${xsnr}" | sort -n | head -n1) && \
			cuts=$(echo ${cuts} | xargs) && \
			gp_hv_sac ${cuts} ${fpart} ${drhv} ${nslt} && \
			xf0w=$(awk '/f0 from average/ {print $NF}' ${drhv}/${nslt}.hv | tail -n1) && \
			amps=$(hv_min_max ${drhv}/${nslt}.hv) && \
			{ amps1=$(echo ${amps} | awk '{print $1}'); amps2=$(echo ${amps} | awk '{print $2}'); }
			((errx+=$?))
		fi
		# ---------------------------------------------------------------------------------------------------------------
		# updates the enhanced event list
		xsnr=${xsnr:-"-"}; xf0w=${xf0w:-"-"}; amps1=${amps1:-"-"}; amps2=${amps2:-"-"}
		strx="${vcols_dat} ${vcols_lat} ${vcols_lon} ${vcols_dep} ${vcols_mag} ${vcols_baz} ${vcols_dst}"
		echo ${vcols_idv} ${nslt} ${strx} ${xf0w} ${amps1} ${amps2} ${xsnr} ${errx} >>${fevtz}

		# ---------------------------------------------------------------------------------------------------------------
	done
	# end loop on nslx
	# cleaning
	[ ${bld} -eq 1 ] && rm -rf ${dsac}
	[ -d ${dmsd} ] && rmdir --ignore-fail-on-non-empty ${dmsd}
	[ -d ${drhv} ] && rmdir --ignore-fail-on-non-empty ${drhv}
	[ -d ${dsac} ] && rmdir --ignore-fail-on-non-empty ${dsac}
	[ -d ${devt} ] && rmdir --ignore-fail-on-non-empty ${devt}

done
# end loop on events
# -------------------------------------------------------------------------------------------------------------------------------
echo
unset strx; [ -z $(echo ${sn0} | awk '$1==0') ] && strx="${g_info_sn1} ${sn0}"
# maybe the check is redundant
check_hveqk_output ${out} 1 && hv_eqk_all ${out} "${g_cfg}" && hv_eqk_output ${out} "${g_cfg}" "${strx}"; ((err=$?))
rmdir --ignore-fail-on-non-empty ${dtmp} ${dfls} ${out}
exit ${err}
