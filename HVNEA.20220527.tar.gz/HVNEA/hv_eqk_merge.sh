#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-05-27
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################
# -------------------------------------------------------------------------------------------------------------------------------
usage()
{
	echo ""
	echo "Usage: $(basename $0) -o out_dir [ -g cfg_dir ] input_dirs"
	echo " where:"
	echo "  -o out_dir specifies the output directory"
	echo "  -g cfg_dir specifies the directory containing the configuration files, if different from the default"
	echo "  input_dirs are the output directories to merge; they can result from"
	echo "  HV_Eqk.sh, hv_eqk_filter.sh, hv_eqk_recovery.sh, hv_eqk_merge.sh"
}
# -------------------------------------------------------------------------------------------------------------------------------
base_dir=$(dirname ${BASH_SOURCE}); cfg_dir=${base_dir}/conf; lib_dir=${base_dir}/tools
fcomm=${lib_dir}/tools.sh; fgpcm=${lib_dir}/gp_tools.sh
. ${fcomm} && . ${fgpcm} || exit 1
while getopts o:g: OPZ
do
	case $OPZ in
		o) dout=${OPTARG} ;;
		g) cfg_dir=${OPTARG} ;;
		?) usage; exit 1 ;;
	esac
done
shift $((OPTIND-1))
declare -a dirs; dirs=($@); ndirs=${#dirs[@]}
[ -z "${dout}" ] && { echo -e "\nspecify output directory"; usage; exit 0; }
[ -d "${dout}" ] && { echo -e "\nspecified output directory exists"; exit 1; }
[ ${ndirs} -lt 2 ] && { echo -e "\nspecify at least two output directories"; usage; exit 0; }
fcfg=${cfg_dir}/hv_eqk.conf
g_cfg=$(init_cfg_hveqk) && g_cfg=$(parse_cfg_hveqk ${fcfg} "${g_cfg}") && check_cfg_hveqk "${g_cfg}" || exit 1

for jtmp in $(seq 1 ${#dirs[@]}); do check_hveqk_output ${dirs[jtmp-1]} 0 || unset dirs[jtmp-1]; echo; done
dirs=(${dirs[@]})
[ ${#dirs[@]} -lt 2 ] && { echo "not enough valid output directories"; exit 1; }

dfl0=${dout}/${g_dir_files}; dev0=${dout}/${g_dir_evts}; mkdir ${dout} ${dfl0} ${dev0} || exit 1
fcal0=${dfl0}/${g_file_args}; fcoo0=${dfl0}/${g_file_coord}; fpar0=${dfl0}/${g_file_parm_eqk}
fevt0=${dout}/${g_file_evts_resp}; fevtt=${dout}/evts_resp.all

((err=0))

# check args.txt compatibility
if [ ${err} -eq 0 ]; then
	stmp=$(echo ${dirs[@]} | xargs -n1 | awk -vf=${g_dir_files} -va=${g_file_args} -vORS=" " '{print $1"/"f"/"a}')
	fcal1=$(echo ${stmp} | awk '{print $1}'); calls=$(cat ${stmp})
	for xpar in ${g_info_net} ${g_info_sta} ${g_info_str} ${g_info_src}
	do
		xtmp=$(echo "${calls}" | awk -vv=${xpar} '$1==v {print $2}' | sort -u)
		if [ $(echo -n "${xtmp}" | awk 'END {print NR}') -ne 1 ]; then
			((err+=1)); echo "directories are not compatible (parameter ${xpar})"
		fi
	done
fi

# check coords.txt compatibility
if [ ${err} -eq 0 ]; then
	stmp=$(echo ${dirs[@]} | xargs -n1 | awk -vf=${g_dir_files} -vc=${g_file_coord} -vORS=" " '{print $1"/"f"/"c}')
	coors=$(cat ${stmp})
	coo0=$(echo "${coors}" | awk '!/^$/' | sort -u)
	nslt=$(echo "${coors}" | awk '!/^$/' | sort -u | awk -vFS="#" -vOFS=. '!/^$/ {print $1, $2, $3}' | sort -u)
	[ $(echo -n "${coo0}" | awk 'END {print NR}') -ne $(echo -n "${nslt}" | awk 'END {print NR}') ] && \
	{ echo "coordinate files are not consistent with each other"; ((err+=1)); }
fi

# check that files param.conf are identical
if [ ${err} -eq 0 ]; then
	fpars=$(echo ${dirs[@]} | xargs -n1 | awk -vf=${g_dir_files} -vp=${g_file_parm_eqk} -vORS=" " '{print $1"/"f"/"p}')
	fpar1=$(echo ${fpars} | awk '{print $1}'); fpars=$(echo ${fpars} | awk '{$1 = ""; print}' | xargs)
	for fparx in ${fpars}; do gp_diff_param_files ${fpar1} ${fparx}; ((err+=$?)); done
fi

# merge dir files
if [ ${err} -eq 0 ]; then
	cp ${fpar1} ${fpar0} && echo "${coo0}" >${fcoo0} && \
	mkargs_hveqk ${fcal1} ${fcal0} && \
	stemp=$(echo "${calls}" | awk -vv=${g_info_frm} '$1==v {$1 = ""; print}' | sort -u) && \
	stemp=$(echo "${stemp}" | sed 's/^ *//' | awk -vORS=", " '{print}' | xargs); stemp=${stemp%,} && \
	stemq=$(echo "${calls}" | awk -vv=${g_info_frn} '$1==v {$1 = ""; print}' | sort -u) && \
	stemq=$(echo "${stemq}" | sed 's/^ *//' | awk -vORS=", " '{print}' | xargs); stemq=${stemq%,} && \
	add_pars_file ${fcal0} ${g_info_frm} "${stemp}" ${g_info_frn} "${stemq}"
	((err=$?))
fi

# merge main
if [ ${err} -eq 0 ]; then
	for dirx in ${dirs[@]}
	do
		echo -e "\nprocessing directory ${dirx}"
		fevtz=${dirx}/${g_file_evts_resp}; awk -vd=${dirx} '!/^#/ && NF==14 && $NF==0 {print $0, d}' ${fevtz} >>${fevtt}
	done
	echo -e "\nmerge..."
	# sorting should be unnecessary
	rows=$(awk '!x[$2 $3 $4 $5 $6 $7]++' ${fevtt} | sort -k3,7); rm -f ${fevtt}
	idev0=""; ((itmp=0)); fevts_hdr ${fevt0}
	echo "${rows}" | while read row
	do
		idevx=$(echo ${row} | awk '{$1="-"; $2="-"; NF=7; print $0}')
		idevt=$(echo ${row} | awk '{print $1}'); nslx=$(echo ${row} | awk '{print $2}')
		dirx=$(echo ${row} | awk '{print $NF}')
		[ "${idevx}" != "${idev0}" ] && ((itmp+=1)) || echo -e "\nduplication (${idev0})"
		idevz=$(echo ${itmp} | awk '{printf "%06d\n", $1}')
		fallx=${dirx}/${g_eqk_fxall//@nslc@/${nslx}}; fally=${dout}/${g_eqk_fxall//@nslc@/${nslx}}
		if [ -s ${fallx} ]; then
			awk -vi=${idevt} -vn=${idevz} '$1==i {print n, $1, $2, $3} END {print ""}' ${fallx} >>${fally}
			echo -ne "\r\e[Kadded event ${idevt} (${nslx})"
			echo ${row} | awk -vid=${idevz} '{$1=id; NF=14; print}' >>${fevt0}
		else
			# this should never happen
			echo -e "\nfile ${fallx} does not exist or is empty"
		fi
		idev0=${idevx}
	done
	echo
fi

# output
if [ ${err} -eq 0 ]; then
	echo -e "\noutput..."; hv_eqk_output ${dout} "${g_cfg}"; ((err=$?))
fi

exit ${err}
