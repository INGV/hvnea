#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-06-29
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################
# -------------------------------------------------------------------------------------------------------------------------------
usage()
{
	echo ""
	echo "Usage: $(basename $0) -o out_dir [ -g cfg_dir ] input_dirs"
	echo " where:"
	echo "  -o out_dir specifies the output directory"
	echo "  -g cfg_dir specifies the directory containing the configuration files, if different from the default"
	echo "  input_dirs are the output directories to merge; they can result from"
	echo "  HV_Noise.sh, hv_noise_filter.sh, hv_noise_recovery.sh, hv_noise_merge.sh"
}
# -------------------------------------------------------------------------------------------------------------------------------
base_dir=$(dirname ${BASH_SOURCE}); cfg_dir=${base_dir}/conf; lib_dir=${base_dir}/tools
fcomm=${lib_dir}/tools.sh; fgpcm=${lib_dir}/gp_tools.sh
. ${fcomm} && . ${fgpcm} || exit 1
while getopts o:g: OPZ
do
	case $OPZ in
		o) dout=${OPTARG} ;;
		g) cfg_dir=${OPTARG} ;;
		?) usage; exit 1 ;;
	esac
done
shift $((OPTIND-1))
declare -a dirs; dirs=($@); ndirs=${#dirs[@]}
[ -z "${dout}" ] && { echo -e "\nspecify output directory"; usage; exit 0; }
[ -d "${dout}" ] && { echo -e "\nspecified output directory exists"; exit 1; }
[ ${ndirs} -lt 2 ] && { echo -e "\nspecify at least two output directories"; usage; exit 0; }
fcfg=${cfg_dir}/hv_noise.conf
g_cfg=$(init_cfg_hvnoise) && g_cfg=$(parse_cfg_hvnoise ${fcfg} "${g_cfg}") && check_cfg_hvnoise "${g_cfg}" || exit 1

for jtmp in $(seq 1 ${#dirs[@]}); do echo; check_hvnoise_output ${dirs[jtmp-1]} 0 || unset dirs[jtmp-1]; done
dirs=(${dirs[@]})
[ ${#dirs[@]} -lt 2 ] && { echo "not enough valid output directories"; exit 1; }

dfl0=${dout}/${g_dir_files}; mkdir ${dout} ${dfl0} || exit 1
fcal0=${dfl0}/${g_file_args}; fcoo0=${dfl0}/${g_file_coord}; fpar0=${dfl0}/${g_file_parm_noise}

((err=0))

# check arg.txt compatibility
if [ ${err} -eq 0 ]; then
	stmp=$(echo ${dirs[@]} | xargs -n1 | awk -vf=${g_dir_files} -va=${g_file_args} -vORS=" " '{print $1"/"f"/"a}')
	fcal1=$(echo ${stmp} | awk '{print $1}'); calls=$(cat ${stmp})
	for xpar in ${g_info_net} ${g_info_sta} ${g_info_str} ${g_info_stp} \
	${g_info_hms} ${g_info_prc} ${g_info_n0w} ${g_info_src} ${g_info_drt}
	do
		xtmp=$(echo "${calls}" | awk -vv=${xpar} '$1==v {print $2}' | sort -u)
		if [ $(echo -n "${xtmp}" | awk 'END {print NR}') -ne 1 ]; then
			((err+=1)); echo "directories are not compatible (parameter ${xpar})"
		fi
	done
fi

# check coords.txt compatibility
if [ ${err} -eq 0 ]; then
	stmp=$(echo ${dirs[@]} | xargs -n1 | awk -vf=${g_dir_files} -vc=${g_file_coord} -vORS=" " '{print $1"/"f"/"c}')
	coors=$(cat ${stmp})
	coo0=$(echo "${coors}" | awk '!/^$/' | sort -u)
	nslt=$(echo "${coors}" | awk '!/^$/' | sort -u | awk -vFS="#" -vOFS=. '!/^$/ {print $1, $2, $3}' | sort -u)
	[ $(echo -n "${coo0}" | awk 'END {print NR}') -ne $(echo -n "${nslt}" | awk 'END {print NR}') ] && \
	{ echo "coordinate files are not consistent with each other"; ((err+=1)); }
fi

# check that files param.conf are identical
if [ ${err} -eq 0 ]; then
	fpars=$(echo ${dirs[@]} | xargs -n1 | awk -vf=${g_dir_files} -vp=${g_file_parm_noise} -vORS=" " '{print $1"/"f"/"p}')
	fpar1=$(echo ${fpars} | awk '{print $1}'); fpars=$(echo ${fpars} | awk '{$1 = ""; print}' | xargs)
	for fparx in ${fpars}; do gp_diff_param_files ${fpar1} ${fparx}; ((err+=$?)); done
fi

# merge dir files
if [ ${err} -eq 0 ]; then
	cp ${fpar1} ${fpar0} && echo "${coo0}" >${fcoo0} && \
	mkargs_hvnoise ${fcal1} ${fcal0} && \
	stemp=$(echo "${calls}" | awk -vv=${g_info_frm} '$1==v {$1 = ""; print}' | sort -u) && \
	stemp=$(echo "${stemp}" | sed 's/^ *//' | awk -vORS=", " '{print}' | xargs); stemp=${stemp%,} && \
	add_pars_file ${fcal0} ${g_info_frm} "${stemp}"
	((err=$?))
fi

# merge main
if [ ${err} -eq 0 ]; then
	str=$(get_par_file ${fcal0} ${g_info_str})
	stp=$(get_par_file ${fcal0} ${g_info_stp})
	nsls=$(awk -vFS="#" -vOFS="." -vc=${str} '{print $1, $2, $3, c}' ${fcoo0})
	for nslx in ${nsls}; do flisq=${dout}/${nslx}.lisq.txt; >${flisq}; done
	for dirx in ${dirs[@]}
	do
		echo -e "\nprocessing directory ${dirx}"
		for nslx in ${nsls}
		do
			flist=${dirx}/${g_noise_flist//@nslc@/${nslx}}; flisq=${dout}/${nslx}.lisq.txt
			[ -s ${flist} ] && awk -vd=${dirx} '!/^#/ {print $0, d}' ${flist} >>${flisq}
		done
	done
	for nslx in ${nsls}
	do
		echo -e "\nprocessing ${nslx}"
		flisq=${dout}/${nslx}.lisq.txt; rows=$(awk '!x[$1]++' ${flisq} | sort)
		fall0=${dout}/${g_noise_fxall//@nslc@/${nslx}}; flist=${dout}/${g_noise_flist//@nslc@/${nslx}}
		unset dtk; >${fall0}; >${flist}
		echo "${rows}" | while read row
		do
			dtj=$(echo ${row}|awk '{print $1}'); wns=$(echo ${row}|awk '{print $3}'); drx=$(echo ${row}|awk '{print $NF}')
			fallx=${drx}/${g_noise_fxall//@nslc@/${nslx}}
			[ ! -z "${dtk}" ] && { dtt=$(d_diffd ${dtj} ${dtk}); [ ${dtt} -gt ${stp} ] && echo >>${fall0}; }; dtk=${dtj}
			awk -vd=${dtj} '$1==d' ${fallx} >>${fall0}; echo >>${fall0}; echo -ne "\r\e[Kadded day ${dtj}"
		done
		awk '{print $1, $2, $3, $4, $5}' ${flisq} | sort >>${flist}
		echo
	done
	for nslx in ${nsls}; do flisq=${dout}/${nslx}.lisq.txt; rm -f ${flisq}; done
fi

if [ ${err} -eq 0 ]; then
	echo "output..."; hv_noise_output ${dout} "${g_cfg}"; ((err=$?))
fi
exit ${err}
