#ifndef lint
static char sccsid[] = "$Id: get_val.c,v 1.1 1993/07/06 19:22:21 doug Exp $ ";
#endif

#include    <stdio.h>

#include    "qlib.h"

#include    "sachead.h"
#include    "procs.h"
#include    "externals.h"

/************************************************************************/
/*  get_val:								*/
/*	Return the next data value.					*/
/************************************************************************/
int
get_val(pval)
    int	    *pval;
{
    if (next_data < npoints) {
	*pval = (int) input_data[next_data++];
	return(1);
    }
    else return(0);
}
