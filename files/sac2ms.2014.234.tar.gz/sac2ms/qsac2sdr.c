/************************************************************************/
/*  sac2sdr -	convert Quanterra SAC files to SEED Data Records.	*/
/************************************************************************/

#ifndef lint
static char sccsid[] = "$Id: qsac2sdr.c,v 1.3 1995/03/22 16:01:45 doug Exp $ ";
#endif

#include    <stdio.h>

char *syntax[] = {
"    [-b] [-C seed_channel] [-N net] [-h] [input_file [output_file]]",
"    where:",
"	-h	    Help - prints syntax message.",
"	-b	    Input is binary SAC file instead of ASCII Sac file.",
"	-C seed_channel",
"		    Explicitly specify SEED channel name.",
"	-N network",
"		    Explicitly specify SEED network name.",
"		    If not specified, default network code will be used.",
"	input_file  Input file containing Quanterra SAC data.",
"		    If no input file is specified, data is read from stdin.",
"	output_file Output file for SEED Data Records.",
"		    If no output file is specified, output is written to stdout.",
NULL };

#include    "qlib.h"

#include    "sachead.h"
#include    "procs.h"
#include    "externals.h"

/************************************************************************/

main(argc, argv)
    int argc;
    char **argv;
{

    int i, ival, npts;
    DATA_HDR *p;

    info = stderr;
    parse_cmdline(&argc,&argv);
    if ( read_sac(input, &sachead, &input_data, &npoints, bin_flag) != 0) 
	FATAL("error reading input file");
    if ( (p = make_hdr(sachead)) == NULL)
	FATAL("error allocating header");
    store (p, output, npoints);
    return(0);
}

/************************************************************************/
/*  print_syntax:							*/
/*	Print the syntax description of program.			*/
/************************************************************************/
void
print_syntax(cmd)
    char *cmd;
{
    int i;
    fprintf (info, "%s", cmd);
    for (i=0; syntax[i] != NULL; i++) fprintf (info, "%s\n", syntax[i]);
}

