/************************************************************************/
/*  Version number for sac2ms.						*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2014 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

/*	$Id: version.h,v 1.10 2014/08/22 17:53:06 doug Exp $ 	*/

#define	VERSION	"1.49 (2014.234)"

/*
Modification History
------------------------------------------------------------------------
Date		Ver			Who	    What
------------------------------------------------------------------------
2014/08/22	1.49 (2014.234)	Doug Neuhauser
	Set miniseed hdr and data to SEED_BIG_ENDIAN.
	Changed default miniseed record size from 4096 to 512.
	Changed default miniseed format from STEIM1 to STEIM2.
2013/01/23	1.48 (2013.023)	Doug Neuhauser
	Fixed code to handle location code.
2013/01/23	1.47 (2013.023)	Doug Neuhauser
	Added (again) code to translate location code with "-" to blank.
2012/05/14	1.46 (2012.134)	Doug Neuhauser
	Removed second close of input file unit.
2012/04/17	1.45 (2012.108)	Doug Neuhauser
	Added support for SEED network code in SAC KNETNM field.
	Added support for SEED location code in SAC KHOLE field.
1999/04/23	1.44 (1999.113)	Doug Neuhauser
	sac2ms.c parse_cmdline.c externals.h version.h sac2ms.man
	Added -L option to specify MiniSEED location field.
*/
