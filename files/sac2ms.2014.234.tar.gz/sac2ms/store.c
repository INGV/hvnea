#ifndef lint
static char sccsid[] = "$Id: store.c,v 1.2 1995/03/22 16:01:38 doug Exp $ ";
#endif

#include    <stdio.h>

#include    "qlib.h"

#include    "sachead.h"
#include    "procs.h"
#include    "externals.h"

#define MAX_CACHED	4

#define	SPECIAL_MASK	00
#define	BYTE_MASK	01
#define	HALFWORD_MASK	02
#define	FULLWORD_MASK	03

#define	FRAMES_PER_BLOCK (64-1)		/* # of data frames per seed blk*/
#define	VALS_PER_FRAME	(16-1)		/* # of ints for data per frame.*/

#define	EMPTY_BLOCK(fn,wn) (fn+wn == 0)

/*  NOTE: the [0]-th item in each array is last data point from the	*/
/*  PREVIOUS block.  Info for current block is stored in		*/
/*  array[1]..array[num_samples].					*/

int data[BLKSIZE];			/* expanded data points.	*/
int diff[BLKSIZE];			/* difference values.		*/
int minbytes[BLKSIZE];			/* min bytes for difference.	*/

typedef struct seed_data_record {	/* seed data record.		*/
    SDR_HDR	sh;			/* data record fixed header.	*/
    int		sh_pad[4];		/* padding for fixed header.	*/
    FRAME	f[FRAMES_PER_BLOCK];	/* data record header frames.	*/
} SDR;


SDR sdr;

#define	X0  sdr.f[0].w[0].fw
#define	XN  sdr.f[0].w[1].fw

/************************************************************************/
/*  Macros								*/
/************************************************************************/

/*  Macro to get the next data value (if any).				*/
#define	GET_VAL(k,points_cached)  \
    if (points_remaining - points_cached > 0) { \
	int tdiff; \
	if (! get_val(&data[k])) { \
	    fprintf (stderr, "error reading input\n"); \
	    exit(1); \
	} \
	tdiff = diff[k] = data[k] - data[k-1]; \
	if (tdiff >= -128 && tdiff < 128) minbytes[k] = 1; \
	else if (tdiff >= -32768 && tdiff < 32768) minbytes[k] = 2; \
	else minbytes[k] = 4; \
	++k; ++points_cached; \
    }

/*  Macro to finish the header with final information.			*/
#define	FINISH_BLOCK \
		p->num_samples = ipt-1; \
		p->x0 = X0 = data[1]; \
		p->xn = XN = data[p->num_samples]; \
		update_seed_hdr(&sdr.sh,p);

/*  Macro to shift unused data to the beginning of the arrays.		*/
/*  Move last value of last block to data[0] for diff computation.	*/
#define	SHIFT_DATA \
    for (j=0,k=ipt-1; j<=points_cached; j++,k++) { \
	data[j] = data[k]; \
	diff[j] = diff[k]; \
	minbytes[j] = minbytes[k]; \
    } \
    ipt = 1; \
    k = points_cached+1; \

/*  Macro to update the header for a new data block.			*/
#define	UPDATE_HDR \
	++(p->seq_no); \
	time_interval (p->num_samples, \
		       p->sample_rate, &sec, &ticks); \
	p->begtime = add_time (p->begtime, sec, ticks);

/*  Macro to pack 4 1-byte differences into a single fullword.		*/
#define	BYTEPACK(i,points_cached)   \
    (points_cached >= 4 && (minbytes[i] == 1) && (minbytes[i+1] == 1) && \
     (minbytes[i+2] == 1) && (minbytes[i+3] == 1))

/*  Macro to pack 2 halfword differences into a single fullword.	*/
#define	HALFPACK(i,points_cached)   \
    (points_cached >= 2 && (minbytes[i] <= 2) && (minbytes[i+1] <= 2))

#define	OUTPUT_BLOCK	write(fileno(output) ,sdr, sizeof(sdr));

#define	SCHAR(dst,n,src) { \
    char *dp = dst; \
    char *sp = src; \
    int sl = strlen(src); \
    int i; \
    for (i=1; i<=n; i++) *dp++ = (i<=sl) ? *sp++ : ' '; }

#define	SCINT(dst,n,ival) { \
    char tmpstr[80]; \
    char tmpfmt[10]; \
    sprintf (tmpfmt, "%%0%dd",n); \
    sprintf (tmpstr, tmpfmt, ival); \
    strncpy (dst, tmpstr, n); }


/************************************************************************/
/*  pad_block:								*/
/*	Pad the rest of the data record with null values.		*/
/************************************************************************/
int
pad_block(fn, wn)
    int	    fn;		    /* current frame number.			*/
    int	    wn;		    /* current work number.			*/
{
    /* Finish off the current frame.					*/
    for (; wn < VALS_PER_FRAME; wn++) {
	    sdr.f[fn].w[wn].fw = 0;
	    sdr.f[fn].ctrl = (sdr.f[fn].ctrl<<2) | STEIM1_SPECIAL_MASK;
    }
    /* Fill the remaining frames in the block.				*/
    for (fn++; fn<FRAMES_PER_BLOCK; fn++) {
	for (wn=0; wn<VALS_PER_FRAME; wn++) {
	    sdr.f[fn].w[wn].fw = 0;
	    sdr.f[fn].ctrl = (sdr.f[fn].ctrl<<2) | STEIM1_SPECIAL_MASK;
	}
    }
    return (0);
}

/************************************************************************/
/*  update_seed_hdr:							*/
/*	Output seed data block.						*/
/************************************************************************/
void
update_seed_hdr(sh, p)
    SDR_HDR	*sh;
    DATA_HDR	*p;
{
    if (p->seq_no <= 1) {
	/*  Parts of the header that do not change.			*/
	SCHAR(&(sh->data_hdr_ind),2,"D")
	SCHAR(sh->station_id,5,p->station_id)
	SCHAR(sh->location_id,2," ")
	SCHAR(sh->channel_id,3,p->channel_id)
	SCHAR(sh->network_id,2,p->network_id)
	sh->sample_rate_factor = p->sample_rate;
	sh->sample_rate_mult = 1;
	sh->num_blockettes = p->num_blockettes;
	sh->num_ticks_correction = p->num_ticks_correction;
	sh->first_data = p->first_data;
	sh->first_blockette = p->first_blockette;
    }
    SCINT(sh->seq_no,6,p->seq_no)
    sh->time = encode_time_sdr(p->begtime);
    sh->num_samples = p->num_samples;
    sh->activity_flags = p->activity_flags;
    sh->io_flags = p->io_flags;
    sh->data_quality_flags = p->data_quality_flags;
    write_blockettes (p, (char *)sh);
}

/************************************************************************/
/*  store:								*/
/*	Store data in steim-1 compressed seed data record.		*/
/************************************************************************/
int
store(p, output, points_remaining)
    DATA_HDR	*p;
    FILE	*output;
    int		points_remaining;
{
    int	    points_cached = 0;
    int	    ipt = 1;		/* index of next data point to be used.	*/
    int	    fn = 0;
    int	    wn = 2;		/* index of next empty position in frame*/
    int	    k = 1;		/* index of next empty position in data.*/
    int	    mask;		/* mask value for compressed fullword.	*/
    int	    j;			/* temp loop counter.			*/
    int	    sec, ticks;		/* second and ticks counters.		*/

    data[0] = 0;

    while (points_remaining > 0) {
	/* Ensure that we cache MAX_CACHED points (if possible).	*/
	for (j=0; j<MAX_CACHED && points_cached<MAX_CACHED; j++)
	    GET_VAL(k,points_cached);

	/*  Pack the next available datapoints into the most compact form.  */
	if (BYTEPACK(ipt,points_cached)) {
	    mask=STEIM1_BYTE_MASK;
	    for (j=0; j<4; j++) sdr.f[fn].w[wn].byte[j] = diff[ipt++];
	    points_cached -= 4;
	    points_remaining -= 4;
	}
	else if (HALFPACK(ipt,points_cached)) {
	    mask=STEIM1_HALFWORD_MASK;
	    for (j=0; j<2; j++) sdr.f[fn].w[wn].hw[j] = diff[ipt++];
	    points_cached -= 2;
	    points_remaining -= 2;
	}
	else {
	    mask=STEIM1_FULLWORD_MASK;
	    sdr.f[fn].w[wn].fw = diff[ipt++];
	    points_cached -= 1;
	    points_remaining -= 1;
	}

	/* Append mask for this word to current mask.			    */
	sdr.f[fn].ctrl = (sdr.f[fn].ctrl<<2) | mask;

	/* Check for full frame or full block.				    */
	if (++wn >= VALS_PER_FRAME) {
	    wn = 0;		/* reset output index to beginning of frame.*/
	    /* If block is full, output block and reinitialize.		    */
	    if (++fn >= FRAMES_PER_BLOCK) {
		FINISH_BLOCK
		OUTPUT_BLOCK
		SHIFT_DATA
		UPDATE_HDR
		fn = 0;
		wn = 2;		/* leave room for x0 and xn in first frame. */
	    }
	    sdr.f[fn].ctrl = 0;
	}
    }

    /* End of data.  Pad final block (if necessary) and output block.	    */
    /* Do not pad and output a completely empty block.			    */
    if (! EMPTY_BLOCK(fn,wn)) {
	pad_block(fn, wn);
	FINISH_BLOCK
	OUTPUT_BLOCK
    }
    return(0);
}

