/************************************************************************/
/*  sac2ms -	convert a SAC file to MiniSEED.				*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2000 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static char sccsid[] = "$Id: sac2ms.c,v 1.9 2014/08/22 17:53:06 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "version.h"

#ifndef	DEFAULT_NETWORK
#define	DEFAULT_NETWORK		"XX"
#endif

#ifndef	DEFAULT_LOCATION
#define	DEFAULT_LOCATION	""
#endif

#ifndef	DEFAULT_OUTPUT_FORMAT
#define	DEFAULT_OUTPUT_FORMAT	STEIM2
#endif

#ifndef	DEFAULT_BLKSIZE
#define	DEFAULT_BLKSIZE		512
#endif

#ifndef	DEFAULT_SAC_FORMAT
#define	DEFAULT_SAC_FORMAT	"ASCII"
#endif

#define	QUOTE(x)	#x
#define	STRING(x)	QUOTE(x)

char *syntax[] = {
"%s version " VERSION,
"%s  [-S station] [-C channel] [-N network] [-L location] [-f a|b]",
"    [-b blksize] [-F format] [-h] [infile [outfile]]",
"    where:",
"	-S station  Specify explicit station name.",
"	-C channel  Specify explicit channel name.",
"	-N network  Specify explicit network code.",
"		    Default network code if none found in sac file is '" 
		    DEFAULT_NETWORK "'.",
"	-L location Specify explicit location code.",
"		    Default location code if none found in sac file is '" 
		    DEFAULT_LOCATION "'.",
"	-f a|b	    Specify input SAC format: ascii or binary.",
"		    Default SAC format is " DEFAULT_SAC_FORMAT ".",
"	-b blksize  Specifies output blksize.  Default blocksize=" STRING(DEFAULT_BLKSIZE) ".",
"	-F format   Specifies output format for MiniSEED data.",
"		    Default output format is " STRING(DEFAULT_OUTPUT_FORMAT) ".",
"	-s scale_factor",
"		    Scale factor to multiply sac data values by before converting",
"		    them to integer.  Default value is 1.0",
"	-h	    Help - prints syntax message.",
"	input_file  Input file containing Quanterra SAC data.",
"		    If no input file is specified, data is read from stdin.",
"	output_file Output file for MiniSEED Records.",
"		    If no output file is specified, output is written to stdout.",
"Notes:",
"1.  A SAC location code beginning with '-' will be converted to a",
"    blank MiniSEED location code.",
NULL };

#include "qlib2.h"

#define	EXTERN
#define	DEFINE

#include "sachead.h"
#include "procs.h"
#include "externals.h"

/************************************************************************/
/*  main:   main program.						*/
/************************************************************************/
int main (int argc, char **argv)
{
    int i, ival, npts;
    DATA_HDR *hdr;
    struct SAChead *sachead = NULL;
    float *input_data = NULL;	/* sac reader allocates buffer.		*/
    int *data = NULL;
    char *mseed = NULL;		/* allow qlib to allocate buffer.	*/
    char *p;
    int n, nleft;
    int status;
    int nblocks;
    int nsamples;

    init_qlib2(1);
    set_hdr_wordorder (SEED_BIG_ENDIAN);
    set_data_wordorder (SEED_BIG_ENDIAN);
    info = stdout;
    parse_cmdline(&argc,&argv);
    status = read_sac(input, &sachead, &input_data, &npts,
		      strchr("Aa", sac_format[0]) ? 0 : 1);
    if (status != 0) 
	FATAL("error reading input file")
    if ((hdr = make_hdr(sachead)) == NULL)
	FATAL("error allocating header")

    /* If no network code found in file, use default network code.  */
    /* If no location code found in file, use default location code. */

    if (strlen(hdr->network_id) == 0) capnstr(hdr->network_id,DEFAULT_NETWORK,DH_NETWORK_LEN);
    if (strlen(hdr->location_id) == 0)capnstr(hdr->location_id,DEFAULT_LOCATION,DH_LOCATION_LEN);
    if (hdr->location_id[0] == '-')capnstr(hdr->location_id,"  ",DH_LOCATION_LEN);

    /* If explicit command line options used to specify SNCL, use them. */
    if (strlen(station)>0) capnstr(hdr->station_id,station,DH_STATION_LEN);
    if (strlen(channel)>0) capnstr(hdr->channel_id,channel,DH_CHANNEL_LEN);
    if (strlen(network)>0) capnstr(hdr->network_id,network,DH_NETWORK_LEN);
    if (strlen(location)>0) capnstr(hdr->location_id,location,DH_LOCATION_LEN);

    /* Convert data in place from float to integer.			*/
    data = (int *)input_data;
    for (i=0; i<npts; i++) {
	data[i] = (int)(input_data[i]*scale_factor);
    }

    hdr->blksize = blksize;
    hdr->data_type = output_format;

    i = 0;
    while (npts > 0) {
    status = ms_pack2_data (hdr, NULL, npts, &data[i], &nblocks, &nsamples, &mseed, 0, NULL);
    if (status != 0 && status != MS_COMPRESS_ERROR) FATAL("Error packing data into MiniSEED.")

    /* Write MiniSEED data to output file.				*/
    n = nleft = nblocks;
    p = (char *)mseed;
    while (nleft > 0 && n > 0) {
	n = fwrite (p, blksize, nleft, output);
	p += n*blksize;
	nleft -= n;
    }
    if (nleft) FATAL("Error writing MiniSEED data.");

    if (status == MS_COMPRESS_ERROR) {
	int sec, usec;
	fprintf (stderr, "Wrote %d samples out of %d samples\n", nsamples, npts);
	fprintf (stderr, "Skipping 5 sample\n");
	hdr->xm2 = hdr->xm1 = 0;
	nsamples += 5;
	time_interval2 (nsamples, hdr->sample_rate, hdr->sample_rate_mult, &sec, &usec);
	hdr->hdrtime = add_time (hdr->hdrtime, sec, usec);
	hdr->begtime = add_time (hdr->begtime, sec, usec);
    }
    else if (status) {
	exit(1);
    }

    i += nsamples;
    npts -= nsamples;
    if (mseed) {
	free (mseed);
	mseed = NULL;
    }

    }

    free_data_hdr (hdr);
    free (sachead);
    free (input_data);
    /* input closed in read_sac */
    fclose (output);
    return(0);
}
