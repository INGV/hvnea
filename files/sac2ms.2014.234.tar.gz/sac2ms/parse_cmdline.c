/************************************************************************/
/*  Command line parsing routines.					*/
/*									*/
/*	Douglas Neuhauser						*/
/*	Seismological Laboratory					*/
/*	University of California, Berkeley				*/
/*	doug@seismo.berkeley.edu					*/
/*									*/
/************************************************************************/

/*
 * Copyright (c) 1996-2000 The Regents of the University of California.
 * All Rights Reserved.
 * 
 * Permission to use, copy, modify, and distribute this software and its
 * documentation for educational, research and non-profit purposes,
 * without fee, and without a written agreement is hereby granted,
 * provided that the above copyright notice, this paragraph and the
 * following three paragraphs appear in all copies.
 * 
 * Permission to incorporate this software into commercial products may
 * be obtained from the Office of Technology Licensing, 2150 Shattuck
 * Avenue, Suite 510, Berkeley, CA  94704.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY
 * FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES,
 * INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE AND
 * ITS DOCUMENTATION, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN
 * ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE UNIVERSITY OF CALIFORNIA SPECIFICALLY DISCLAIMS ANY WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE SOFTWARE
 * PROVIDED HEREUNDER IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
 * CALIFORNIA HAS NO OBLIGATIONS TO PROVIDE MAINTENANCE, SUPPORT,
 * UPDATES, ENHANCEMENTS, OR MODIFICATIONS.
 */

#ifndef lint
static char sccsid[] = "$Id: parse_cmdline.c,v 1.6 2000/10/26 13:40:01 doug Exp $ ";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#include "qlib2.h"

#include "sachead.h"
#include "procs.h"
#include "externals.h"

#define	argc	(*pargc)
#define	argv	(*pargv)

/************************************************************************/
/*  parse_cmdline:							*/
/*	Parse command line.						*/
/************************************************************************/
int
parse_cmdline( pargc, pargv)
    int	    *pargc;
    char    ***pargv;
{
    int i;
    int	nfiles;
    char *p;

    /* Variables needed for getopt. */
    extern char	*optarg;
    extern int	optind, opterr;
    int		c;

    cmdname = tail(*argv);
    scale_factor = 1.0;

    /*	Parse command line options.					*/
    while ( (c = getopt(argc,argv,"hf:b:s:F:S:C:N:L:")) != -1)
    switch (c) {
      case '?':
      case 'h':	print_syntax(cmdname,syntax,info); exit(0); break;
      case 'f': sac_format = optarg; break;
      case 'b':	blksize = get_blksize(optarg); break;
      case 's': scale_factor = atof(optarg); break;
      case 'F':	output_format = decode_data_format (optarg); break;
      case 'S':	strncpy(station,optarg,DH_STATION_LEN); station[DH_STATION_LEN] = '\0'; uppercase(station); break;
      case 'C':	strncpy(channel,optarg,DH_CHANNEL_LEN); channel[DH_CHANNEL_LEN] = '\0'; uppercase(channel); break;
      case 'N':	strncpy(network,optarg,DH_NETWORK_LEN); network[DH_NETWORK_LEN] = '\0'; uppercase(network); break;
      case 'L':	strncpy(location,optarg,DH_LOCATION_LEN); location[DH_LOCATION_LEN] = '\0'; uppercase(location); break;
      default: FATAL("error parsing options")
    }

    /*	Skip over all options and their arguments.			*/
    argv = &(argv[optind]);
    argc -= optind;

    /*	Verify that options are OK.					*/
    if (blksize <= 0) FATAL("Error - invalid blksize.");
    if (output_format <= 0) 
	FATAL("Error - Unknown or unsupported output data format.")
    if (strchr("AaBb", sac_format[0]) == NULL)
	FATAL("Error - invalid sac format specified.")

    /* The remaining arguments are [ input [and output] ] files.	*/

    infile = "<stdin>";
    input = stdin;
    outfile = "<stdout>";
    output = stdout;
    info = stdout;
    switch (argc) {
      case 0:
	info = stderr;
	break;
      case 1:
	infile = argv[0];
	if ((input = fopen (infile, "r")) == NULL)
	    FATAL ("unable to open input file")
	info = stderr;
	break;
      case 2: 
	infile = argv[0];
	if ((input = fopen (infile, "r")) == NULL)
	    FATAL ("unable to open input file")
	outfile = argv[1];
	if ((output = fopen (outfile, "w")) == NULL)
	    FATAL ("unable to open output file")
	break;
      default:
	print_syntax(cmdname,syntax,info); exit(1); break;
    }
    return(0);
}

/************************************************************************/
/*  get_blksize:							*/
/*	Parse blksize_str and return blocksize.  Ensure it is valid, ie	*/
/*	it is a power of 2, and within the valid blksize boundaries.	*/
/*	Return 0 on error.						*/
/************************************************************************/
int get_blksize
   (char	*str)		/* string containing blksize.		*/
{
    int blksize, n, m;
    char *p;
    blksize = strtol (str, &p, 10);
    switch (*p) {
      case 0:	break;
      case 'k':
      case 'K':	blksize *= 1024; break;
      default:	blksize = 0;
    }
    if (blksize <= 0 || blksize > MAX_BLKSIZE) return (0);
    n = (int)log2((double)blksize);
    m = (int)pow(2.0,(double)n);
    if (m != blksize) return (0);
    return (blksize);
}
