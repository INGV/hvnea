# rdseed
rdseed – Read an FDSN SEED format volume
