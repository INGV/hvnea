/***************************************************************************
**
**  This file is part of hvtfa.
**
**  hvtfa is free software: you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  hvtfa is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with Foobar.  If not, see <http://www.gnu.org/licenses/>
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2007-05-31
**  Copyright: 2007-2019
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**    Miriam Kristekova (Geophysical Institute, Academy of Sciences, Bratislava, Slovak Republic)
**
***************************************************************************/

#ifndef TOOLHVTFAD_H
#define TOOLHVTFAD_H

#include <QtGui>

#include "HVTFAParameters.h"
#include "ui_ToolHVTFAd.h"

class ToolHVTFAd : public QWidget, public Ui::ToolHVTFAd
{
  Q_OBJECT
public:
  ToolHVTFAd(QWidget * parent=nullptr);

  void getParameters(HVTFAParameters& param);
  void setParameters(const HVTFAParameters& param);
private slots:
  void on_outputDirectoryBut_clicked();
};

#endif // TOOLHVTFAD_H
