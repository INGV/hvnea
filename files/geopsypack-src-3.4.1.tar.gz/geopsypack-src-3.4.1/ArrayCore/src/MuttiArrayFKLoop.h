/***************************************************************************
**
**  This file is part of ArrayCore.
**
**  ArrayCore is free software: you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  ArrayCore is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with Foobar.  If not, see <http://www.gnu.org/licenses/>
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2018-04-25
**  Copyright: 2018-2019
**    Marc Wathelet (ISTerre, Grenoble, France)
**
***************************************************************************/

#ifndef MUTTIARRAYFKLOOP_H
#define MUTTIARRAYFKLOOP_H

//#include "ArrayLoop.h"
#include "ArrayCoreDLLExport.h"
#include "FKCrossSpectrum.h"

namespace ArrayCore {
#if 0
  class WaveNumberConverter;

  class ARRAYCORE_EXPORT MuttiArrayFKLoop : public ArrayLoop
  {
  public:
    MuttiArrayFKLoop(const ArraySelection * array);
    ~MuttiArrayFKLoop();
  protected:
    virtual LoopWorker * newWorker();

    QVector<FKCache *> _gridCache;
  };

  class ARRAYCORE_EXPORT MuttiArrayFKLoopWorker : public LoopWorker
  {
  public:
    MuttiArrayFKLoopWorker();
    ~MuttiArrayFKLoopWorker();

    virtual void setArray(const ArraySelection * array);
    virtual void setGrid(FKCache * gridCache);
    void setParameters(const FKParameters * param);
    void setLoop(const MuttiArrayFKLoop * l) {_loop=l;}
  protected:
    virtual void run(int index);
    void localizeMax(int gridIndex);
    void addPeak(int gridIndex, const WaveNumberConverter& conv);
    bool setSlownessRange(int gridIndex);

    const MuttiArrayFKLoop * _loop;
    QVector<FKCrossSpectrum *> _process;
    FunctionSearch * _grid[2];
  };

#endif

} // namespace ArrayCore

#endif // MUTTIARRAYFKLOOP_H

