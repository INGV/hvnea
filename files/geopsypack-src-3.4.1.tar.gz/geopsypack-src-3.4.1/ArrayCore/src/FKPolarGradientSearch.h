/***************************************************************************
**
**  This file is part of ArrayCore.
**
**  ArrayCore is free software: you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  ArrayCore is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with Foobar.  If not, see <http://www.gnu.org/licenses/>
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2019-07-01
**  Copyright: 2019
**    Marc Wathelet (ISTerre, Grenoble, France)
**
***************************************************************************/

#ifndef FKPOLARGRADIENTSEARCH_H
#define FKPOLARGRADIENTSEARCH_H

#include "FKGridSearch.h"
#include "ArrayCoreDLLExport.h"

namespace ArrayCore {
#if 0
  class ARRAYCORE_EXPORT FKPolarGradientSearch : public FKGridSearch
  {
  public:
    FKPolarGradientSearch();
    ~FKPolarGradientSearch();

    void setGrid(const Point& gridSize);
    void localMax(int nMax, double absThres, double relThres);

  private:
    struct State {
      int i;
      Point p;
      Point dp;
      FKPower fkp;
    };
    State _s1, _s2;
    FKPower _refinep;

    //int nextGridIndex(const State * s);
    //void scaleStep(Point& step, const Point& maxStep);

    //void gridClimbing(int startGridIndex);
    void freeClimbing(Point p, double step, const Point& p0);
    void refineMax(Point p, Point px);

    bool * _visited;
    int * _searchGridIndexList;
    int _searchGridCount;
    Point _gridSize;
    double _cacheGridStep, _invCacheGridStep, _climbStep, _minStep, _maxClimb;
  };
#endif

} // namespace ArrayCore
#endif // FKPOLARGRADIENTSEARCH_H

