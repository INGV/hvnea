#if defined __cplusplus
#include <QtCore>
#ifndef Q_OS_MAC
#include <QGpCoreTools.h>
#include <QGpCoreMath.h>
#include <GeopsyCore.h>
#include <QGpCoreWave.h>
#include <DinverCore.h>
#include <DinverDCCore.h>
#include <QGpCompatibility.h>
#include <QGpCoreStat.h>
#endif // Q_OS_MAC
#endif // __cplusplus
