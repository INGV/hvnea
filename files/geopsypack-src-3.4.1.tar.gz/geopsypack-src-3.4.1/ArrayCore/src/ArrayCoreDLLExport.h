#ifndef ARRAYCOREDLLEXPORT_H
#define ARRAYCOREDLLEXPORT_H

/* *_STATIC and MAKE_*_DLL are defined by the capitalization of
  the package name, included in the compiler options (only for Windows).
  Use directly WIN32 to allow transparent usage with or without Qt.
  ArrayCoreStatic.h may contain ARRAYCORE_STATIC macro definition.
  This define was introduced there to mark this library as static for
  all projects that link to this library.
*/

#include "ArrayCoreStatic.h"

#if defined(WIN32) && !defined(ARRAYCORE_STATIC)
#ifdef MAKE_ARRAYCORE_DLL
# define ARRAYCORE_EXPORT __declspec(dllexport)
#else
# define ARRAYCORE_EXPORT __declspec(dllimport)
#endif
#else
# define ARRAYCORE_EXPORT
#endif

#endif  // ARRAYCOREDLLEXPORT_H

