#ifndef GEOPSYSLINK_HEADERS
#define GEOPSYSLINK_HEADERS

// All headers of GeopsySLink library

#include "GeopsySLinkDLLExport.h"
#include "SeedLink.h"
#include "SeedLinkServer.h"
#include "SeedLinkStation.h"
#include "SeedLinkStream.h"

#ifndef GP_EXPLICIT_LIBRARY_NAMESPACE
using namespace GeopsySLink;
#endif

#endif // GEOPSYSLINK_HEADERS
