#ifndef ARRAYGUIDLLEXPORT_H
#define ARRAYGUIDLLEXPORT_H

/* *_STATIC and MAKE_*_DLL are defined by the capitalization of
  the package name, included in the compiler options (only for Windows).
  Use directly WIN32 to allow transparent usage with or without Qt.
  ArrayGuiStatic.h may contain ARRAYGUI_STATIC macro definition.
  This define was introduced there to mark this library as static for
  all projects that link to this library.
*/

#include "ArrayGuiStatic.h"

#if defined(WIN32) && !defined(ARRAYGUI_STATIC)
#ifdef MAKE_ARRAYGUI_DLL
# define ARRAYGUI_EXPORT __declspec(dllexport)
#else
# define ARRAYGUI_EXPORT __declspec(dllimport)
#endif
#else
# define ARRAYGUI_EXPORT
#endif

#endif  // ARRAYGUIDLLEXPORT_H

