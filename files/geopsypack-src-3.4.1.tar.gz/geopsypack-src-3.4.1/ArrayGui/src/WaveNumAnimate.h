/***************************************************************************
**
**  This file is part of ArrayGui.
**
**  ArrayGui is free software: you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  ArrayGui is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with Foobar.  If not, see <http://www.gnu.org/licenses/>
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2005-12-15
**  Copyright: 2005-2019
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef WAVENUMANIMATE_H
#define WAVENUMANIMATE_H

#include "ui_WaveNumAnimate.h"

namespace ArrayGui {

class WaveNumAnimate : public QWidget, public Ui::WaveNumAnimate
{
  Q_OBJECT
public:
  WaveNumAnimate(QWidget *parent=nullptr, Qt::WindowFlags f=Qt::Widget);
};

} // namespace ArrayGui

#endif // WAVENUMANIMATE_H
