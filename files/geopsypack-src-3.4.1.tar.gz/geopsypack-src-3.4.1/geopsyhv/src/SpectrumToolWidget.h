/***************************************************************************
**
**  This file is part of geopsyhv.
**
**  geopsyhv is free software: you can redistribute it and/or modify
**  it under the terms of the GNU General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  geopsyhv is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU General Public License for more details.
**
**  You should have received a copy of the GNU General Public License
**  along with Foobar.  If not, see <http://www.gnu.org/licenses/>
**
**  See http://www.geopsy.org for more information.
**
**  Created: 2007-08-17
**  Copyright: 2007-2019
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef SPECTRUMTOOLWIDGET_H
#define SPECTRUMTOOLWIDGET_H

#include <HVGui.h>

class SpectrumToolWidget : public AbstractHVWidget
{
  Q_OBJECT
public:
  SpectrumToolWidget(QWidget * parent);

  bool setSubPool(SubSignalPool * subPool);
protected:
  virtual AbstractResultSheet * createResultSheet();
  virtual AbstractSummary * createSummary();
};

#endif // SPECTRUMTOOLWIDGET_H
