<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbTFAPlugin</name>
    <message>
        <location filename="../src/qtbtfaplugin.cpp" line="34"/>
        <location filename="../src/qtbtfaplugin.h" line="37"/>
        <source>Time frequency analysis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbTFAResults</name>
    <message>
        <location filename="../src/qtbtfaresults.cpp" line="79"/>
        <source>Amplitude</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtfaresults.cpp" line="105"/>
        <source>Signal %1 : Morlet wavelet convolution at %2 Hz</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolTFA</name>
    <message>
        <location filename="../src/qtbtooltfa.cpp" line="119"/>
        <source>Computation stopped</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbToolTFAd</name>
    <message>
        <location filename="../src/qtbtooltfad.cpp" line="42"/>
        <source> Hz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.cpp" line="47"/>
        <source>This is just for computing the resolution in time and frequency. It has no influence on the computation of the Morlet transform.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.ui" line="13"/>
        <source>TFA toolbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.ui" line="31"/>
        <source>Time limits</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.ui" line="58"/>
        <source>Frequency sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.ui" line="70"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Modified Morlet Wavelet in spectral domain:&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;M(f) = 1/pow(pi,0.25)*exp( (w0*f/fi - w0 )^2 * m )&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;w0, m0 are the wavelet parameters. Theoretically w0&amp;gt;5.5. A typical value for w0 is 6. A typical value for m0 is 10.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;fi is the analysed frequency.&lt;/p&gt;
&lt;p style=&quot;-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.ui" line="83"/>
        <source>Wavelet parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.ui" line="112"/>
        <source>Load parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.ui" line="135"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtooltfad.ui" line="145"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
