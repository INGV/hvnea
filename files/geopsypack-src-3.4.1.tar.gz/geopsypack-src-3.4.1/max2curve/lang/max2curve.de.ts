<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QtbFKMaxAzimuth</name>
    <message>
        <location filename="../src/qtbfkmaxazimuth.cpp" line="64"/>
        <source>Load FKMax file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkmaxazimuth.cpp" line="65"/>
        <source>Cap output file(*.max)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkmaxazimuth.cpp" line="91"/>
        <source>Loading .max file (FK)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkmaxazimuth.cpp" line="93"/>
        <source>Impossible to access to file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkmaxazimuth.cpp" line="117"/>
        <source>Only polar-slowness grids can be loaded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkmaxazimuth.cpp" line="149"/>
        <source>It seems that the file contains a number of frequency bands different than specified in the first header. If you concatenate various files, make sure that they have the same set of frequency bands.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkmaxazimuth.ui" line="16"/>
        <source>FK Azimuth histogram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkmaxazimuth.ui" line="30"/>
        <source>Load</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkmaxazimuth.ui" line="53"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbFKOptions</name>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="13"/>
        <source>FK options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="37"/>
        <source>Sample selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="98"/>
        <location filename="../src/qtbfkoptions.ui" line="137"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="146"/>
        <source>0% means all windows, 85% means all
windows which power is greater than
min+0.85*(max-min).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="161"/>
        <source>Histogram properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="199"/>
        <source>Minimum velocity (m/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="234"/>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="263"/>
        <source>Maximum velocity (m/s)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="298"/>
        <source>3000</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="327"/>
        <source>Number of velocity classes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="368"/>
        <source>Velocity is for convenience only, internal
statistics are computed in slowness.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="58"/>
        <source>Keep only windows with highest power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="91"/>
        <source>Semblance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfkoptions.ui" line="130"/>
        <source>Beam power</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbFreqVelocityFilter</name>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="13"/>
        <source>Frequency-Velocity histogram filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="45"/>
        <source>Minimum probability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="76"/>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="96"/>
        <source>Wavenumber range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="145"/>
        <source>k&lt;font size=&quot;-1&quot;&gt;min&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="160"/>
        <source>0.05</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="170"/>
        <source>k&lt;font size=&quot;-1&quot;&gt;max&lt;/font&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="185"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="200"/>
        <source>Values excluded are set to null and the grid is re-normalized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="247"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbfreqvelocityfilter.ui" line="263"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbGenericOptions</name>
    <message>
        <location filename="../src/qtbgenericoptions.ui" line="13"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbgenericoptions.ui" line="19"/>
        <source>X sampling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbgenericoptions.ui" line="31"/>
        <source>Y sampling</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbHistogram</name>
    <message>
        <location filename="../src/qtbhistogram.ui" line="27"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Discard some samples from histogram&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.ui" line="33"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.ui" line="40"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Smooth histogram&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.ui" line="46"/>
        <source>Smooth</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.ui" line="53"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Save currently selected samples&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.ui" line="59"/>
        <source>Save </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.ui" line="82"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.cpp" line="87"/>
        <source>&amp;Adjust</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.cpp" line="87"/>
        <source>Adjust current curve to the closest maximum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.cpp" line="489"/>
        <source>max file (*.max)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.cpp" line="489"/>
        <source>Saving max file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.ui" line="13"/>
        <source>max2curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbhistogram.cpp" line="251"/>
        <source>Null or negative values not allowed for log scales, back to linear scale</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbMaxEntryList</name>
    <message>
        <location filename="../src/qtbmaxentrylist.cpp" line="56"/>
        <source>Loading max file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmaxentrylist.cpp" line="57"/>
        <location filename="../src/qtbmaxentrylist.cpp" line="129"/>
        <source>Impossible to access to file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmaxentrylist.cpp" line="122"/>
        <location filename="../src/qtbmaxentrylist.cpp" line="128"/>
        <source>Saving max file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbmaxentrylist.cpp" line="123"/>
        <source>Null number of entries, nothing written</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbSPACOptions</name>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="13"/>
        <source>Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="25"/>
        <source>Sample selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="40"/>
        <source>Ring index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="47"/>
        <source>Component index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="60"/>
        <source>Histogram properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="80"/>
        <source>Minimum value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="117"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="137"/>
        <source>Maximum value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="174"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbspacoptions.ui" line="194"/>
        <source>Number of value classes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbStatGridAnalyser</name>
    <message>
        <location filename="../src/qtbstatgridanalyser.cpp" line="173"/>
        <location filename="../src/qtbstatgridanalyser.cpp" line="189"/>
        <source>Pick bands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.cpp" line="173"/>
        <location filename="../src/qtbstatgridanalyser.cpp" line="189"/>
        <source>Define the frequency band to rejet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.ui" line="13"/>
        <source>Grid Statistics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.ui" line="43"/>
        <source>Mean stddev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.ui" line="131"/>
        <source>Reject all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.ui" line="138"/>
        <source>Undo all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.ui" line="145"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You can also use Left, Right arrows to change reject band (combined also with SHIFT). Up and down arrows can be used to scroll frequencies. If SHIFT is pressed down with Up or Down, the current frequency is rejected.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.ui" line="151"/>
        <source>Reject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.ui" line="158"/>
        <source>Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.cpp" line="54"/>
        <location filename="../src/qtbstatgridanalyser.ui" line="165"/>
        <source>Curve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.cpp" line="59"/>
        <source>&amp;Mean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.cpp" line="62"/>
        <source>Medi&amp;an</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.cpp" line="65"/>
        <source>Mo&amp;de</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbstatgridanalyser.cpp" line="302"/>
        <source>Average %1 %7 - Stddev %2 %7
Median %3 %7 - Meddev %4 %7
Mode %5 %7 - Moddev %6 %7</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtbTFAOptions</name>
    <message>
        <location filename="../src/qtbtfaoptions.ui" line="13"/>
        <source>TFA Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtfaoptions.ui" line="19"/>
        <source>Event selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtfaoptions.ui" line="36"/>
        <source>Number of peaks per minute</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtfaoptions.ui" line="64"/>
        <source>Histogram properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtfaoptions.ui" line="78"/>
        <source>Minimum value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtfaoptions.ui" line="124"/>
        <source>Maximum value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/qtbtfaoptions.ui" line="167"/>
        <source>Number of value classes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../src/main.cpp" line="114"/>
        <source>max2curve: bad option %1, see -help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="136"/>
        <source>Minimum and maximum are equal. These values must be defined by options -min and -max, see -help for details.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="144"/>
        <location filename="../src/main.cpp" line="160"/>
        <source>Loading max file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="145"/>
        <source>max file (*.max)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="161"/>
        <source>No max result can be loaded</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
