/***************************************************************************
**
**  This file is part of max2curve.
**
**  This file may be distributed and/or modified under the terms of the
**  GNU General Public License version 2 or 3 as published by the Free
**  Software Foundation and appearing in the file LICENSE.GPL included
**  in the packaging of this file.
**
**  This file is distributed in the hope that it will be useful, but WITHOUT
**  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
**  FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
**  more details.
**
**  You should have received a copy of the GNU General Public License
**  along with this program. If not, see <http://www.gnu.org/licenses/>.
**
**  See http://www.geopsy.org for more information.
**
**  Created : 2007-07-09
**  Authors:
**    Marc Wathelet
**    Marc Wathelet (LGIT, Grenoble, France)
**
***************************************************************************/

#ifndef CURVEMAXENTRY_H
#define CURVEMAXENTRY_H

#include "MaxEntry.h"

class CurveMaxEntry : public MaxEntry
{
public:
  virtual bool readLine(QTextStream& s);
  virtual void writeHeader(QTextStream& s) const;
  virtual void writeLine(QTextStream& s) const;
  static QByteArray fields();
  static bool isHeaderLine(QString f);

  virtual bool operator<(const MaxEntry& o) const;

  virtual double value() const {return _y;}
  double y() const {return _y;}
private:
  double _y;
};

#endif // CURVEMAXENTRY_H
