#include	<sys/types.h>
#include	<sys/stat.h>
#define		OPENREADONLY	"r"
#define		OPENREADAPPEND	"r+"
#define		OPENWRITEAPPEND	"w+"
#ifndef __STDC__
#define size_t int
#define const 
#endif

#include	<string.h>
