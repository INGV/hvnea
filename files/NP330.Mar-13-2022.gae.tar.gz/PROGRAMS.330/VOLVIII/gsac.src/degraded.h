		{LOGLIN, "LOGLIN", &gsac_set_param_plotctl, &gsac_exec_plotctl, help_loglin},
		{LOGLOG, "LOGLOG", &gsac_set_param_plotctl, &gsac_exec_plotctl, help_loglog},
