static char *gsac_version ="GSAC - Computer Programs in Seismology [V1.1.5l 12 DEC 2021]\n       Copyright 2004-2021 R. B. Herrmann";

