#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-10-05
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################

# WS_CENTERS="https://www.fdsn.org/ws/datacenters/1/query"
WS_DATA="fdsnws-dataselect-1"
WS_STAT="fdsnws-station-1"
WS_EVNT="fdsnws-event-1"
WS_QUERY="/query?"
WS_QUERY0="/query"

CFG_WS_DATA_LIST="data_centers"
CFG_WS_DATA_CENT="data_center"
CFG_WS_DATA_SITE="data_site"
CFG_WS_DATA_DESC="data_desc"
CFG_WS_EVNT_CENT="event_center"
CFG_WS_EVNT_SITE="event_site"
CFG_WS_EVNT_DESC="event_desc"
CFG_WS_DATA="ws_data"
CFG_WS_STAT="ws_station"
CFG_WS_EVNT="ws_event"

# field separator in station info
WS_SEP="|"

# output field separator in ws_get_station_info, ws_parse_dless, perhaps other
WS_SEQ="#"

# field positions in station, level channel
# Network | Station | location | Channel | Latitude | Longitude | Elevation | Depth | 
# Azimuth | Dip | SensorDescription | Scale | ScaleFreq | ScaleUnits | SampleRate | StartTime | EndTime
declare -A WS_INFO_COLS=( ['net']=1 ['sta']=2 ['loc']=3 ['cha']=4 ['lat']=5 ['lon']=6 ['ele']=7 ['dep']=8 \
['azi']=9 ['dip']=10 ['dsc']=11 ['sns']=12 ['frq']=13 ['unt']=14 ['sps']=15 ['dat']=16 ['end']=17 )

# field positions in station, level station
# Network | Station | Latitude | Longitude | Elevation | SiteName | StartTime | EndTime
# declare -A WS_INFO_COLZ=( ['net']=1 ['sta']=2 ['lat']=3 ['lon']=4 ['ele']=5 ['nam']=6 ['dat']=7 ['end']=8 )

# output field positions in ws_get_station_info and ws_parse_dless;
# net sta loc cha lat lon ele sns frq dat end sps
declare -A WS_INFO_S=( ['net']=1 ['sta']=2 ['loc']=3 ['cha']=4 ['lat']=5 ['lon']=6 \
['ele']=7 ['sns']=8 ['frq']=9 ['dat']=10 ['end']=11 ['sps']=12 )

# some useful constants
WS_DFMT="%Y-%m-%dT%H:%M:%S"
WS_DATA0="1970-01-01T00:00:00"
WS_DATAF="2050-12-31T00:00:00"
WS_EARTH_RADIUS=6371

# maximum depth of an event
((WS_MAX_DEPTH=1000))
# maximum number of events to be analyzed
((WS_MAX_EVTS=15000))
# maximum distance of an event from the station
((WS_MAX_DIST_EVT=500))
# events list separator
WS_EVT_LIST_SEP="|"

ev_list_sep="ev_list_sep"
ev_list_fprefx="ev_list_col_"
# declare -A ev_list_fields=( ['idv']=1 ['dat']=2 ['lat']=3 ['lon']=4 ['dep']=5 ['mag']=6 ['tmg']=7 )
# ev_list_fields['baz']=$((${#ev_list_fields[@]}+1)); ev_list_fields['dst']=$((${#ev_list_fields[@]}+1))
declare -A ev_list_fields=( ['idv']=1 ['dat']=2 ['lat']=3 ['lon']=4 ['dep']=5 ['mag']=6 ['tmg']=7 ['baz']=8 ['dst']=9 )
# -------------------------------------------------------------------------------------------------------------------------------
# perhaps lnet is not needed (it should be in B050F16); to verify
ws_parse_dless()
{
	local lnet=$1 ldless=$2
	[ -z "${ldless}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lerr
	((lerr=0))
	[ ! -s ${ldless} ] && { echo -e "\nfile ${ldless} does not exist or is empty" >/dev/stderr; return 1; }

	rdseed -s -f ${ldless} | awk -vnet=${lnet} -vld0="${WS_DATA0}" -vld1="${WS_DATAF}" -vlft=${WS_DFMT} '
	/^B050F03/ { sta = $NF; datastaz_da = ld0; datastaz_a = ld1 }
	/^B050F13/ {
		split($NF, t, "[:,.]"); d = mktime(t[1]" 1 "t[2]" "t[3]" "t[4]" "t[5], 1);
		if (d != -1) { datastaz_da = strftime(lft, d, 1) }
	}
	/^B050F14/ {
		split($NF, t, "[:,.]"); d = mktime(t[1]" 1 "t[2]" "t[3]" "t[4]" "t[5], 1);
		if (d != -1) { datastaz_a = strftime(lft, d, 1) }
	}
	/^B052F04/ { cha = $NF }
	/^B052F03/ { gsub(/[ \t]/, ""); split($0, t, ":"); loc = t[2] }
	/^B052F10/ { lat = $NF }
	/^B052F11/ { lon = $3 }
	/^B052F12/ { ele = $NF }
	# dep, azi, dip are not included in the result
	/^B052F13/ { dep = $NF }
	/^B052F14/ { azi = $NF }
	/^B052F15/ { dip = $NF + 90 }
	/^B052F18/ { sps = $NF }
	/^B052F22/ {
		split($NF, t, "[:,.]"); d = mktime(t[1]" 1 "t[2]" "t[3]" "t[4]" "t[5], 1);
		dat = (d != -1) ? strftime(lft, d, 1) : datastaz_da;
	}
	/^B052F23/ {
		split($NF, t, "[:,.]"); d = mktime(t[1]" 1 "t[2]" "t[3]" "t[4]" "t[5], 1);
		end = (d != -1) ? strftime(lft, d, 1) : datastaz_a;
	}
	/^B058F03/||/^B060F04/ { stage = $NF }
	/^B058F04/||/^B048F05/ { if (stage == 0) { sns = $NF } }
	/^B058F05/||/^B048F06/ {
		if (stage == 0)
		{
			split($0, t, "[:]"); frq = t[2]; gsub(/^[ \t]+/, "", frq); gsub(/[ \t]+$/, "", frq);
			split(frq, t, "[ \t]"); frq = t[1];
			printf "%s#%s#%s#%s#%s#%s#%s#%1.6E#%1.6E#%s#%s#%s\n", 
			net, sta, loc, cha, lat, lon, ele, sns, frq, dat, end, sps;
			loc = ""; cha = ""; lat = ""; lon = ""; ele = ""; sns = 1; frq = 0; sps = 1;
		}
	}
	'
	((lerr=$?))

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_set_par()
{
	local lcfg=$1 lpar=$2 lval=$3
	[ ! -z "${lcfg}" ] && echo -ne "${lcfg}\n"; echo "${lpar} ${lval}"
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_get_par()
{
	local lcfg=$1 lpar=$2
	echo "${lcfg}" | awk '/^'${lpar}' / {$1 = ""; print}' | xargs
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_get_data_from()
{
	local lcfg=$1
	[ -z "${lcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	ws_get_par "${lcfg}" ${CFG_WS_DATA_DESC}
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_get_evnt_from()
{
	local lcfg=$1
	[ -z "${lcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	ws_get_par "${lcfg}" ${CFG_WS_EVNT_DESC}
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves ws configuration
ws_load_cfg()
{
	local lfcfg lstr lc0 lerr
	local llist lcntr lcntq lflagd lflagv
	# lflagd is to decide whether to retrieve data and station services (1) or not (other);
	# lflagv is to decide whether to retrieve event service (1) or not (other)
	lfcfg=$1; lflagd=$2; lflagv=$3; ((lerr=0))
	[ -z "${lflagv}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	lflagd=$(echo ${lflagd} | awk '{printf "%d", $1}'); lflagv=$(echo ${lflagv} | awk '{printf "%d", $1}')
	[ ${lflagd} -eq 0 -a ${lflagv} -eq 0 ] && return 0
	[ -f ${lfcfg} -a -s ${lfcfg} ] || \
	{ echo "${FUNCNAME}: file ${lfcfg} does not exist or is empty" >/dev/stderr; return 1; }
	lc0=$(awk -vFS='[[:blank:]]*=[[:blank:]]*' '!/^#/ {gsub(/["\047;\\\t<>$* ]/, ""); print}' ${lfcfg})
	echo "checking ws configuration in ${lfcfg}..." >/dev/stderr
	llist=$(echo "${lc0}" | awk '/^'${CFG_WS_DATA_LIST}'=/' | awk -vFS== 'END {print $2}')
	[ ! -z "${llist}" ] && lstr=$(ws_set_par "${lstr}" ${CFG_WS_DATA_LIST} ${llist}) || \
	{ echo -e "\n${CFG_WS_DATA_LIST} missing" >/dev/stderr; ((lerr+=1)); }
	if [ ${lflagd} -eq 1 ]; then
		lcntr=$(echo "${lc0}" | awk '/^'${CFG_WS_DATA_CENT}'=/' | awk -vFS== 'END {print $2}')
		[ ! -z "${lcntr}" ] && lstr=$(ws_set_par "${lstr}" ${CFG_WS_DATA_CENT} ${lcntr}) || \
		{ echo -e "\n${CFG_WS_DATA_CENT} missing" >/dev/stderr; ((lerr+=1)); }
	fi
	if [ ${lflagv} -eq 1 ]; then
		lcntq=$(echo "${lc0}" | awk '/^'${CFG_WS_EVNT_CENT}'=/' | awk -vFS== 'END {print $2}')
		[ ! -z "${lcntq}" ] && lstr=$(ws_set_par "${lstr}" ${CFG_WS_EVNT_CENT} ${lcntq}) || \
		{ echo -e "\n${CFG_WS_EVNT_CENT} missing" >/dev/stderr; ((lerr+=1)); }
	fi
	[ ${lerr} -eq 0 ] && echo "${lstr}"
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves ws links; maybe it would be better joined with ws_load_cfg
ws_get_links()
{
	local lcfg=$1
	[ -z "${lcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local llist lcntr lcntq
	local ljson lcent lsrvs lnam ldsc lurl lval
	local lstr lerr
	((lerr=0))

	llist=$(ws_get_par "${lcfg}" ${CFG_WS_DATA_LIST})
	[ -z "${llist}" ] && { echo "${FUNCNAME}: data center list is empty" >/dev/stderr; return 1; }
	lcntr=$(ws_get_par "${lcfg}" ${CFG_WS_DATA_CENT}); lcntq=$(ws_get_par "${lcfg}" ${CFG_WS_EVNT_CENT})
	if [ ! -z "${lcntr}" ]; then
		# retrieves information on data center
		ljson=$(wget -nv -a /dev/stderr -O - --no-check-certificate ${llist}"?name="${lcntr}) && \
		lcent=$(echo "${ljson}" | jq -e '.datacenters[0]') && \
		lsrvs=$(echo "${lcent}" | jq -e '.repositories[0] | .services') && \
		lnam=$(echo "${lcent}" | jq -e -r '.name') && \
		ldsc=$(echo "${lcent}" | jq -e -r '.fullName') && \
		lurl=$(echo "${lcent}" | jq -e -r '.website') && \
		lstr=$(ws_set_par "${lstr}" ${CFG_WS_DATA_CENT} "${lnam}") && \
		lstr=$(ws_set_par "${lstr}" ${CFG_WS_DATA_DESC} "${ldsc}") && \
		lstr=$(ws_set_par "${lstr}" ${CFG_WS_DATA_SITE} "${lurl}") && \
		lval=$(echo "${lsrvs}" | jq -e -r --arg n ${WS_DATA} '.[] | select(.name==$n) | .url') && \
		lval=${lval%%/}${WS_QUERY} && \
		lstr=$(ws_set_par "${lstr}" ${CFG_WS_DATA} "${lval}") && \
		lval=$(echo "${lsrvs}" | jq -e -r --arg n ${WS_STAT} '.[] | select(.name==$n) | .url') && \
		lval=${lval%%/}${WS_QUERY} && \
		lstr=$(ws_set_par "${lstr}" ${CFG_WS_STAT} "${lval}")
		((lerr=$?))
	fi

	if [ ${lerr} -eq 0 -a ! -z "${lcntq}" ]; then
		# retrieves information on event center
		if [ ${lcntq} != "${lcntr}" ]; then
			ljson=$(wget -nv -a /dev/stderr -O - --no-check-certificate ${llist}"?name="${lcntq}); ((lerr=$?))
			if [ ${lerr} -eq 0 ]; then
				lcent=$(echo "${ljson}" | jq -e '.datacenters[0]') && \
				lsrvs=$(echo "${lcent}" | jq -e '.repositories[0] | .services') && \
				lnam=$(echo "${lcent}" | jq -e -r '.name') && \
				ldsc=$(echo "${lcent}" | jq -e -r '.fullName') && \
				lurl=$(echo "${lcent}" | jq -e -r '.website'); ((lerr=$?))
			fi
		fi
		if [ ${lerr} -eq 0 ]; then
			lstr=$(ws_set_par "${lstr}" ${CFG_WS_EVNT_CENT} "${lnam}") && \
			lstr=$(ws_set_par "${lstr}" ${CFG_WS_EVNT_DESC} "${ldsc}") && \
			lstr=$(ws_set_par "${lstr}" ${CFG_WS_EVNT_SITE} "${lurl}") && \
			lval=$(echo "${lsrvs}" | jq -e -r --arg n ${WS_EVNT} '.[] | select(.name==$n) | .url') && \
			lval=${lval%%/}${WS_QUERY} && \
			lstr=$(ws_set_par "${lstr}" ${CFG_WS_EVNT} "${lval}"); ((lerr=$?))
		fi
	fi
	[ ${lerr} -eq 0 ] && echo "${lstr}" || echo -e "\nerror while retrieving ws links" >/dev/stderr
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_get_station_info()
{
	local lsrvs=$1 lnet=$2 lsta=$3 lcha=$4
	# maybe we could check that lsta (not lcha) is not empty
	[ -z "${lcha}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lstainfo=""
	local lsrvx lnsrvs lidx llink lrows lstrx lstmp
	local lerr lerx
	((lerr=0))

	lsrvs=$(echo "${lsrvs}" | awk -vFS="?" '{print $1}' | sort -u)
	lnsrvs=$(echo -n "${lsrvs}" | awk 'END {print NR}')
	for lidx in $(seq 1 ${lnsrvs})
	do
		llink=$(echo "${lsrvs}" | awk -vi=${lidx} 'NR==i')
		# composes string for download, but also allows empty strings (to see above and decide)
		# echo "llink $llink" >/dev/stderr
		lstmp=${llink}"?level=channel&format=text"
		# echo "lstmp $lstmp" >/dev/stderr
		[ ! -z "${lnet}" ] && lstmp="${lstmp}&net=${lnet}"
		[ ! -z "${lsta}" ] && lstmp="${lstmp}&sta=${lsta}"
		[ ! -z "${lcha}" ] && lstmp="${lstmp}&cha=${lcha}"
		# just to be safe uses /dev/stderr, it shouldn't be necessary
		lstrx=$(wget -nv -a /dev/stderr -O - "${lstmp}"); ((lerx=$?)); ((lerr+=${lerx}))
		# echo "lstrx $lstrx" >/dev/stderr; return 1
		# if something goes wrong it breaks
		[ ${lerx} -ne 0 ] && break
		if [ ! -z "${lstrx}" ]; then
			lrows=$(echo "${lstrx}" | awk -vFS="${WS_SEP}" -vOFS="${WS_SEQ}" -ve="${WS_DATAF}" \
			'!/^#/ { end = $'${WS_INFO_COLS['end']}'; if (end == "") {end = e}; print \
			$'${WS_INFO_COLS['net']}', $'${WS_INFO_COLS['sta']}', $'${WS_INFO_COLS['loc']}', \
			$'${WS_INFO_COLS['cha']}', $'${WS_INFO_COLS['lat']}', $'${WS_INFO_COLS['lon']}', \
			$'${WS_INFO_COLS['ele']}', $'${WS_INFO_COLS['sns']}', $'${WS_INFO_COLS['frq']}', \
			$'${WS_INFO_COLS['dat']}', end, $'${WS_INFO_COLS['sps']}'}')
			lstainfo=$(echo -e "${lstainfo}\n${lrows}")
			# echo "lrows $lrows" >/dev/stderr; return 1
		fi
	done
	if [ ${lerr} -eq 0 ]; then
		if [ -z "${lstainfo}" ]; then
			echo -e "\nperhaps triple ${lnet}/${lsta}/${lcha} does not exist" >/dev/stderr; ((lerr+=1))
		else
			lstainfo=${lstainfo:1}; echo "${lstainfo}"
		fi
	fi
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_check_station_info()
{
	local lxsf=$1 lflag=$2
	local lcha lcmp lstm
	local ltmp ltmq
	local lerr
	((lerr=0))

	# selects the fields we need (cha, sns, frq, sps)
	lxsf=$(echo "${lxsf}" | awk -vc=${WS_INFO_S['cha']} -vs=${WS_INFO_S['sns']} -vq=${WS_INFO_S['frq']} -vf=${WS_INFO_S['sps']} \
	-vFS="${WS_SEQ}" -vOFS="${WS_SEQ}" '{print $c, $s, $q, $f}')

	# checks number of channels
	lcha=$(echo "${lxsf}" | awk -vFS="${WS_SEQ}" '{print $1}' | sort -u)
	[ $(echo -n "${lcha}" | awk 'END {print NR}') -ne 3 ] && { echo -e "\nchannels are not three, skipping"; ((lerr+=1)); }

	# checks components
	# lcmp=$(echo "${lcha}" | awk '{print substr($1, 3)}' | sort -u | tr -d "\n")
	# [ ${lerr} -eq 0 ] && [ "${lcmp}" != "ENZ" ] && { echo -e "\ncomponents are not the standard ones, skipping"; ((lerr+=1)); }

	# checks uniqueness of the stream (superfluous for now, but you never know)
	lstm=$(echo "${lcha}" | awk '{print substr($1, 1, 2)}' | sort -u); ltmq=$(echo -n "${lstm}" | awk 'END {print NR}')
	[ ${lerr} -eq 0 ] && [ ${ltmq} -gt 1 ] && { echo -e "\nthe streams are not equal, skipping"; ((lerr+=1)); }

	# checks that cfg does not change
	ltmq=$(echo -n "${lxsf}" | awk 'END {print NR}')
	[ ${lerr} -eq 0 ] && [ ${ltmq} -gt 3 ] && { echo -e "\nconfiguration changes detected, skipping"; ((lerr+=1)); }

	# checks that fg are the same
	ltmp=$(echo "${lxsf}" | awk -vFS="${WS_SEQ}" -vORS=" " '{print $3}' | awk '$1==$2 && $1==$3')
	[ ${lerr} -eq 0 ] && [ -z "${ltmp}" ] && { echo -e "\nthe frequencies are not equal, skipping"; ((lerr+=1)); }

	# checks that sens are the same
	# if [ "${lflag}" == "1" ]; then
	# 	ltmp=$(echo "${lxsf}" | awk -vFS="${WS_SEQ}" -vORS=" " '{print $2}' | awk '$1==$2 && $1==$3')
	# 	[ ${lerr} -eq 0 ] && [ -z "${ltmp}" ] && { echo -e "\nthe sensitivities are not equal, skipping"; ((lerr+=1)); }
	# fi

	# checks that sps are the same
	ltmp=$(echo "${lxsf}" | awk -vFS="${WS_SEQ}" -vORS=" " '{print $4}' | awk '$1==$2 && $1==$3')
	[ ${lerr} -eq 0 ] && [ -z "${ltmp}" ] && { echo -e "\nthe sampling frequencies are not equal, skipping"; ((lerr+=1)); }

	# checks that fg are non-zero; it should only be done for velocimeters, commented for now
	# if [ ${lstm:1} == "H" ]; then
	# 	ltmp=$(echo "${lxsf}" | awk -vFS="${WS_SEQ}" '$3 == 0 {print}')
	# 	[ ${lerr} -eq 0 ] && [ ! -z "${ltmp}" ] && { echo -e "\nfound some frequencies equal to zero, skipping"; ((lerr+=1)); }
	# fi

	# checks that sens are non-zero
	ltmp=$(echo "${lxsf}" | awk -vFS="${WS_SEQ}" '$2 == 0')
	[ ${lerr} -eq 0 ] && [ ! -z "${ltmp}" ] && { echo -e "\nfound some sensitivities equal to zero, skipping"; ((lerr+=1)); }

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_check_comps()
{
	local lchs=$1
	local lcmp lerr
	((lerr=0))
	lcmp=$(echo "${lchs}" | awk '{print substr($1, 3)}' | sort -u | tr -d "\n")
	[ "${lcmp}" != "ENZ" ] && { echo -e "\ncomponents are not the standard ones"; ((lerr=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# selects some rows of a sta_info table based on d1, d2, net, sta, loc, str;
# the selected rows have an epoch contained in [d1 d2]
ws_select_stainfo()
{
	local lsinfo=$1 ld1=$2 ld2=$3 lnet=$4 lsta=$5 lloc=$6 lstr=$7
	[ -z "${ld2}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lerr lstrx
	((lerr=0))
	if [ ! -z "${lnet}" ]; then
		lstrx=${lstrx}${lnet}${WS_SEQ}
		if [ ! -z "${lsta}" ]; then
			lstrx=${lstrx}${lsta}${WS_SEQ}; lstrx=${lstrx}${lloc}${WS_SEQ}
			[ ! -z "${lstr}" ] && lstrx=${lstrx}${lstr}
		fi
	fi
	echo "${lsinfo}" | awk -vFS="${WS_SEQ}" -vf=${ld1} -vt=${ld2} -vd1=${WS_INFO_S['dat']} -vd2=${WS_INFO_S['end']} \
	'/^'${lstrx}'/ && $d1<=f && t<=$d2'
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
# get the coordinates of all triples net, sta, loc from a sta_info table based on net, sta
ws_info_coords()
{
	local lsinfo=$1 lnet=$2 lsta=$3
	[ -z "${lsta}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lns=${lnet}${WS_SEQ}${lsta}${WS_SEQ}
	echo "${lsinfo}" | awk '/^'${lns}'/' | awk -vFS="${WS_SEQ}" -vOFS="${WS_SEQ}" -vs1=${WS_INFO_S['net']} \
	-vs2=${WS_INFO_S['sta']} -vs3=${WS_INFO_S['loc']} -vc1=${WS_INFO_S['lat']} -vc2=${WS_INFO_S['lon']} -vc3=${WS_INFO_S['ele']} \
	'{print $s1, $s2, $s3, $c1, $c2, $c3}' | sort -u
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves sensitivity from a sta_info table based on net, sta, loc, cha
ws_info_sens()
{
	local lsinfo=$1 lnet=$2 lsta=$3 lloc=$4 lcha=$5
	[ -z "${lcha}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lnslc ltmp lsens lerr
	((lerr=0))
	lnslc=${lnet}${WS_SEQ}${lsta}${WS_SEQ}${lloc}${WS_SEQ}${lcha}
	ltmp=$(echo "${lsinfo}" | awk -vFS="${WS_SEQ}" -vc=${WS_INFO_S['sns']} '/^'${lnslc}'/ {print $c}')
	lsens=$(echo ${ltmp} | awk '$1 - 0 == $1 && $1 != 0')
	[ ! -z "${lsens}" ] && echo ${lsens} || \
	{ echo -e "\nsensitivity \"${ltmp}\" is not valid" >/dev/stderr; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves channel/sensitivity pairs from a sta_info table based on net, sta, loc, cha
ws_info_sens_m()
{
	local lsinfo=$1 lnet=$2 lsta=$3 lloc=$4 lcha=$5
	[ -z "${lsinfo}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lstrx ltmp lerr
	((lerr=0))
	if [ ! -z "${lnet}" ]; then
		lstrx=${lstrx}${lnet}${WS_SEQ}
		if [ ! -z "${lsta}" ]; then
			lstrx=${lstrx}${lsta}${WS_SEQ}; lstrx=${lstrx}${lloc}${WS_SEQ}
			[ ! -z "${lcha}" ] && lstrx=${lstrx}${lcha}${WS_SEQ}
		fi
	fi
	lsens=$(echo "${lsinfo}" | awk -vFS="${WS_SEQ}" -vc=${WS_INFO_S['cha']} -vs=${WS_INFO_S['sns']} \
	'/^'${lstrx}'/ {print $c, $s}')
	ltmp=$(echo "${lsens}" | awk '$2 - 0 != $2 || $2 == 0')
	[ -z "${ltmp}" ] && echo "${lsens}" || \
	{ echo -e "\nsensitivity:\n${lsens}\nis not valid" >/dev/stderr; ((lerr+=1)); }
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves channels from a sta_info table
ws_info_chans()
{
	local lsinfo=$1
	local lstrx
	[ -z "${lsinfo}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	lstrx=$(echo "${lsinfo}" | awk -vFS="${WS_SEQ}" -vc=${WS_INFO_S['cha']} '{print $c}' | sort -u)
	[ -z "${lstrx}" ] && return 1
	echo "${lstrx}"
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves net/sta/loc triples from a sta_info table based on date
ws_info_nsls()
{
	local lsinfo=$1 ld0=$2
	local lstrx
	[ -z "${ld0}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	lstrx=$(echo "${lsinfo}" | awk -vFS="${WS_SEQ}" -vOFS="${WS_SEQ}" -vd=${ld0} \
	-vi=${WS_INFO_S['dat']} -vj=${WS_INFO_S['end']} '$i <= d && d < $j {print $1, $2, $3}' | sort -u)
	[ -z "${lstrx}" ] && return 1
	echo "${lstrx}"
	return 0
}
# -------------------------------------------------------------------------------------------------------------------------------
# retrieves events based on input parameters
ws_get_evt_list()
{
	local llnkv ldt0 ldt1 lmg0 lmg1 llat llon ldst llist
	local OPTIND OPTARG
	while getopts :v:f:t:m:M:L:R:l:e: OPZ
	do
		case $OPZ in
			v) llnkv=${OPTARG} ;;
			f) ldt0=${OPTARG} ;;
			t) ldt1=${OPTARG} ;;
			m) lmg0=${OPTARG} ;;
			M) lmg1=${OPTARG} ;;
			R) ldst=${OPTARG} ;;
			L) llat=${OPTARG} ;;
			l) llon=${OPTARG} ;;
			e) llist=${OPTARG} ;;
			?) echo -e "${FUNCNAME}: invalid option -${OPTARG}"; return 1 ;;
		esac
	done
	[ -z "${llnkv}" -o -z "${ldt0}" -o -z "${ldt1}" -o -z "${lmg0}" -o -z "${lmg1}" \
	-o -z "${llat}" -o -z "${llon}" -o -z "${ldst}" -o -z "${llist}" ] && \
	{ echo -e "${FUNCNAME}: missing arguments"; return 1; }
	local lstrx lrds lerr
	((lerr=0))
	echo -e "\ngetting event list..."
	lrds=$(echo ${ldst} ${WS_EARTH_RADIUS} | awk '{print $1 * 360 / (2 * atan2(0, -1) * $2)}')
	lstrx=${linkv}"starttime=${ldt0}&endtime=${ldt1}&minmag=${lmg0}&maxmag=${lmg1}"
	lstrx=${lstrx}"&mindepth=-10&maxdepth=${WS_MAX_DEPTH}"
	lstrx=${lstrx}"&orderby=time-asc&lat=${llat}&lon=${llon}&maxradius=${lrds}&format=text&limit=${WS_MAX_EVTS}"
	wget -nv -a /dev/stdout -O ${llist} "${lstrx}"; ((lerr+=$?))
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# discards events at distance > ${WS_MAX_DIST_EVT} or at depth > ${WS_MAX_DEPTH}, and truncates to ${WS_MAX_EVTS}
ws_clean_evt_list()
{
	local llist=$1
	[ -z "${llist}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lstrx lneqk lneqh lerr
	((lerr=0))
	# lstrx=$(awk -vFS="${WS_EVT_LIST_SEP}" -vm=${WS_MAX_DIST_EVT} -vp=${WS_MAX_DEPTH} '/^#/ || $NF <= m && $5 <= p' ${llist}) && \
	lstrx=$(awk -vFS="${WS_EVT_LIST_SEP}" -vm=${WS_MAX_DIST_EVT} -vp=${WS_MAX_DEPTH} \
	-vjp=${ev_list_fields[dep]} -vjm=${ev_list_fields[dst]} '/^#/ || $jm <= m && $jp <= p' ${llist}) && \
	lstrx=$(echo "${lstrx}" | awk -vm=${WS_MAX_EVTS} 'NR <= m+1') && \
	lneqk=$(echo "${lstrx}" | awk 'END {print NR-1}') && \
	lneqh=$(awk -vn=${lneqk} 'END {print NR-1-n}' ${llist}); ((lerr=$?))
	if [ ${lerr} -eq 0 ]; then
	   echo "${lstrx}" >${llist}
		if [ ${lneqk} -eq 0 ]; then
			echo -e "\nno events found at distance <= ${WS_MAX_DIST_EVT} and depth <= ${WS_MAX_DEPTH}" >/dev/stderr
			((lerr+=1))
		else
			[ ${lneqh} -gt 0 ] && echo -e "\n${lneqh} events discarded" >/dev/stderr
		fi
	fi
	[ ${lerr} -eq 0 ] && echo ${lneqk}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# adds "baz" and "dist" fields to the event list
ws_enhance_evt_list()
{
	local lbult=$1 lstlo=$2 lstla=$3 ldtmp=$4 llist=$5
	[ -z "${llist}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lerr
	((lerr=0))
	local ldsts=${ldtmp}/boll_dists.txt
	echo "baz${WS_EVT_LIST_SEP}dst" >${ldsts} && \
	awk -vFS="${WS_EVT_LIST_SEP}" -vi=${ev_list_fields[lon]} -vj=${ev_list_fields[lat]} '!/^#/ {print $i, $j}' ${lbult} | \
	gmt mapproject -Ab${lstlo}/${lstla} -G${lstlo}/${lstla}+uk | \
	awk -vf="%d${WS_EVT_LIST_SEP}%.1f\n" '{printf f, $(NF-1), $NF}' >>${ldsts} && \
	paste -d "${WS_EVT_LIST_SEP}" ${lbult} ${ldsts} >${llist}; ((lerr=$?))
	rm -f ${ldsts}
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
# verifies that the list has the correct structure, and that it has at least one event;
# check all fields but date; creates a file with separator WS_EVT_LIST_SEP
# and columns sorted according to ev_list_fields; discards duplicate events
ws_conv_evt_list()
{
	local lfile lfilf lecfg
	lfile=$1; lfilf=$2; lecfg=$3
	[ -z "${lecfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	local lsep lhlist ln1 ln2 lnum lfldx lfldy lstrx lrows lerr
	local lfmt
	local -A lidxs
	((lerr=0))
	[ ! -f ${lfile} ] && { echo -e "\n${FUNCNAME}: ${lfile} does not exist"; return 1; }
	[ ! -s ${lfile} ] && { echo -e "\n${FUNCNAME}: no events found"; return 1; }

	lsep=$(ws_get_par "${lecfg}" ${ev_list_sep})

	# check that a header row is present
	lhlist=$(awk '/^#/ && NR==1' ${lfile} | tr -d " "); lhlist=${lhlist#"#"}
	[ -z "${lhlist}" ] && { echo -e "\nheader line is missing in ${lfile}"; return 1; }

	# check that the file has all the necessary fields (idv and tmg are not needed)
	for lfldx in ${!ev_list_fields[@]}
	do
		lfldy=${ev_list_fprefx}${lfldx}; lfldy=$(ws_get_par "${lecfg}" ${lfldy})
		lidxs[${lfldx}]=$(echo ${lhlist} | awk -vRS="${lsep}" -vv=${lfldy} '$1==v {print NR}' | tail -n1)
		if [ -z "${lidxs[${lfldx}]}" -a ${lfldx} != "idv" -a ${lfldx} != "tmg" -a ${lfldx} != "baz" -a ${lfldx} != "dst" ]; then
			echo -e "\nfield ${lfldy} missing in ${lfile}"; ((lerr+=1))
		fi
	done

	# check that the id is unique (it can be useful in the case of a local list)
	if [ ${lerr} -eq 0 -a ! -z "${lidxs[idv]}" ]; then
		ln1=$(awk -vFS="${lsep}" '!/^#/ {print $'${lidxs[idv]}'}' ${lfile} | sort -u | wc -l)
		ln2=$(awk '!/^#/' ${lfile} | awk 'END {print NR}')
		[ ${ln1} -ne ${ln2} ] && { echo -e "\nthe field \"id\" in ${lfile} must be unique"; ((lerr+=1)); }
	fi

	# verify that at least one event is present
	if [ ${lerr} -eq 0 ]; then
		lnum=$(awk '!/^#/' ${lfile} | awk 'END {print NR}')
		[ ${lnum} -eq 0 ] && { echo -e "\nno events found in ${lfile}"; ((lerr+=1)); }
	fi

	# rearrange columns (and check all fields but date)
	if [ ${lerr} -eq 0 ]; then
		awk '!/^#/' ${lfile} | \
		awk -vFS="${lsep}" -vOFS="${WS_EVT_LIST_SEP}" -vf=${lfilf} -vievt=${lidxs[idv]} -vidat=${lidxs[dat]} \
		-vilat=${lidxs[lat]} -vilon=${lidxs[lon]} -videp=${lidxs[dep]} -vimag=${lidxs[mag]} -vitmg=${lidxs[tmg]} \
		-vjevt=${ev_list_fields[idv]} -vjdat=${ev_list_fields[dat]} -vjlat=${ev_list_fields[lat]} -vjlon=${ev_list_fields[lon]} \
		-vjdep=${ev_list_fields[dep]} -vjmag=${ev_list_fields[mag]} -vjtmg=${ev_list_fields[tmg]} '!/^#/ 
		{
			if (!(ievt)) {evt = sprintf("%07d", NR)} else {evt = $ievt}
			dat = $idat
			lat = sprintf("%.5f", $ilat); lon = sprintf("%.5f", $ilon)
			dep = sprintf("%.1f", $idep); mag = sprintf("%.1f", $imag)
			if (!(itmg)) {tmg = ""} else {tmg = $itmg}
			xL = (lat-0==lat && -90<=lat && lat<=90); xl = (lon-0==lon && -180<=lon && lon<=180)
			xp = (dep-0==dep); xm = (mag-0==mag && 0<mag && mag<=10); $0 = ""
			if (xL && xl && xp && xm == 0) { print "row "NR" is not valid" >"/dev/stderr" }
			else { $jevt = evt; $jdat = dat; $jlat = lat; $jlon = lon; $jmag = mag; $jdep = dep; $jtmg = tmg; print >>f }
		}' >/dev/null
	fi	

	# retrieves the list without duplicates
	lrows=$(awk -vFS="${WS_EVT_LIST_SEP}" -vjdat=${ev_list_fields[dat]} -vjlat=${ev_list_fields[lat]} \
	-vjlon=${ev_list_fields[lon]} -vjdep=${ev_list_fields[dep]} -vjmag=${ev_list_fields[mag]} \
	'!x[$jdat $jlat $jlon $jdep $jmag]++' ${lfilf})

	# header
	lstrx=$(for k in ${!ev_list_fields[@]}; do [ ${k} != "baz" -a ${k} != "dst" ] && echo ${ev_list_fields[${k}]} ${k}; done)
	lstrx=$(echo "${lstrx}" | sort | awk -vORS="${WS_EVT_LIST_SEP}" '{print $2}'); lstrx="#"${lstrx%${WS_EVT_LIST_SEP}}

	echo -e "${lstrx}\n${lrows}" >${lfilf}

	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_load_evt_cfg()
{
	local lfcfg lc0 lstr lstx lsty ltmp lstrx lerr
	lfcfg=$1; ((lerr=0))
	[ -z "${lfcfg}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	[ -f ${lfcfg} ] || { echo "${FUNCNAME}: file ${lfcfg} does not exist" >/dev/stderr; return 1; }
	lc0=$(awk -vFS='[[:blank:]]*=[[:blank:]]*' '!/^#/ {gsub(/["\047;\\\t<>$*\+\-: ]/, ""); print}' ${lfcfg})
	lstr=$(echo "${lc0}" | awk '/^'${ev_list_sep}'=/' | awk -vFS== 'END {print $2}')
	lstr=${lstr:0:1}; lstr=${lstr:-${WS_EVT_LIST_SEP}}
	lstrx=$(ws_set_par "${lstrx}" ${ev_list_sep} ${lstr})
	for lstx in ${!ev_list_fields[@]}
	do
		lsty=${ev_list_fprefx}${lstx}; lstr=$(echo "${lc0}" | awk '/^'${lsty}'=/' | awk -vFS== 'END {print $2}')
		if [ ! -z "${lstr}" ]; then
			lstrx=$(ws_set_par "${lstrx}" ${lsty} ${lstr})
		elif [ ${lstx} != "idv" -a ${lstx} != "tmg" -a ${lstx} != "baz" -a ${lstx} != "dst" ]; then
			echo -e "${FUNCNAME}: parameter ${lstx} missing" >/dev/stderr; ((lerr+=1))
		fi
	done
	if [ ${lerr} -eq 0 ]; then
		ltmp=$(echo "${lstrx}" | awk '/^'${ev_list_fprefx}'/ {print $2}' | sort -u | wc -l)
		if [ ${ltmp} -lt 7 ]; then
			echo -e "${FUNCNAME}: duplicates found in the event list field definitions" >/dev/stderr
			((lerr+=1))
		fi
	fi
	[ ${lerr} -eq 0 ] && echo "${lstrx}"
	return ${lerr}
}
# -------------------------------------------------------------------------------------------------------------------------------
ws_get_evtf()
{
	local levtx=$1 lstrx=$2
	[ -z "${lstrx}" ] && { echo "${FUNCNAME}: wrong number of arguments" >/dev/stderr; return 1; }
	echo "${levtx}" | awk -vFS="${WS_EVT_LIST_SEP}" -vi=${ev_list_fields[${lstrx}]} '{print $i}'
}
# -------------------------------------------------------------------------------------------------------------------------------
