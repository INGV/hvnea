#!/bin/bash

#########################################################################################################################
#
# This file is part of HVNEA.
# 
# HVNEA is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# HVNEA is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with HVNEA.  If not, see <http://www.gnu.org/licenses/>.
#
#  Created: 2022-10-05
#  Copyright: 2022
#  M. Vassallo, G. Riccio, A. Mercuri, G. Cultrera, G. Di Giulio (INGV, Rome, Italy)
#
#########################################################################################################################
usage()
{
	echo ""
	echo "Usage: $(basename $0) [ -g cfg_dir ] input_dirs"
	echo " where:"
	echo "  -g cfg_dir specifies the directory containing the configuration files, if different from the default"
	echo "  input_dirs are the HV_Eqk.sh output directories to recover"
}
base_dir=$(dirname ${BASH_SOURCE}); cfg_dir=${base_dir}/conf; lib_dir=${base_dir}/tools; fcomm=${lib_dir}/tools.sh
. ${fcomm} || exit 1
while getopts g: OPZ
do
	case $OPZ in
		g) cfg_dir=${OPTARG} ;;
		?) usage; exit 1 ;;
	esac
done
shift $((OPTIND-1)); declare -a dirs; dirs=($@); ndirs=${#dirs[@]}
[ ${ndirs} -eq 0 ] && { echo -e "\nspecify at least one HV_Eqk.sh output directory"; usage; exit 0; }
fcfg=${cfg_dir}/hv_eqk.conf
g_cfg=$(init_cfg_hvnoise) && g_cfg=$(parse_cfg_hveqk ${fcfg} "${g_cfg}") && check_cfg_hveqk "${g_cfg}" || exit 1
((err=0))
for dirx in ${dirs[@]}
do
	echo
	check_hveqk_output ${dirx} 1 && hv_eqk_all ${dirx} "${g_cfg}" && hv_eqk_output ${dirx} "${g_cfg}"
	((err+=$?))
done
exit ${err}
